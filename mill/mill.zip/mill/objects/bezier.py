"""
.. module:: utils.parts.bezier
   :synopsis: Collection fo functions to support bezier-style nurbsCurves

.. moduleauthor:: andreasg
"""

# maya imports
import pymel.core as pm
from maya.api.OpenMaya import MVector

# package imports
from millrigger.globals import rig as RIG
from millrigger.utils.data import RigData
from millrigger.utils import name as mname
from millrigger.utils.nodes import create as mcrt


def three_point_bezier(name='C_generic_CRV', axis='+y', tangents='all'):
    ''' Create a curve with 7 CVs and add bezier-style behaviour to it

    :param name: Name of node.
    :type name: String

    :param axis: Orientation of the curve
    :type axis:  +x/+y/+z/-x/-y/-z

    :param tangents: What parts to create tangents on
    :type tangents: String - all/mid/ends

    :rType: PyNode

    '''

    crv_data = RigData
    if tangents == 'all':
        val_list = [-1.0, -0.75, -0.25, 0.0, 0.25, 0.75, 1.0]
        index_dict = {1: 0, 2: 3, 4: 3, 5: 6}
    elif tangents == 'mid':
        val_list = [-1.0, -0.33, 0.0, 0.33, 1.0]
        index_dict = {1: 2, 3: 2}
    elif tangents == 'ends':
        val_list = [-1.0, -0.67, 0.0, 0.67, 1.0]
        index_dict = {1: 0, 3: 4}
    else:
        raise ValueError('Invalid value for "tangents" : %s' % tangents)

    namer = mname.Name(name)
    axis_vec = RIG.STR_TO_VEC_SWITCH[axis]
    pos_list = [(i * axis_vec[0], i * axis_vec[1], i * axis_vec[2]) for i in val_list]
    crv = pm.curve(p=pos_list, name=name)
    loc_list = []
    for i, pos in enumerate(pos_list):
        loc = mcrt.simple_node('locator', namer.replace(index=i + 1, suffix='LOC'))
        loc.transform.t.set(pos)
        loc.shape.wp >> crv.cv[i]
        loc.shape.localScale.set(.1, .1, .1)
        loc_list.append(loc)

    # organising the locators
    for index in index_dict:
        loc = loc_list[index]
        loc.transform.setParent(loc_list[index_dict[index]].transform)
        loc.shape.localPosition.set(loc.transform.t.get())
        loc.transform.t.set(0, 0, 0)
        loc.transform.v.set(False)

    # distances
    dist_01 = pm.createNode('distanceBetween', name=namer.replace(index=1, suffix='DIST'))
    dist_02 = pm.createNode('distanceBetween', name=namer.replace(index=2, suffix='DIST'))
    len_val = len(val_list)

    loc_list[0].transform.wm >> dist_01.inMatrix1
    loc_list[(len_val - 1) / 2].transform.wm >> dist_01.inMatrix2
    loc_list[(len_val - 1) / 2].transform.wm >> dist_02.inMatrix2
    loc_list[len_val - 1].transform.wm >> dist_02.inMatrix1

    at = 's' + axis[-1]
    if tangents == 'all':
        dist_01.distance >> loc_list[1].transform.attr(at)
        dist_01.distance >> loc_list[2].transform.attr(at)
        dist_02.distance >> loc_list[4].transform.attr(at)
        dist_02.distance >> loc_list[5].transform.attr(at)
    else:
        dist_01.distance >> loc_list[1].transform.attr(at)
        dist_02.distance >> loc_list[3].transform.attr(at)

    if tangents != 'ends':
        # orientation
        sub = mcrt.node('sub', name=namer.replace(suffix='SUB')).node
        angl = mcrt.node('angleBetween', name=namer.replace(suffix='ANGL')).node
        angl.vector1.set(axis_vec)
        sub.o3 >> angl.vector2

        if tangents == 'mid':
            loc_list[4].shape.wp >> sub.i3[0]
            loc_list[0].shape.wp >> sub.i3[1]
            angl.euler >> loc_list[1].transform.r
            angl.euler >> loc_list[3].transform.r
        else:
            loc_list[6].shape.wp >> sub.i3[0]
            loc_list[1].shape.wp >> sub.i3[1]
            angl.euler >> loc_list[2].transform.r
            angl.euler >> loc_list[4].transform.r

    crv_data.crv = crv
    if tangents == 'all':
        crv_data.locs = [loc.transform for loc in loc_list[::3]]
    else:
        crv_data.locs = [loc.transform for loc in loc_list[::2]]
