import pymel.core as pm
from millrigger.utils.nodes import constraints as mcon
from millrigger.utils.nodes import create as mcre
from millrigger.utils import matrix as mmtrx
from millrigger.utils import name as mname
from millrigger.utils import fkik as mfkik

import rigobject as rigobj
import srtgroup as msrt


class SRTGroupLinearTwistChain(rigobj.RigObjectChain):
    def __init__(self, name, start, end, driver, parent=None, aim="+x", up="+z", num_twists=3, suffix=None,
                 length_driver=None):
        """
        Creates a series of SRT Groups that blend from

        :param name:
        :param start:
        :param end:
        :param parent:
        :param aim:
        :param up:
        :param num_twists:
        :return:
        """
        namer = mname.Name(name, index=None)
        start_matrix = mmtrx.get_matrix(start)
        end_matrix = mmtrx.get_matrix(end)

        # make an RP IK Handle to get the root rotation
        root_ik_jnt = pm.createNode("joint",
                                    p=start,
                                    n=namer.replace(add_to_tags="root", suffix="IK_AIM")
                                    )
        root_ik_jnt_end = pm.createNode("joint",
                                        p=root_ik_jnt,
                                        n=namer.replace(add_to_tags="root", suffix="IK_END")
                                        )
        root_ik_jnt.visibility.set(False)
        mmtrx.set_matrix(root_ik_jnt, start_matrix)
        mmtrx.set_matrix(root_ik_jnt_end, end_matrix)
        ikh = mfkik.create_ik_handle(name,
                                     eff_ctrl=None,
                                     start_jnt=root_ik_jnt,
                                     end_jnt=root_ik_jnt_end,
                                     ikh_parent=driver,
                                     twist=None,
                                     twist_offset=0.0,
                                     snap=False
                                     )
        ikh.poleVector.set(0, 0, 0)
        ikh.visibility.set(False)

        # make an aim constraint using the start as an aim object. This will drive the root rotation
        root_aimer = pm.createNode("transform", p=start, n=namer.replace(add_to_tags="root", suffix="AIMER"))
        root_aimer.t.set(0, 0, 0)
        mcon.create_aim_constraint(source=root_ik_jnt_end,
                                   target=root_aimer,
                                   aim=aim,
                                   up=up,
                                   axis_obj=root_ik_jnt,
                                   axis_aim=up,
                                   snap=True
                                   )

        # make another aimer under it that uses the end as an aim object. This will drive the interpolated rotations
        end_aimer = pm.createNode("transform", p=root_aimer, n=namer.replace(add_to_tags="end", suffix="AIMER"))
        end_aimer.t.set(0, 0, 0)
        mcon.create_aim_constraint(source=end, target=end_aimer, aim=aim, up=up, axis_obj=end, axis_aim=up, snap=True)

        # make a bone chain
        super(SRTGroupLinearTwistChain, self).__init__(rig_object=msrt.SRTGroup,
                                                       name=namer.create_name(),
                                                       suffix=suffix,
                                                       matrices=[start_matrix] * (num_twists + 1),
                                                       parent=parent,
                                                       tags="",
                                                       last=True
                                                       )

        # constrain the first to the root aimer
        mcon.create_simple_constraint(source=root_aimer, target=self.chain[0].zero)

        # drive the translate if have an attribute
        if length_driver:
            divide = mcre.node(node_type="div", name=namer.replace(add_to_tags="translate", suffix="DIV")).node
            length_driver >> divide.input1
            divide.input2.set(num_twists, num_twists, num_twists)

#             # if the length is negative, negate the divide (check the longest translate to work it out)
#             lengths = [length_driver.tx.get(), length_driver.ty.get(), length_driver.tz.get()]
#             lengths_abs = [abs(l) for l in lengths]
#             longest = lengths[lengths_abs.index(max(lengths_abs))]
#
#             if longest > 0.0:
#                 divide.input2.set(num_twists, num_twists, num_twists)
#             else:
#                 divide.input2.set(-num_twists, -num_twists, -num_twists)

            # distribute along the chain
            for srt in self.chain[1:]:
                divide.output >> srt.root.translate

        # otherwise distribute the translates
        else:
            distance = root_ik_jnt_end.t.get().length()
            for srt in self.chain[1:]:
                srt.obj.setAttr("t" + aim.lower()[1], distance / num_twists)

        # distribute the aim rotation of the end aimer
        divide = mcre.node(node_type="div", name=namer.replace(add_to_tags="rotation", suffix="DIV")).node
        end_aimer.rotate >> divide.input1
        divide.input2.set(num_twists - 1, num_twists - 1, num_twists - 1)
        for srt in self.chain[1:-1]:
            divide.output >> srt.obj.rotate
