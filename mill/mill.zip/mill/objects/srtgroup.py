'''
Created on 25 Jan 2016

@author: petera
'''
import rigobject as rigobj


class SRTGroup(rigobj.RigObject):
    """
    A light class that creates a joint with an offset at a given matrix.

    Joints will lose some functionality in maya if they have more than one
    parent transform, so adding a zero will be True by default, but not a
    zero ofs, though the option will still be there, if needed.
    """

    def __init__(self,
                 name,
                 matrix,
                 offset_matrix=None,
                 parent=None,
                 rotate_order="xyz",
                 create_zero=True,
                 create_ofs=False,
                 create_secondary=False,
                 create_mtx=False,
                 create_cnst=False,
                 suffix='SRT',
                 add_to_tags=None):
        """

        :param matrix:
        :param name:
        :param parent:
        :param rotate_order:
        :param create_zero:
        :param create_ofs:
        :param create_secondary:
        :param add_to_tags:
        :return:
        """
        super(SRTGroup, self).__init__(matrix=matrix,
                                       name=name,
                                       offset_matrix=offset_matrix,
                                       parent=parent,
                                       rotate_order=rotate_order,
                                       create_zero=create_zero,
                                       create_ofs=create_ofs,
                                       create_secondary=create_secondary,
                                       create_cnst=create_cnst,
                                       create_mtx=create_mtx,
                                       suffix=suffix,
                                       node_type='transform',
                                       add_to_tags=add_to_tags)

        # store
        self.srt = self.obj
        self.secondary_srt = self.secondary_obj


class SRTGroupChain(rigobj.RigObjectChain):
    def __init__(self,
                 name,
                 matrices,
                 offset_matrix=None,
                 parent=None,
                 tags="",
                 last=True,
                 rotate_order="xyz",
                 create_zero=True,
                 create_ofs=False,
                 create_secondary=False,
                 create_mtx=False,
                 create_cnst=False,
                 suffix="SRT",
                 add_to_tags=None,
                 flat=False):
        """

        :param name:
        :param matrices:
        :param parent:
        :param tags:
        :param last:
        :param rotate_order:
        :param create_zero:
        :param create_ofs:
        :param create_cnst:
        :param create_secondary:
        :return:
        """

        # make the args lists
        kwargs = {"rotate_order": rotate_order,
                  "create_zero": create_zero,
                  "create_ofs": create_ofs,
                  "create_cnst": create_cnst,
                  "create_secondary": create_secondary,
                  "create_mtx": create_mtx,
                  "suffix": suffix
                  }

        super(SRTGroupChain, self).__init__(rig_object=SRTGroup,
                                            name=name,
                                            matrices=matrices,
                                            offset_matrix=offset_matrix,
                                            parent=parent,
                                            tags=tags,
                                            last=last,
                                            add_to_tags=add_to_tags,
                                            flat=flat,
                                            **kwargs)
