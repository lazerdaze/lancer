

from pymel.core import createNode
import millrigger.objects.rigobject as rigobj
from millrigger.utils.matrix import IDENTITY_MATRIX


class FollicleObject(rigobj.RigObject):
    """
    Using RigObject as the base for a single rig object

    :param name: The basename of the control.
    :type name: String

    :param suffix: The suffix of the control.
    :type suffix: String

    :param node_type: "joint" or "transform".
    :type node_type: String

    :param matrix: matrix or transform-node to match else "None".
    :type matrix: MMatrix or Transform

    :param offset_matrix: matrix or transform-node to match else "None".
    :type offset_matrix: MMatrix or Transform

    :param rotate_order: Default is 'xyz'.
    :type rotate_order: String

    :param parent: If given, the zero-node will be parented to this transform.
    :type parent: Transform

    :param create_zero: Add a zero-transform to the hierarchy
    :type create_zero: Boolean

    :param create_ofs: Add a ofs-transform to the hierarchy
    :type create_ofs: Boolean

    :param create_secondary: Add a secondary-transform as child the the main object
    :type create_secondary: Boolean

    :param create_cnst: Add a locator child for constraints
    :type create_cnst: Boolean

    :param create_mtx: Add a transform for use as flexible outmatrix
    :type create_mtx: Boolean


    """
    def __init__(self, name,
                 node_type='transform',
                 matrix=None,
                 offset_matrix=None,
                 rotate_order='xyz',
                 parent=None,
                 suffix='SRT',
                 add_to_tags=None,
                 create_zero=True,
                 create_ofs=False,
                 create_secondary=False,
                 create_cnst=False,
                 create_mtx=False,
                 nrb=None,
                 uv=(0.5, 0.5)
                 ):

        self.nrb = nrb
        self.uv = uv
        self.foll = None
        self.follshape = None
        self.u_plug = None
        self.v_plug = None

        super(FollicleObject, self).__init__(matrix=IDENTITY_MATRIX,
                                             name=name,
                                             parent=parent,
                                             offset_matrix=offset_matrix,
                                             rotate_order=rotate_order,
                                             create_zero=create_zero,
                                             create_ofs=create_ofs,
                                             create_secondary=create_secondary,
                                             create_cnst=create_cnst,
                                             create_mtx=create_mtx,
                                             suffix=suffix,
                                             node_type=node_type,
                                             add_to_tags=add_to_tags)

    def build(self, zero=True, ofs=True, secondary=False, cnst=False, mtx=False):
        """
        create hierarchy
        """
        parent = self.parent

        # create follicle
        self.create_follicle(parent)
        parent = self.foll

        # create zero
        if zero:
            self.create_zero(parent)
            parent = self.zero

        # create ofs
        if ofs:
            self.create_ofs(parent)
            parent = self.ofs

        # make the main srt
        parent = self.create_obj(parent)

        # make a secondary srt if needed
        if secondary:
            self.create_secondary_obj()
            parent = self.secondary_obj

        if mtx:
            self.create_mtx(parent)

        if cnst:
            self.cnst = createNode('locator',
                                   name=self.namer.replace(add_to_suffix='CNST') + 'Shape',
                                   parent=self.top
                                   )
            self.cnst.visibility.set(False)

        # if self.nrb is defined, connect the follicle to the nurbsSurface
        if self.nrb:
            self.connect_to_nurbs()

    def create_follicle(self, parent):
        """ create and return follicle-node"""

        self.foll = self._create_transform(parent=parent,
                                           matrix=IDENTITY_MATRIX,
                                           add_to_suffix='FOLL')
        self.follshape = createNode('follicle',
                                    name=self.foll.name() + 'Shape',
                                    parent=self.foll)
        self.follshape.outTranslate >> self.foll.t
        self.follshape.outRotate >> self.foll.r
        self.follshape.visibility.set(False)
        self.u_plug = self.foll.pu
        self.v_plug = self.foll.pv

    def connect_to_nurbs(self, nrb=None, uv=None):
        """
        connect nurbs to follicle and set u/v-values
        :param nrb: nurbsSurface-transform-Node
        :type nrb: PyNode
        :param uv: nurbsSurface-transform-Node
        :type uv: PyNode
        """
        nrb = nrb or self.nrb
        uv = uv or self.uv
        if nrb:
            nrb.getShape().ws >> self.follshape.inputSurface
        if uv:
            self.u_plug.set(uv[0])
            self.v_plug.set(uv[1])


class FollicleObjectChain(rigobj.RigObjectChain):
    def __init__(self,
                 name,
                 parent=None,
                 node_type='transform',
                 tags="",
                 rotate_order="xyz",
                 create_zero=True,
                 create_ofs=False,
                 create_secondary=False,
                 create_mtx=False,
                 create_cnst=False,
                 suffix="SRT",
                 add_to_tags=None,
                 uvs=(0.5, 0.5),
                 nrb=None):
        """

        :param name:
        :param parent:
        :param tags:
        :param node_type:
        :param rotate_order:
        :param create_zero:
        :param create_ofs:
        :param create_cnst:
        :param create_secondary:
        :param suffix:
        :param add_to_tags:
        :param uv:
        :param nrb:
        :return:
        """

        if isinstance(uvs, tuple):
            matrices = [IDENTITY_MATRIX]
        elif isinstance(uvs, list):
            if isinstance(uvs[0], (list, tuple)):
                matrices = [IDENTITY_MATRIX] * len(uvs)

        print matrices

        # make the args lists
        kwargs = {"rotate_order": rotate_order,
                  "create_zero": create_zero,
                  "create_ofs": create_ofs,
                  "create_cnst": create_cnst,
                  "create_secondary": create_secondary,
                  "create_mtx": create_mtx,
                  "suffix": suffix,
                  "node_type": node_type,
                  "uv": uvs,
                  "nrb": nrb
                  }

        super(FollicleObjectChain, self).__init__(rig_object=FollicleObject,
                                                  name=name,
                                                  matrices=matrices,
                                                  parent=parent,
                                                  tags=tags,
                                                  last=False,
                                                  add_to_tags=add_to_tags,
                                                  flat=True,
                                                  **kwargs)

    @property
    def follicles(self):
        """
        :return: A list of all the follicle-transforms in the chain
        """
        out = []
        for each in self:
            try:
                out.append(each.foll)
            except AttributeError:
                continue
        return out
