'''
Created on 5 Feb 2016

@author: matthewk
'''

# python modules
import pymel.core as pm
import maya.api.OpenMaya as om

# package modules
from millrigger.utils import name as mname
from millrigger.utils import matrix as mmtrx
from millrigger.objects.controls import control as mctrl
import millrigger.utils.nodes.create as mcreate


class TiltControl(object):

    def __init__(self, name='C_bank_TMP', in_pos=None, shape='bendArrowsTilt', width=1, axis='+x', ctrl_size=1.0, parent=None):
        self.namer = mname.Name(name)
        self.in_pos = in_pos
        self.shape = shape
        self.width = int(width)
        self.axis = axis.lower()
        self.parent = parent
        self.ctrl_size = ctrl_size

    def create_control(self):
        
        
        if isinstance(self.in_pos, om.MMatrix):
            mtx = self.in_pos
        else:
            mtx = mmtrx.get_matrix(pm.PyNode(self.in_pos), ws=True)
        
        if self.axis[-1] == 'z' or self.axis == 'Z':
            pvt = -2
        else:
            pvt = -4
            
        center_matrix = mtx

        lft_mtx = om.MMatrix(mtx)
        l_value = lft_mtx[pvt]
        lft_mtx[pvt] = l_value + self.width

        rght_mtx = om.MMatrix(mtx)
        r_value = rght_mtx[pvt]
        rght_mtx[pvt] = r_value - self.width
        
        print center_matrix

        # create Tilt
        self.main = mctrl.Control(self.namer.replace(suffix="CTRL", add_to_tags='bank'),
                                       shape_type=self.shape,
                                       size=self.ctrl_size,
                                       matrix=center_matrix,
                                       shape_aim='+z',
                                       shape_up='+y',
                                       parent=self.parent,
                                       lock_pos = "xyz",
                                       lock_rot = "xy",
                                       lock_scl = "xyz"
                                       )
        self.ctrl = self.main.ctrl

        self.left_pvt = mcreate.node('transform',
                                     name=self.namer.replace(add_to_tags='bank', suffix='left_PVT'),
                                     parent=self.main.zero,
                                     matrix=lft_mtx
                                     ).transform

        self.right_pvt = mcreate.node('transform',
                                      name=self.namer.replace(add_to_tags='bank', suffix="right_PVT"),
                                      parent=self.left_pvt,
                                      matrix=rght_mtx
                                      ).transform

        # create setRange
        self.setrange = mcreate.node('setRange',
                                     name=self.namer.replace(add_to_tags='bank', suffix="bank_SRG")
                                     ).node

        # set the values of the SetRange
        self.setrange.minY.set(-360)
        self.setrange.maxZ.set(360)
        self.setrange.oldMinY.set(-360)
        self.setrange.oldMaxZ.set(360)

        self.main.ctrl.rz >> self.setrange.vy
        self.main.ctrl.rz >> self.setrange.vz
        self.setrange.outValue.outValueY >> self.left_pvt.rz
        self.setrange.outValue.outValueZ >> self.right_pvt.rz



def midPos(pos1, pos2, obj):
            loc1 = pm.spaceLocator(name='temp_1')
            loc1.setMatrix(pos1)
            loc2 = pm.spaceLocator(name='temp_2')
            loc2.setMatrix(pos2)
            cnst = pm.parentConstraint(loc1, loc2, obj, w=1)
            pm.delete(cnst, loc1, loc2)


def spacing(dist, segs):
    end = (dist/2)*-1
    start = dist/2
    pos_list = []
    if segs == 1:
        pos_list.append((start+end))
    elif segs == 2:
        pos_list.append(start)
        pos_list.append(end)
    elif segs > 2:
        s = abs(start)
        e = abs(end)
        div = dist/(segs-1.0)
        for i in range(segs):
            if i == 0:
                pos_list.append(start)
            elif i == segs:
                pos_list.append(end)
            else:
                iteration = pos_list[-1]-div
                pos_list.append(iteration)
    return pos_list

def add_visibility_attr(ctrl, attr_list, lock = False):
    for attr in attr_list:
        ctrl.addAttr(attr, dv=0, k=False, minValue=0, maxValue=1, at=int)
        pm.setAttr(ctrl+'.'+attr, cb=True)

def add_title_attr(ctrl, attr_list, lock = False):
    for attr in attr_list:
        ctrl.addAttr(attr, en='___', at='enum', k=False)
        pm.setAttr(ctrl+'.'+attr, cb=True)
        if lock==True:
            pm.setAttr(ctrl+'.'+attr, lock=True)
            
def add_float_attr(ctrl, attr_list, lock = False):
    for attr in attr_list:
        ctrl.addAttr(attr, dv=0, at=float)
        pm.setAttr(ctrl+'.'+attr, cb=True)
