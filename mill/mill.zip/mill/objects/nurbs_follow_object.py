import pymel.core as pm
from maya.api.OpenMaya import MAngle, MEulerRotation

import millrigger.objects.rigobject as mrig
import millrigger.utils.info as minf

from millrigger.utils import matrix as mmtrx
from millrigger.utils import vector as mvec
from millrigger.globals.rig import MIRROR_SWITCH, ROTATIONORDER_SWITCH


class FollowObject(mrig.RigObject):
    """
    Using RigObject as the base for a single rig object

    :param name: The basename of the control.
    :type name: String

    :param suffix: The suffix of the control.
    :type suffix: String

    :param node_type: "joint" or "transform".
    :type node_type: String

    :param rotate_order: Default is 'xyz'.
    :type rotate_order: String

    :param parent: If given, the zero-node will be parented to this transform.
    :type parent: Transform

    :param create_cnst: Add a locator child for constraints
    :type create_cnst: Boolean

    :param create_mtx: Add a transform for use as flexible outmatrix
    :type create_mtx: Boolean

    :param nurbs: transform of a nurbsSurface
    :type nurbs: PyNode

    :param uv: values for u and v (based on parameters)
    :type uv: Tuple or List

    :param uv: values for dimensions of nurbsSurface in units (if not given it will be calculated)
    :type uv: Tuple or List

    :param u_axis: axis to be aligned to u-direction of nurbsSurface
    :type u_axis: +x, +y, +z, -x, -y, -z

    :param v_axis: axis to be aligned to v-direction of nurbsSurface
    :type v_axis: +x, +y, +z, -x, -y, -z

    """

    def __init__(self, name,
                 rotate_order='xyz',
                 parent=None,
                 parent_obj=None,
                 create_mtx=True,
                 add_to_tags=None,
                 mirror_mode='FULL',
                 nurbs_size=None,
                 u_axis='+x',
                 v_axis='+y'
                 ):

        self.nurbs_size = nurbs_size
        self.u_axis = u_axis
        self.v_axis = v_axis
        self.w_axis = self._get_w_axis()
        self.srg = None

        super(FollowObject, self).__init__(name=name,
                                           node_type='transform',
                                           rotate_order=rotate_order,
                                           parent=parent,
                                           create_zero=True,
                                           create_ofs=False,
                                           create_secondary=False,
                                           create_cnst=False,
                                           create_mtx=create_mtx,
                                           add_to_tags=add_to_tags,
                                           mirror_mode=mirror_mode
                                           )

        # right side gets "FULL"-mirror-behaviour => Rotation and translation
        if self.side.startswith("R"):
            self._create_mirrorbehaviour()

        # use a setRange-node to convert from Unit-space to UV-space
        self.srg = self._create_converter()

        # create transform in "2D"-space to provide a matrix
        self._create_flat_srt(parent_obj)

    def _create_mirrorbehaviour(self, mirror_axis='x'):
        # right side mirrors behavior in translation and rotation
        mirror_vec = mmtrx.get_as_mvector(MIRROR_SWITCH[mirror_axis])
        self.zero.s.set(mirror_vec)
        if self.mtx:
            self.mtx.s.set(mirror_vec)

    def _create_flat_srt(self, parent_obj=None):
        """
        create transform in a flat 3D-space
        :return:
        """

        self.zero.ro.disconnect()
        self.zero.ro.set(0)  # xyz
        self.lcl_zero = pm.createNode("transform",
                                      name=self.namer.replace(add_to_tags="local",
                                                              add_to_suffix="ZERO"),
                                      parent=parent_obj)

        self.lcl = pm.createNode("joint",
                                 name=self.namer.replace(add_to_tags="local",
                                                         add_to_suffix="SRT"),
                                 parent=self.lcl_zero)

        self.obj.r >> self.lcl.r
        self.zro.o3 >> self.lcl.t

        self.obj.ro >> self.lcl.ro
        self.obj.jo >> self.lcl.jo

        # use of millSimpleConstraint instaed of decomposeMatrix because the rotateOrder is still buggy on the decompose
        dcmp = pm.createNode("millSimpleConstraint",
                             name=self.namer.replace(add_to_suffix="millSimpleConstraint"))
        dcmp.rotateOrder.set(0)

        if self.side[0] == "R":
            self.lcl_zero.sx.set(-1)
            dcmp.useOffsets.set(True)
            dcmp.rotateOffsetY.set(180)
        else:
            dcmp.useOffsets.set(False)

        self.lcl.worldMatrix >> dcmp.inMatrix
        # self.lcl.ro >> dcmp.rotateOrder
        dcmp.outRotate >> self.zero.r
        dcmp.outTranslate >> self.srg.v

        self.srg.attr("o" + self.u_axis[-1]) >> self.follshape.pu
        self.srg.attr("o" + self.v_axis[-1]) >> self.follshape.pv
        dcmp.attr("ot" + self.w_axis[-1]) >> self.zero.tz

    def _create_converter(self):
        """
        create setRange-node that translates the local-units into UV-values
        """
        srg = pm.createNode("setRange",
                            name=self.namer.replace(add_to_suffix='SRG'))

        u_flip = self.u_axis[0] != '+'
        v_flip = self.v_axis[0] != '+'
        u_vec = mmtrx.get_as_mvector("+" + self.u_axis[-1])
        v_vec = mmtrx.get_as_mvector("+" + self.v_axis[-1])

        u_new_vec = u_vec * self.nurbs_spans[0]
        v_new_vec = v_vec * self.nurbs_spans[1]

        srg.min.set(u_new_vec * u_flip + v_new_vec * v_flip)
        srg.max.set(u_new_vec * (not u_flip) + v_new_vec * (not v_flip))

        u_old_vec = u_vec * self.nurbs_size[0]
        v_old_vec = v_vec * self.nurbs_size[1]
        old_vec = u_old_vec + v_old_vec

        srg.oldMin.set(-0.5 * old_vec)
        srg.oldMax.set(0.5 * old_vec)
        return srg

    def _get_w_axis(self):
        w_axis = "+" + "xyz".translate(None, self.u_axis + self.v_axis)
        return w_axis

    def _get_nurbs(self, nurbs):
        nurbs_type = nurbs.type()
        if nurbs_type == "transform":
            transform = nurbs
            shape = nurbs.getShape(type="nurbsSurface")
            if shape:
                return transform, shape
        elif nurbs_type == "nurbsSurface":
            transform = nurbs.getParent()
            shape = nurbs
            return transform, shape
        else:
            raise RuntimeError("Couldn't find NurbsSurface!")

    @staticmethod
    def zero_out(ctrl):
        """
        zero out control translation and rotation
        :param ctrl:
        :return:
        """
        # zero out rotation --------------------------------------
        ro = ROTATIONORDER_SWITCH[ctrl.ro.get()]
        rot_vec = mvec.get_as_mvector(ctrl.r.get())
        jo_vec = mvec.get_as_mvector(ctrl.jo.get())

        jo_euler = mvec.get_as_eulerrotation(jo_vec, ro="xyz")
        r_euler = mvec.get_as_eulerrotation(rot_vec, ro=ro)
        r_euler.reorderIt(ROTATIONORDER_SWITCH["xyz"])

        matrix = r_euler.asMatrix() * jo_euler.asMatrix()
        euler = MEulerRotation.decompose(matrix, 0)
        rot = mvec.get_as_mvector([MAngle(euler.x, MAngle.kRadians).asDegrees(),
                                   MAngle(euler.y, MAngle.kRadians).asDegrees(),
                                   MAngle(euler.z, MAngle.kRadians).asDegrees()]
                                  )

        # zero out translation -----------------------------------

        # check for zro node
        found = ctrl.t.outputs(type="plusMinusAverage")
        if not found:
            return
        zro = found[0]
        found = zro.o3.outputs(type="joint")
        if not found:
            return
        pos = found[0].t.get()

        # set the values
        zro.i3[1].set(pos)
        ctrl.t.set(0, 0, 0)

        ctrl.jo.set(rot)
        ctrl.r.set(0, 0, 0)

    @staticmethod
    def zero_reset(ctrl):
        """
        zero out control translation and rotation
        :param ctrl:
        :return:
        """
        # zero out rotation --------------------------------------
        ro = ROTATIONORDER_SWITCH[ctrl.ro.get()]
        rot_vec = mvec.get_as_mvector(ctrl.r.get())
        jo_vec = mvec.get_as_mvector(ctrl.jo.get())

        jo_euler = mvec.get_as_eulerrotation(jo_vec, ro="xyz")
        r_euler = mvec.get_as_eulerrotation(rot_vec, ro=ro)
        jo_euler.reorderIt(ROTATIONORDER_SWITCH[ro])

        matrix = r_euler.asMatrix() * jo_euler.asMatrix()
        euler = MEulerRotation.decompose(matrix, ctrl.ro.get())
        rot = mvec.get_as_mvector([MAngle(euler.x, MAngle.kRadians).asDegrees(),
                                   MAngle(euler.y, MAngle.kRadians).asDegrees(),
                                   MAngle(euler.z, MAngle.kRadians).asDegrees()]
                                  )

        # zero out translation -----------------------------------

        # check for zro node
        found = ctrl.t.outputs(type="plusMinusAverage")
        if not found:
            return
        zro = found[0]
        found = zro.o3.outputs(type="joint")
        if not found:
            return
        pos = found[0].t.get()

        # set the values
        ctrl.r.set(rot)
        ctrl.jo.set(0, 0, 0)
        zro.i3[1].set(0, 0, 0)
        ctrl.t.set(pos)
