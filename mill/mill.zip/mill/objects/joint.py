'''
Created on 25 Jan 2016

@author: petera
'''
import rigobject as rigobj
import millrigger.utils.matrix as mmtrx
import pymel.core as pm


class Joint(rigobj.RigObject):
    """
    A light class that creates a joint with an offset at a given matrix.

    Joints will lose some functionality in maya if they have more than one
    parent transform, so adding a zero will be True by default, but not a
    zero ofs, though the option will still be there, if needed.
    """

    def __init__(self,
                 matrix,
                 name,
                 offset_matrix=None,
                 parent=None,
                 keep_rotation=True,
                 rotate_order="xyz",
                 create_zero=True,
                 create_ofs=False,
                 create_cnst=False,
                 add_to_tags=None):
        """

        :param matrix:
        :param name:
        :param parent:
        :param rotate_order:
        :param create_zero:
        :param create_ofs:
        :param create_cnst:
        :return:
        """
        super(Joint, self).__init__(matrix=matrix,
                                    name=name,
                                    offset_matrix=offset_matrix,
                                    add_to_tags=add_to_tags,
                                    suffix='JNT',
                                    node_type='joint',
                                    parent=parent,
                                    create_zero=create_zero,
                                    create_ofs=create_ofs,
                                    create_cnst=create_cnst,
                                    keep_rotation=keep_rotation,
                                    rotate_order=rotate_order)

        # specific variables
        self.joint = self.obj

    def create_obj(self, parent=None):
        """ create and return main obj"""
        self.obj = pm.createNode("joint", n=self.namer.create_name(), p=parent)
        mmtrx.set_matrix(self.obj, self.matrix)
        self.obj.pa.set(self.obj.rotate.get())
        self.obj.drawStyle.set(2)
        return self.obj


class JointChain(rigobj.RigObjectChain):
    def __init__(self,
                 matrices,
                 name,
                 offset_matrix=None,
                 tags="",
                 parent=None,
                 last=False,
                 rotate_order="xyz",
                 create_zero=True,
                 create_ofs=False,
                 create_cnst=False,
                 add_to_tags=None,
                 keep_rotation=True,
                 zero_first=False
                 ):
        """

        :param matrices:
        :param name:
        :param tags:
        :param parent:
        :param last:
        :param rotate_order:
        :param create_zero:
        :param create_ofs:
        :param create_cnst:
        :return:
        """
        num_objs = len(matrices)

        # override in case we want only the first control zeroed
        keep_rotation = self.make_value_list(keep_rotation, num_objs)
        if zero_first:
            keep_rotation[0] = False

        super(JointChain, self).__init__(rig_object=Joint,
                                         name=name,
                                         matrices=matrices,
                                         offset_matrix=offset_matrix,
                                         parent=parent,
                                         tags=tags,
                                         last=last,
                                         add_to_tags=add_to_tags,
                                         keep_rotation=keep_rotation,
                                         create_zero=create_zero,
                                         create_ofs=create_ofs,
                                         create_cnst=create_cnst
                                         )
