'''
Created on 1 Feb 2016

@author: petera
'''
import millrigger.utils.name as mname
import millrigger.utils.matrix as mmtrx
from millrigger.globals.rig import ROTORDER_SWITCH
from pymel.core import createNode, objExists, PyNode

LENGTH_ERR_MSG = "The argument '%s' must be of length %d for this chain: %s"


class RigObject(object):
    """
    Using RigObject as the base for a single rig object

    :param name: The basename of the control.
    :type name: String

    :param suffix: The suffix of the control.
    :type suffix: String

    :param node_type: "joint" or "transform".
    :type node_type: String

    :param matrix: matrix or transform-node to match else "None".
    :type matrix: MMatrix or Transform

    :param offset_matrix: matrix or transform-node to match else "None".
    :type offset_matrix: MMatrix or Transform

    :param rotate_order: Default is 'xyz'.
    :type rotate_order: String

    :param parent: If given, the zero-node will be parented to this transform.
    :type parent: Transform

    :param create_zero: Add a zero-transform to the hierarchy
    :type create_zero: Boolean

    :param create_ofs: Add a ofs-transform to the hierarchy
    :type create_ofs: Boolean

    :param create_secondary: Add a secondary-transform as child the the main object
    :type create_secondary: Boolean

    :param create_cnst: Add a locator child for constraints
    :type create_cnst: Boolean

    :param create_mtx: Add a transform for use as flexible outmatrix
    :type create_mtx: Boolean

    :param clean_worldscale: makes sure the resulting worldmatrix of "mtx" is always positive
    :type create_mtx: Boolean

    :param create_matrixsum: creates multMatrix that multiplies all local matrices of the hierarchy
    :type create_matrixsum: Boolean


    """
    def __init__(self, name,
                 node_type='transform',
                 zero_node_type='transform',
                 matrix=None,
                 offset_matrix=None,
                 keep_rotation=False,
                 rotate_order='xyz',
                 parent=None,
                 suffix='SRT',
                 add_to_tags=None,
                 create_zero=True,
                 create_ofs=False,
                 create_secondary=False,
                 create_cnst=False,
                 create_mtx=False,
                 clean_worldscale=True):

        # empty class-variables for new created nodes
        self.zero = None
        self.spc = None
        self.ofs = None
        self.obj = None
        self.secondary_obj = None
        self.cnst = None
        self.bone = None
        self.mtx = None
        self.matrixsum = None

        # Ensure name is always the Name()
        if isinstance(name, mname.Name):
            self.namer = name(add_to_tags=add_to_tags,
                              suffix=suffix or "SRT")
        else:
            self.namer = mname.Name(name,
                                    add_to_tags=add_to_tags,
                                    suffix=suffix or "SRT")
        self.name = self.namer.create_name()

        # user-defined parameters
        self.parent = parent
        self.node_type = node_type
        self.zero_node_type = zero_node_type
        self.keep_rotation = keep_rotation
        self.matrix = matrix or mmtrx.IDENTITY_MATRIX
        self.rotate_order = self._check_rotate_order(rotate_order)
        self.offset_matrix = self._get_offset_matrix(offset_matrix, matrix)
        self.clean_worldscale = clean_worldscale

        # create the nodes
        self.build(zero=create_zero,
                   ofs=create_ofs,
                   secondary=create_secondary,
                   cnst=create_cnst,
                   mtx=create_mtx)

    def build(self, zero=True, ofs=True, secondary=False, cnst=False, mtx=False):
        """
        create hierarchy
        """
        parent = self.parent
        # create zero
        if zero:
            self.create_zero(parent)
            parent = self.zero

        # create ofs
        if ofs:
            self.create_ofs(parent)
            parent = self.ofs

        # make the main srt
        parent = self.create_obj(parent)

        # make a secondary srt if needed
        if secondary:
            self.create_secondary_obj()
            parent = self.secondary_obj

        if mtx:
            self.create_mtx(parent, self.clean_worldscale)

        if cnst:
            self.cnst = createNode('locator',
                                   name=self.namer.replace(add_to_suffix='CNST') + 'Shape',
                                   parent=self.top
                                   )
            self.cnst.visibility.set(False)

    def __iter__(self):
        for item in self.hierarchy(existing=True):
            yield item

    @property
    def root(self):
        """
        returns the lowest object in the hierarchy

        :return: PyNode
        """
        for item in self:
            if item is not None:
                return item

    @property
    def top(self):
        """
        Returns the last DAG Node that can be used as a parent

        :return: PyNode
        """
        reverse_flat = self.hierarchy(existing=True)
        reverse_flat.reverse()
        for item in reverse_flat:
            if item is not None:
                return item

    def hierarchy(self, existing=False):
        """
        Returns the nodes in this object. By default it will return the items that aren't there as well.
        This is so that blend functions can do so, even with objects

        :param existing: If true, only the existing nodes will be returned
        :return: a list of the items in the object
        """
        items = [self.zero, self.spc, self.ofs, self.obj, self.secondary_obj]
        if existing:
            return [item for item in items if item is not None]
        else:
            return items

    def get_shapes(self):
        """
        Returns all the shapes in the rig object

        :return: list of shapes
        """
        out = []
        for item in self.hierarchy(existing=True):
            shapes = item.getShapes(type='nurbsCurve')
            if shapes:
                out.extend(shapes)
        return out

    def create_zero(self, parent=None):
        """ create and return zero-node"""
        if self.keep_rotation:
            matrix = self.offset_matrix or self.matrix
        else:
            matrix = self.matrix
        self.zero = self._create_transform(parent=parent,
                                           matrix=matrix,
                                           add_to_suffix='ZERO',
                                           node_type=self.zero_node_type)
        return self.zero

    def create_ofs(self, parent=None):
        """ create and return offset-node"""
        if self.keep_rotation:
            matrix = self.offset_matrix or self.matrix
        else:
            matrix = self.matrix

        self.ofs = self._create_transform(parent=parent,
                                          matrix=matrix,
                                          add_to_suffix='OFS')
        if self.keep_rotation:
            self.ofs.rotate.set(0, 0, 0)
        return self.ofs

    def create_obj(self, parent=None):
        """ create and return main obj"""
        add_to_suffix = None
        if self.namer.index == 'END' and self.namer.suffix == 'CTRL':
            add_to_suffix = 'SRT'
        self.obj = self._create_transform(parent=parent,
                                          matrix=self.matrix,
                                          add_to_suffix=add_to_suffix,
                                          node_type=self.node_type)
        return self.obj

    def create_secondary_obj(self):
        """ create and return secondary_obj"""
        self.secondary_obj = self._create_transform(parent=self.obj,
                                                    matrix=self.matrix,
                                                    suffix="SCND_" + self.namer.suffix,
                                                    node_type=self.node_type)
        return self.secondary_obj

    def create_mtx(self, parent=None, clean_worldscale=True):
        """
        create and return transform group to provide a matrix to other tools (e.g. a millMatrixRamp).
        Unless requested, the world scale of this transform will not be negative in any axis

        :param clean_worldscale: If true, scaling of nodes worldmatrix is positive

        """
        self.mtx = self._create_transform(parent=parent,
                                          matrix=self.matrix,
                                          add_to_suffix="MTX",
                                          node_type='transform')
    # positive scaling for transform
        if clean_worldscale:
            self.mtx.sx.set(self._get_worldscale(self.matrix))

        return self.mtx

    def create_spc(self):
        """ create and return space-node"""

        self.spc = self._create_transform(parent=self.zero,
                                          add_to_suffix='SPC')

        if self.ofs:
            # store child srt
            rot = self.ofs.r.get()
            pos = self.ofs.t.get()

            self.ofs.setParent(self.spc)

            # restore child srt
            self.ofs.t.set(pos)
            self.ofs.r.set(rot)
        else:
            # store child srt
            rot = self.obj.r.get()
            pos = self.obj.t.get()
            if self.node_type == 'joint':
                jo = self.obj.jo.get()

            self.obj.setParent(self.spc)

            # restore child srt
            self.obj.r.set(rot)
            self.obj.t.set(pos)
            if self.node_type == 'joint':
                self.obj.jo.set(jo)

        return self.spc

    def create_matrixsum(self):
        """
        create and return multMatrix node and multiplies all local matrices in hierarchy
        """
        self.matrixsum = createNode("multMatrix",
                                    name=self.namer.replace(add_to_suffix="multMatrix")
                                    )
        # positive scaling for transform
        hierarchy = self.hierarchy(existing=True)[1:]  # ignore the zero node
        if self.mtx:
            hierarchy.append(self.mtx)
        # reverse content of hierarchy
        hierarchy.reverse()

        for i, item in enumerate(hierarchy):
            item.matrix >> self.matrixsum.matrixIn[i]

        return self.matrixsum

    def create_bone(self, modulebuilder):
        """
        Creates and parents a bone to itself for a module builder

        :param modulebuilder:
        :return:list of joints
        """
        self.bone = create_bone_on_obj(obj=self.top, modulebuilder=modulebuilder)
        return self.bone

    def rename(self, name=None, namer=None, **kwargs):
        """
        rename all objects in the hierarchy

        :param name:
        :return: new name
        """
        namer = namer or mname.Name(name)
        suffix = namer.suffix
        suffix_list = [suffix + '_ZERO',
                       suffix + '_OFS',
                       suffix,
                       'SCND_' + suffix]
        for item, suffix in zip(self.hierarchy(existing=False), suffix_list):
            if item is not None:
                item.rename(namer.replace(suffix=suffix, **kwargs))

    def set_parent(self, parent):
        """
        parent root object to new parent while preserving the worldspace-transformations
        :param parent: new parent-object
        """
        attr_dict = {}
        for at in 'srt':
            attr_dict[(at, None)] = self.root.attr(at).isLocked()
            for axis in 'xyz':
                attr_dict[at, axis] = self.root.attr(at + axis).isLocked()
        matrix = mmtrx.get_matrix(self.root, ws=True)
        self.root.setParent(parent)
        mmtrx.set_matrix(self.root, matrix, ws=True)
        for at in 'srt':
            self.root.attr(at).lock(attr_dict[(at, None)])
            for axis in 'xyz':
                self.root.attr(at + axis).lock(attr_dict[(at, axis)])

    # NON-PUBLIC methods
    def _create_transform(self, parent=None, suffix=None, add_to_suffix=None,
                          matrix=None, node_type='transform'):
        """ create basic transform/joint-node """
        name = self.namer.replace(suffix=suffix or self.namer.suffix,
                                  add_to_suffix=add_to_suffix
                                  )
        obj = createNode(node_type, n=name, p=parent)

        obj.ro.set(self.rotate_order)
        if matrix:
            mmtrx.set_matrix(obj, matrix, ws=True)

        if node_type == 'joint':
            obj.pa.set(obj.rotate.get())
            if self.keep_rotation is False and self.offset_matrix is not None:
                # set the offset matrix
                if self.zero is not None:
                    mmtrx.set_matrix(self.zero, self.offset_matrix)
                if self.ofs is not None:
                    mmtrx.set_matrix(self.ofs, self.offset_matrix)
                mmtrx.set_matrix(obj, self.matrix)

                # get the rotation, then set it back
                rot = obj.rotate.get()

                # put the rotation into the joint orient
                obj.jo.set(rot)
                obj.r.set(0, 0, 0)

            # hide the joint draw
            obj.drawStyle.set(2)
            obj.radius.set(cb=False)
        return obj

    def _get_offset_matrix(self, offset_matrix, matrix):
        """ check and define the right matrix-value for the offset-matrix """

        if offset_matrix is None:
            return matrix
        return mmtrx.match_position(offset_matrix, matrix)

    @ staticmethod
    def _check_matrix(matrix):
        ''' If matrix is a Transform get its Matrix, else assume it is a Matrix '''
        try:
            return mmtrx.get_matrix(matrix, ws=True)
        except AttributeError:
            return matrix

    @ staticmethod
    def _check_rotate_order(value):
        ''' If srt is vector return its string-representation '''
        if isinstance(value, basestring):
            return ROTORDER_SWITCH[value]
        else:
            return value

    @ staticmethod
    def _get_worldscale(matrix):
        ''' Check if matrix scaling is negative '''
        scaling = mmtrx.get_axis_scaling(matrix)
        return scaling[0] * scaling[1] * scaling[2]



def create_bone_on_obj(obj, modulebuilder):
    """
    Makes the bone to be parented to the given object

    :param obj: PyNode to parent the obj to
    :param modulebuilder: A module to create the bone
    :return:
    """
    # make the namer
    namer = mname.Name(obj.name(), suffix="BONE")

    # don't make any END bones
    if namer.index == "END":
        return None

    # remove any bone tags from the namer
    if namer.tags is not None:
        new_tags = []
        old_tags = namer.tags.split("_")
        for tag in old_tags:
            if not tag.startswith("bone"):
                new_tags.append(tag)

        # if we have no tags, use None
        if new_tags:
            namer.tags = new_tags
        else:
            namer.tags = None

    # make the bone with the given modulebuilder class
    bone = modulebuilder.create_skin_joint(namer.create_name(), parent=obj, pyNode=True)
    return bone


class RigObjectChain(object):
    """
    A Rig Object Chain is designed like a standard list, but gives easier access to the RigObjects in it. Same as the
    RigObject class, there are a few properties and methods to make accessing nodes easier.
    """
    def __init__(self, rig_object=None, name=None,
                 matrices=[], parent=None, tags=None, last=True,
                 offset_matrix=None, startindex=1, flat=False, **kwargs):
        """
        Given a rig_object class, will create a chain of those rigobjects. If no object is given this will be an
        empty chain that can be populated later.

        :param rig_object: a Class inheriting from millrigger.objects.rig_object.RigObject
        :param name: The base name for the chain - indexes will be set automatically
        :param node_type: "joint" or "transform"
        :param matrices: The list of om.MMatrix transforms for the created chain
        :param parent: a parent for the chain
        :param tags: a list of tags for the names of the chain
        :param last: if True, the last index in the chain will be END
        :param offset_matrix: offset-matrix for first element in chain
        :param startindex: startindex for the first element of the chain
        :param kwargs: custom list of arguments for the rig_object class. These arguments should be in a list of the
        same length as the matrices.
        :return:
        """

        self.chain = []
        self.bones = []

        # if this is an empty chain, do nothing
        if rig_object is None:
            return

        num_objs = len(matrices)

        # make all kwargs a list, if it isn't already
        for key in kwargs:
            if isinstance(kwargs[key], list):
                continue
            kwargs[key] = self.make_value_list(kwargs[key], num_objs)

        # check the length of the kwargs:
        for key in kwargs:
            if len(kwargs[key]) != num_objs:
                raise ValueError(LENGTH_ERR_MSG % (str(key), num_objs, name))

        # make the control names
        ctrl_names = mname.create_chain_names(count=tags or num_objs, last=last,
                                              name=name, startindex=startindex,
                                              force_index=True)

        # make the controls
        self.create_objects(rig_object, ctrl_names, matrices, kwargs, parent,
                            offset_matrix=offset_matrix, flat=flat)

    def __iter__(self):
        """
        Generator function, returning all the rig objects in the chain
        """
        for obj in self.chain:
            yield obj

    def __len__(self):
        """
        :return: The length of the chain of rigobjects
        """
        return self.count()

    def __getitem__(self, item):
        """

        :param item: Int index for the rig object
        :return: RigObject
        """
        return self.chain[item]

    def append(self, rig_object, parent=True):
        """
        Adds another rig object onto the end of this chain.

        :param rig_object: a millrigger.objects.rigobject.RigObject class
        :param parent: If true, the rigobject will be parented to the chain
        """
        # try parenting the rig object
        if parent:
            try:  # only parent if there are objects to parent
                if self.top and rig_object.root:
                    rig_object.root.setParent(self.top)
            except AttributeError:
                pass

        self.chain.append(rig_object)

    def extend(self, rig_object_chain, parent=True):
        """
        Add the items in the given chain to this one

        :param rig_object_chain: a millrigger.objects.rigobject.RigObjectChain class
        :param parent: If true, the rig_object_chain will be parented to this one
        """
        if parent:
            try:  # only parent if there are objects to parent
                if self.top and rig_object_chain.root:
                    rig_object_chain.root.setParent(self.top)
            except AttributeError:
                pass

        for item in rig_object_chain:
            self.chain.append(item)

    def insert(self, index, rig_object, parent=True):
        """
        Adds another rig object onto the end of this chain.

        :param index: index of the element before which to insert
        :param rig_object: a millrigger.objects.rigobject.RigObject class
        :param parent: If true, the rigobject will be parented to the chain
        """
        # try parenting the rig object
        if parent:
            if index > 0:
                parent_obj = self.chain[index - 1]
                rig_object.set_parent(parent_obj.top)
            child_obj = self.chain[index]
            child_obj.set_parent(rig_object.top)
        self.chain.insert(index, rig_object)

    def count(self):
        """
        :return: The number of RigObjects in the chain
        """
        return len(self.chain)

    @property
    def root(self):
        """
        Returns the bottom node in the chain, usually so we can parent the chain to something

        :return: the first PyNode object in the first RigObject in the chain
        """
        hierarchy = self.hierarchy(existing=True)
        if hierarchy:
            return hierarchy[0]
        else:
            return None

    @property
    def top(self):
        """
        Returns the top node in the chain, usually so we can parent something to the end

        :return: the last PyNode object in the last RigObject in the chain
        """
        hierarchy = self.hierarchy(existing=True)
        if hierarchy:
            return hierarchy[-1]
        else:
            return None

    @property
    def roots(self):
        """
        :return: A list of all the roots in the chain
        """
        out = []
        for each in self:
            try:
                out.append(each.root)
            except AttributeError:
                continue
        return out

    @property
    def tops(self):
        """
        :return: A list of all the roots in the chain
        """
        out = []
        for each in self:
            try:
                out.append(each.top)
            except AttributeError:
                continue
        return out

    @property
    def objs(self):
        """
        :return: A list of all the roots in the chain
        """
        out = []
        for each in self:
            try:
                out.append(each.obj)
            except AttributeError:
                continue
        return out

    @property
    def cnsts(self):
        """
        :return: A list of all the roots in the chain
        """
        out = []
        for each in self:
            try:
                out.append(each.cnst)
            except AttributeError:
                continue
        return out

    @property
    def matrixsums(self):
        """
        :return: A list of all the roots in the chain
        """
        out = []
        for each in self:
            try:
                out.append(each.matrixsum)
            except AttributeError:
                continue
        return out

    def get_shapes(self):
        """
        :return: a list of all the shapes on all the RigObjects in the chain
        """
        out = []
        for rigobj in self.chain:
            out.extend(rigobj.get_shapes())
        return out

    def hierarchy(self, existing=False):
        """
        Returns a list of everything in the chain, usually so we can blend them together.

        :param existing: If true, only the existing nodes will be returned
        :return: A list of the items in each of the RigObjects in the chain
        """
        items = []
        for obj in self:
            for item in obj.hierarchy(existing=existing):
                items.append(item)
        return items

    def create_bones(self, modulebuilder):
        """
        Creates a bone object for each obj in the chain

        :param modulebuilder: a class inheriting from the base ModuleBuilder
        :return: list of joints
        """
        for obj in self:
            self.bones.append(obj.create_bone(modulebuilder))

    def create_objects(self, rig_object, ctrl_names, matrices, kwargs, parent,
                       offset_matrix=None, flat=False):
        """
        create hierarchy of rigobjects
        """
        # make the controls
        i = 0
        for ctrl_name, matrix in zip(ctrl_names, matrices):
            # get the current values for the kwargs
            tmp_kwargs = {}
            for key in kwargs:
                tmp_kwargs[key] = kwargs[key][i]

            obj = rig_object(name=ctrl_name,
                             matrix=matrix,
                             offset_matrix=offset_matrix,
                             parent=parent,
                             **tmp_kwargs)
            if not flat:
                parent = obj.top
            offset_matrix = matrix
            self.chain.append(obj)
            i += 1

    def make_dict_values_lists(self, dic, length):
        """
        Takes a dictionary and make sure all the lists are of the right list

        :param dic: The dictionary to check
        :param length: The length to ensure
        """
        for key in dic:
            dic[key] = self.make_value_list(dic[key], length)

    @ staticmethod
    def make_value_list(item, length):
        """
        Makes a list of a certain length of the item

        :param item: The item to make in the list
        :param length: How long the list needs to be
        :return: list of items
        """
        if isinstance(item, list):
            return item
        return [item] * length


class ExistingRigObject(RigObject):
    """
    Returns a RigObject if it finds it in the scene

    :param name: The basename of the control.
    :type name: String
    """

    def __init__(self, name, **kwargs):

        # Ensure name is always the Name()
        if isinstance(name, mname.Name):
            self.namer = name(add_to_tags=kwargs.get("add_to_tags"),
                              )
        else:
            self.namer = mname.Name(name,
                                    add_to_tags=kwargs.get("add_to_tags")
                                    )
        if kwargs.get("suffix"):
            self.namer.suffix = kwargs.get("suffix")
        self.name = self.namer.create_name()

        # empty class-variables for new created nodes
        self.obj = self._find_existing_node()
        if self.obj:
            self.secondary_obj = self._find_existing_node(suffix="SCND_" + self.namer.suffix)
            self.zero = self._find_existing_node(add_to_suffix='ZERO')
            self.ofs = self._find_existing_node(add_to_suffix='OFS')
            self.cnst = self._find_existing_node(add_to_suffix='CNST', add_shape=True)
            self.bone = None
            self.mtx = self._find_existing_node(add_to_suffix='MTX')
            self.parent = self.root.getParent()
            self.node_type = self.obj.type()
            self.rotate_order = self.obj.ro.get()

    def _find_existing_node(self, suffix=None, add_to_suffix=None, add_shape=False):
        # find existing node and return it or return None
        name = self.namer.replace(suffix=suffix or self.namer.suffix,
                                  add_to_suffix=add_to_suffix
                                  )
        if add_shape:
            name += "Shape"
        if objExists(name):
            return PyNode(name)


class ExistingRigObjectChain(RigObjectChain):
    """
    A Rig Object Chain is designed like a standard list, but gives easier access to the RigObjects in it. Same as the
    RigObject class, there are a few properties and methods to make accessing nodes easier.
    """
    def __init__(self, name=None, **kwargs):
        """
        Given a rig_object class, will create a chain of those rigobjects. If no object is given this will be an
        empty chain that can be populated later.

        :param rig_object: a Class inheriting from millrigger.objects.rig_object.RigObject
        :param name: The base name for the chain - indexes will be set automatically
        :param node_type: "joint" or "transform"
        :param matrices: The list of om.MMatrix transforms for the created chain
        :param parent: a parent for the chain
        :param tags: a list of tags for the names of the chain
        :param last: if True, the last index in the chain will be END
        :param offset_matrix: offset-matrix for first element in chain
        :param startindex: startindex for the first element of the chain
        :param kwargs: custom list of arguments for the rig_object class. These arguments should be in a list of the
        same length as the matrices.
        :return:
        """

        self.chain = []
        self.bones = []
        namer = mname.Name(name)
        # replace suffix if given
        if kwargs.get("suffix"):
            namer.suffix = kwargs.get("suffix")

        # make the control names
        if kwargs.get("tags"):
            # if tags are given look for matching nodes
            ctrl_names = mname.create_chain_names(count=kwargs.get("tags"),
                                                  last=kwargs.get("last"),
                                                  name=name,
                                                  startindex=kwargs.get("startindex")
                                                  )
        else:
            # find existing objects by wildcard
            wildcard = namer.wildcard("index")
            if namer.suffix == 'CTRL':
                end_obj = namer.replace(index="END", add_to_suffix='SRT')
            else:
                end_obj = namer.replace(index="END")
            ctrl_names = ls(wildcard, end_obj)

        # find the controls
        i = 0
        for ctrl_name in ctrl_names:
            obj = ExistingRigObject(ctrl_name)
            self.chain.append(obj)
            i += 1


class RigObjectChainByRoot(RigObjectChain):
    '''
    Same as RigObjectChain, but the hierarchy uses always the parent root as
    as parent and not the top.
    '''

    def create_objects(self, rig_object, ctrl_names, matrices, kwargs, parent,
                       offset_matrix=None, flat=False):
        """
        create hierarchy of rigobjects
        """
        # make the controls
        i = 0
        for ctrl_name, matrix in zip(ctrl_names, matrices):
            # get the current values for the kwargs
            tmp_kwargs = {}
            for key in kwargs:
                tmp_kwargs[key] = kwargs[key][i]

            obj = rig_object(name=ctrl_name,
                             matrix=matrix,
                             offset_matrix=offset_matrix,
                             parent=parent,
                             **tmp_kwargs)
            if not flat:
                parent = obj.root  # <<< this is the difference
            offset_matrix = matrix
            self.chain.append(obj)
            i += 1
