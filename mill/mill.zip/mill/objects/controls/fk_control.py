import control
import millrigger.objects.rigobject as rigobj
import millrigger.utils.name as mname
from millrigger.utils.nodes import utility as mutil


class FKControl(control.Control):
    """
    A Control class for creating FK Controls
    """

    def __init__(self,
                 name,
                 matrix=None,
                 offset_matrix=None,
                 size=1.0,
                 parent=None,
                 world_space=None,
                 local_space=None,
                 shape_type='circle',
                 shape_offset=None,
                 shape_aim="+x",
                 shape_up="+y",
                 lock_rot="",
                 lock_pos=True,
                 lock_scl=True,
                 keep_rotation=True,
                 shape_mirror=True,
                 rotate_order='xyz',
                 add_to_tags=None):
        """

        :param name: a string for the name of the control, 'ik' will be added as a tag
        :param matrix: the placement of the control
        :param size: the size of the control
        :param parent: the parent of the control
        :param world_space: an object to use as a reference for the world space
        :param shape_offset: a vector offset to the shape
        :param shape_aim: the axis for the shape to aim in
        :param shape_up: the axis for the shape to orient up in
        :param lock_rot: which rotation axies to lock
        :param keep_rotation: if True, the control's offset will keep the orientation of the parent
        :param add_to_tags: usually adds the "fk"-tag to the name
        :return:
        """
        namer = mname.Name(name)

        super(FKControl, self).__init__(name=namer.create_name(),
                                        matrix=matrix,
                                        offset_matrix=offset_matrix,
                                        size=size,
                                        node_type='transform',
                                        parent=parent,
                                        shape_type=shape_type,
                                        shape_aim=shape_aim,
                                        shape_up=shape_up,
                                        lock_rot=lock_rot,
                                        keep_rotation=keep_rotation,
                                        shape_mirror=shape_mirror,
                                        lock_pos=lock_pos,
                                        lock_scl=lock_scl,
                                        create_cnst=False,
                                        shape_offset=shape_offset,
                                        rotate_order=rotate_order,
                                        add_to_tags=add_to_tags
                                        )
        if world_space:
            self.create_space(tag='fk',
                              connect='r',
                              world_space=world_space,
                              local_space=local_space,
                              default='local')


class FKControlChain(rigobj.RigObjectChain):
    def __init__(self,
                 name,
                 matrices,
                 offset_matrix=None,
                 sizes=None,
                 parent=None,
                 world_space=None,
                 local_space=None,
                 shape_offsets=None,
                 shape_type='circle',
                 shape_aim="+x",
                 shape_up="+y",
                 lock_pos="xyz",
                 lock_rot="",
                 lock_scl="xyz",
                 lock_first_pos=True,
                 keep_rotation=True,
                 zero_first=False,
                 tags="",
                 last=True,
                 shape_mirror=True,
                 rotate_order='xyz',
                 add_to_tags=None,
                 make_length_offset=False):
        """

        :param name:
        :param matrices:
        :param sizes:
        :param parent:
        :param world_space:
        :param local_space:
        :param shape_offsets:
        :param shape_aim:
        :param shape_up:
        :param lock_rot:
        :param keep_rotation:
        :param zero_first:
        :param tags:
        :param last:
        :return:
        """
        num_objs = len(matrices)
        sizes = sizes or [1.0] * num_objs

        # world space will only be for the first control
        world_space_list = self.make_value_list(None, length=num_objs)
        world_space_list[0] = world_space

        # local space will only be for the first control
        local_space_list = self.make_value_list(None, length=num_objs)
        local_space_list[0] = local_space

        # some fk chains need a pos on first control
        lock_pos = self.make_value_list(lock_pos, num_objs)
        lock_pos[0] = lock_first_pos

        # first controls can always be rotated
        lock_rot = self.make_value_list(lock_rot, num_objs)
        lock_rot[0] = False

        shape_type_list = self.make_value_list(shape_type, length=num_objs)
        if last is True:
            shape_type_list[-1] = None

        keep_rotation = self.make_value_list(keep_rotation, length=num_objs)

        if zero_first:
            keep_rotation[0] = False

        # make the kwargs
        kwargs = {"size": sizes,
                  "shape_offset": shape_offsets,
                  "shape_aim": shape_aim,
                  "shape_up": shape_up,
                  "lock_rot": lock_rot,
                  "lock_pos": lock_pos,
                  "lock_scl": lock_scl,
                  "world_space": world_space_list,
                  "local_space": local_space_list,
                  "keep_rotation": keep_rotation,
                  "shape_mirror": shape_mirror,
                  "rotate_order": rotate_order,
                  "shape_type": shape_type_list
                  }
        self.make_dict_values_lists(dic=kwargs, length=num_objs)
        super(FKControlChain, self).__init__(rig_object=FKControl,
                                             name=name,
                                             matrices=matrices,
                                             offset_matrix=offset_matrix,
                                             parent=parent,
                                             tags=tags,
                                             last=last,
                                             add_to_tags=add_to_tags,
                                             **kwargs)

        if make_length_offset:
            mutil.add_length_offset(controls=self.objs[:-1], parent_roots=self.roots[1:])

    def get_bone_objects(self):
        """
        Returns a list of every bone object in the chain
        :return:
        """
        return [obj.bone_object for obj in self]
