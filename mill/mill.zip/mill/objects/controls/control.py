"""
.. module:: utils.control
   :synopsis: Creation of controls based on the millRig-standards.

.. moduleauthor:: andreasg, ren, fabiane, petera
"""

import math

# maya imports
import pymel.core as pm
import maya.api.OpenMaya as om

# package imports
from millrigger.globals.color import CTRL_COLORS
from millrigger.globals.rig import NEG_SWITCH, STR_TO_VEC_SWITCH
from millrigger.utils import name as mname
from millrigger.utils import shape as mshape
from millrigger.utils import attributes as mattr
from millrigger.utils import matrix as mmtrx
from millrigger.utils import space as mspc
from millrigger.utils.nodes import constraints as mcon
from millrigger.utils.nodes import pairblend as mpblnd
from millrigger.utils.nodes import utility as mutil
import millrigger.objects.rigobject as rigobj

ZERO_VEC = mmtrx.get_as_mvector([0, 0, 0])


class Control(rigobj.RigObject):
    '''Creates a control object for animated controls

    :param name: The basename of the control.
    :type name: String

    :param suffix: The suffix of the control.
    :type suffix: String

    :param node_type: "joint" or "transform".
    :type node_type: String

    :param matrix: matrix or transform-node to match else "None".
    :type matrix: MMatrix or Transform

    :param offset_matrix: matrix or transform-node to match else "None".
    :type offset_matrix: MMatrix or Transform

    :param rotate_order: Default is 'xyz'.
    :type rotate_order: String

    :param parent: If given, the zero-node will be parented to this transform.
    :type parent: Transform

    :param create_zero: Add a zero-transform to the hierarchy
    :type create_zero: Boolean

    :param create_ofs: Add a ofs-transform to the hierarchy
    :type create_ofs: Boolean

    :param create_secondary: Add a secondary-transform as child the the main object
    :type create_secondary: Boolean

    :param create_cnst: Add a locator child for constraints
    :type create_cnst: Boolean

    :param keep_rotation: preserve the rotationvalues of the control.
    :type keep_rotation: Boolean

    :param shape_type: Predefined shape imported from library.
                       If value is None: Suffix will be "CTRL_SRT"
                       and no ctrlShape is used
    :type shape_type: String

    :param size: Scaling-factor of standard sized controlShape (1 Unit).
    :type size: float/Tuple/List/MVector

    :param color: Indexcolor-value of type integer.
    :type color: int

    :param shape_aim: The facing direction for the shape
    :type shape_aim: +x/+y/+z/-x/-y/-z

    :param shape_up: The up direction for the shape
    :type shape_up: +x/+y/+z/-x/-y/-z

    :param shape_offset: The offset for the shape
    :type shape_offset: Vector/Tuple/List

    :param shape_mirror: mirrors shape for if side == "R". Default value: False
    :type shape_mirror: Boolean

    :param lock_pos: The transform axies to lock, "xyz" will lock everything
    :type lock_pos: String

    .. note::
        The used control-shape needs to be 1 Unit in size and
        needs to be aligned with Y-axis

    '''
    def __init__(self, name,
                 node_type='transform',
                 matrix=None,
                 offset_matrix=None,
                 rotate_order='xyz',
                 parent=None,
                 create_zero=True,
                 create_ofs=True,
                 create_secondary=False,
                 create_cnst=False,
                 create_mtx=False,
                 keep_rotation=True,
                 add_to_tags=None,
                 shape_type='circle',
                 shape_type2=None,
                 shape_aim='+x',
                 shape_up='+y',
                 shape_offset=None,
                 shape_offset2=None,
                 shape_mirror=False,
                 size=1.0,
                 color=None,
                 lock_pos="",
                 lock_rot="",
                 lock_scl="",
                 mirror_mode='ROTATE'
                 ):
        """ store all the attributes and build the control """

        # if the control has no shape, a secondary control is redundant
        if shape_type is None:
            create_secondary = False

        super(Control, self).__init__(name=name,
                                      node_type=node_type,
                                      matrix=matrix,
                                      offset_matrix=offset_matrix,
                                      rotate_order=rotate_order,
                                      parent=parent,
                                      create_zero=create_zero,
                                      create_ofs=create_ofs,
                                      create_secondary=create_secondary,
                                      create_cnst=create_cnst,
                                      create_mtx=create_mtx,
                                      keep_rotation=keep_rotation,
                                      suffix='CTRL',
                                      add_to_tags=add_to_tags)
        self.bone_object = None

        # user input
        self.side = self.namer.side[0]  # only care about the first letter
        self.shape_type = shape_type
        self.color = color
        self.size = size
        self.shape_aim = shape_aim
        self.shape_up = shape_up
        self.shape_mirror = shape_mirror
        self.shape_offset = self._check_shapeoffset(shape_offset) / size
        if shape_mirror and self.side == "R":
            self.shape_offset *= -1
        self.space = None

        # check colors
        if isinstance(color, basestring):
            try:
                self.color = CTRL_COLORS[color][0]
            except KeyError:
                pm.warning("'%s' isn't a valid colour, should be one of %s" % (color, str(CTRL_COLORS.keys())))
                color = None
        if not color:
            self.color = CTRL_COLORS[self.side][0]

        # check for attr locks
        self.lock_pos = self._check_lock(lock_pos)
        self.lock_rot = self._check_lock(lock_rot)
        self.lock_scl = self._check_lock(lock_scl)

        # create shape for control
        self.shape = self._add_shape_to_ctrl(self.obj, mult_size=1.0,
                                             shape_type=self.shape_type,
                                             shape_offset=self.shape_offset)

        # set mirror-mode
        if self.obj.name().endswith("_CTRL"):
            mattr.add_mirror_behaviour_attr(self.obj, default=mirror_mode)

        # lock attributes
        mattr.lock_hide_axis(self.obj, self.lock_pos, self.lock_rot, self.lock_scl)

        # rename if not a control
        if not self.is_ctrl():
            self.obj.rename(self.namer.replace(suffix='CTRL_SRT'))
        self.obj.visibility.set(l=True, k=False)

        # create shape for secondary control and lock attributes
        self.secondary_shape = None
        if self.secondary_obj is not None:
            if shape_type2:
                mult_size = 1.0
            else:
                mult_size = 1.5
                shape_type2 = self.shape_type
            self.secondary_shape = self._add_shape_to_ctrl(self.secondary_obj,
                                                           mult_size=mult_size,
                                                           shape_type=shape_type2,
                                                           shape_offset=self._check_shapeoffset(shape_offset2) / size)
            self.drive_visibility(driver=self.obj,
                                  default=shape_type2 != self.shape_type,
                                  secondary=True,
                                  attr_name="secondaryVisibility"
                                  )
            self.secondary_obj.visibility.set(l=True, k=False)
            mattr.lock_hide_axis(self.secondary_obj, self.lock_pos, self.lock_rot, self.lock_scl)
            self.secondary_obj.rotateOrder.set(k=False)

        # set the ctrl rotateOrder, then link the others to it
        self.obj.rotateOrder.set(self.rotate_order)
        if self.zero is not None:
            self.obj.rotateOrder >> self.zero.rotateOrder
        if self.ofs is not None:
            self.obj.rotateOrder >> self.ofs.rotateOrder
        if self.secondary_obj is not None:
            self.obj.rotateOrder >> self.secondary_obj.rotateOrder

        # for cosmetic reasons
        self.ctrl = self.obj
        self.secondary_ctrl = self.secondary_obj

        # # and for practical reasons (also mark as MillRig-control)
        # if self.ctrl:
        #     add_to_ctrlset(self.ctrl)
        #     mattr.add_millrigcontrol_attr(self.ctrl)
        # if self.secondary_ctrl:
        #     add_to_ctrlset(self.secondary_ctrl)
        #     mattr.add_millrigcontrol_attr(self.secondary_ctrl)

        # store the bind pose
        self.set_bindpose()

    def create_bone(self, modulebuilder):
        """
        Creates and parents a bone to itself for a module builder

        :param modulebuilder:
        :return:list of joints
        """
        self.bone_object = pm.createNode("transform",
                                         n=self.namer.replace(add_to_tags="bone", suffix="SRT")
                                         )
        mcon.create_simple_constraint(source=self.top, target=self.bone_object)
        self.bone = rigobj.create_bone_on_obj(obj=self.bone_object, modulebuilder=modulebuilder)
        return self.bone

    def zero_transforms(self):
        """
        Have the control ofs and zeros match the control transformation
        :return:
        """
        ctrl_matrix = mmtrx.get_matrix(self.obj)
        if self.zero:
            mmtrx.set_matrix(self.zero, ctrl_matrix)
        if self.ofs:
            mmtrx.set_matrix(self.ofs, ctrl_matrix)
        mmtrx.set_matrix(self.obj, ctrl_matrix)

    def replace_shape(self, shape_type, secondary=False, mult_size=1.0, aim=None, up=None):
        """
        replace existing shape with a new shape_type
        """
        ctrl = self.secondary_obj if secondary is True else self.obj
        shape = ctrl.getShape(type='nurbsCurve')
        aim = aim or self.shape_aim
        up = up or self.shape_up

        if self.side == 'R' and self.shape_mirror is True:
            aim = NEG_SWITCH[aim]
            up = NEG_SWITCH[up]

        size = self.size * mult_size
        tmp_shape = mshape.create_nurbscurve(shape_type,
                                             parent=ctrl,
                                             color=self.color,
                                             size=size,
                                             aim=aim,
                                             up=up)
        tmp_shape.worldSpace >> shape.create
        pm.refresh()
        pm.delete(tmp_shape)
        return shape

    def _add_shape_to_ctrl(self, ctrl, mult_size=1.0,
                           shape_type=None, shape_offset=ZERO_VEC):
        """
        Takes a control and adds the shape to it

        :param ctrl:
        :return:
        """
        if self.shape_type is None or self.namer.index == 'END':
            return

        # mirror control shape for right side
        if self.side == 'R' and self.shape_mirror is True:
            self.shape_aim = NEG_SWITCH[self.shape_aim]
            self.shape_up = NEG_SWITCH[self.shape_up]

        size = self.size * mult_size

        shape = mshape.create_nurbscurve(shape_type, parent=ctrl,
                                         color=self.color, size=size,
                                         aim=self.shape_aim, up=self.shape_up,
                                         offset=shape_offset)
        return shape

    def _get_offset_matrix(self, offset_matrix, matrix):
        """ check and define the right matrix-value for the offset-matrix """

        if offset_matrix is None:
            return matrix
#         if self.keep_rotation is False and self.node_type != 'joint':
#             # ignore it for the moment and deal with it later
#             return self.matrix
        return mmtrx.match_position(offset_matrix, matrix)

    @ staticmethod
    def _check_lock(value):
        ''' check and set the right value for the locked-axis '''
        if isinstance(value, bool):
            if value:
                value = "xyz"
            else:
                value = ""
        elif isinstance(value, str):
            value = value.lower()
        else:
            value = ""
        return value

    def _create_offset_matrix(self, offset_matrix, matrix):
        ''' create an orientationmatrix for joints '''
        if offset_matrix is None:
            return mmtrx.match_position(om.MMatrix(), matrix)
        else:
            return mmtrx.match_position(self._check_matrix(offset_matrix), matrix)

    def create_space(self, attr_obj=None, tag='ik', connect='rt',
                     world_space=None, local_space=None,
                     world_attr='world', local_attr='local',
                     nice_name=None,
                     follow_obj=None, default=None, make_custom=None):
        """

        :param attr_obj:
        :param tag:
        :param connect:
        :param world_space:
        :param local_space:
        :param world_attr:
        :param local_attr:
        :param default:
        :return:
        """

        self.space = mspc.Space(self,
                                attr_obj=attr_obj,
                                tag=tag,
                                connect=connect,
                                world_space=world_space,
                                local_space=local_space,
                                world_attr=world_attr,
                                local_attr=local_attr,
                                make_custom=make_custom or tag not in ['fk', 'pole'],
                                follow_obj=follow_obj,
                                default=default or local_attr,
                                rotate_order=self.obj.rotateOrder,
                                nice_name=nice_name
                                )

    def create_aim_space(self, aim_target, blend=None, aim="+x", up="+y", pole_obj=None, axis_obj=None, axis_aim="+y",
                         snap=False):
        """
        Creates a blended aim space. As opposed to the regular space, and aimer is a float
        blend rather than a choice

        :param aim_target: The driving transform to aim at
        :param blend: the attribute to drive the switch (if None given it'll be created)
        :param aim: aim vector of the constraint
        :param up: up vector of the constraint
        :param pole_obj:  A transform to act as a pole for the constraint
        :param axis_obj: A transform to act as a Object Up Rotation for the constraint
        :param axis_aim: The vector to use for the Object Up
        :param snap: Whether to snap the constraint to the aim_target
        :return:
        """
        if blend is None:
            blend = mattr.add_aim_attr(self.obj)

        # make an aim transform an constrain it
        self.aim_transform = pm.createNode('transform',
                                           name=self.namer.replace(add_to_tags='aim',
                                                                   suffix='SPC'
                                                                   ),
                                           parent=self.zero
                                           )
        mmtrx.set_matrix(self.aim_transform, mmtrx.get_matrix(self.ofs))

        # if we aren't given a pole or an axis aim obj, use the aim target as the axis obj
        if pole_obj is None and axis_obj is None:
            axis_obj = aim_target
        mcon.create_aim_constraint(source=aim_target,
                                   target=self.aim_transform,
                                   aim=aim,
                                   up=up,
                                   pole_obj=pole_obj,
                                   axis_obj=axis_obj,
                                   axis_aim=axis_aim,
                                   snap=snap
                                   )

        # make a static transform to blend with
        self.aim_blend_transform = pm.createNode('transform',
                                                 name=self.namer.replace(add_to_tags='blend',
                                                                         suffix='SPC'
                                                                         ),
                                                 parent=self.zero
                                                 )
        mmtrx.set_matrix(self.aim_blend_transform, mmtrx.get_matrix(self.ofs))

        # connect an existing space to the blend transform
        if self.space is not None:
            blend_node = self.space.matrix_blend.node
            blend_node.outTranslate >> self.aim_blend_transform.translate
            blend_node.outRotate >> self.aim_blend_transform.rotate

        # create pairblend for aim
        self.aim_pairblend = mpblnd.PairBlend(source1=self.aim_blend_transform,
                                              source2=self.aim_transform,
                                              target=self.ofs,
                                              weight=blend,
                                              connect="r"
                                              )

    def drive_visibility(self, driver, default=1.0, secondary=False, attr_name=None):
        """
        Drives the visibility of the control shape

        :param driver: If an attribute, drives the visibility directly. If a transform, give it
                       an attribute and use that to drive.
        :param default: The default value for the visibility
        :return:
        """
        if secondary:
            shape = self.secondary_shape
        else:
            shape = self.shape

        if shape:
            mshape.drive_visibility(shapes=shape,
                                    driver=driver,
                                    default=default,
                                    attr_name=attr_name
                                    )

    def set_bindpose(self):
        '''
        add "millPose"-attribute and set it.
        '''
        if self.is_ctrl():
            mattr.store_pose(self.ctrl, pose_name='bindPose')
            if self.secondary_ctrl:
                mattr.store_pose(self.secondary_ctrl, pose_name='bindPose')

    def is_ctrl(self):
        return self.shape_type is not None or self.namer.index != 'END'

    def _check_shapeoffset(self, val, aim_axis='+x'):
        if isinstance(val, float):
            return mmtrx.get_as_mvector(STR_TO_VEC_SWITCH[aim_axis]) * val
        elif isinstance(val, (tuple, list)):
            return mmtrx.get_as_mvector(val)
        elif isinstance(val, om.MVector):
            return val
        else:
            return mmtrx.get_as_mvector((0, 0, 0))


class ControlChain(rigobj.RigObjectChain):
    def __init__(self, name, matrices, parent=None, tags="", last=False,
                 keep_rotation=True, zero_first=False,
                 make_length_offset=False, **kwargs):
        """

        :param name:
        :param matrices:
        :param last:
        :param keep_rotation:
        :param shape_type:
        :param zero_first:
        :param kwargs:
        :return:
        """
        num_objs = len(matrices)

        # override in case we want only the first control zeroed
        keep_rotation = self.make_value_list(keep_rotation, num_objs)
        if zero_first:
            keep_rotation[0] = False
        kwargs["keep_rotation"] = keep_rotation

        super(ControlChain, self).__init__(Control,
                                           name=name,
                                           matrices=matrices,
                                           parent=parent,
                                           tags=tags,
                                           last=last,
                                           **kwargs)

        if make_length_offset:
            mutil.add_length_offset(controls=self.objs[:-1], parent_roots=self.roots[1:])

    def set_bindpose(self):
        for each in self.chain:
            each.set_bindpose()

    def get_bone_objects(self):
        """
        Returns a list of every bone object in the chain
        :return:
        """
        return [obj.bone_object for obj in self]


def create_shared_ctrl(ctrls, name='C_generic_SHARED_CTRL', shared=None):
    ''' Creates an instanced locatorshape on all given controls for use as a shared-ctrl

    :params name: name of shared ctrl (will always end with "SHARED_CTRL" by default)
    :type base_name: String

    :params ctrls: list of the controls to get the shared-ctrl-shape
    :type ctrls: list of PyNode-transforms

    :params shared: workflow-option to use an existing shared-ctrl
    :type shared: PyNode

    :rType: Pynode
    '''
    namer = mname.Name(name)

    # check for rigobjects and use their main obj if available
    for i, ctrl in enumerate(ctrls):
        try:
            c = ctrl.obj
        except AttributeError:
            c = ctrl
        ctrls[i] = c

    if shared is None:
        shared_name = namer.replace(suffix="SHARED_CTRL")
        if pm.objExists(shared_name):
            shared = pm.PyNode(shared_name)
        else:
            shared = pm.createNode('locator',
                                   parent=ctrls[0],
                                   name=shared_name
                                   )
            ctrls = ctrls[1:]

    for ctrl in ctrls:
        pm.parent(shared, ctrl, s=True, add=True)

    shared.v.set(False)
    shared.localPositionX.set(cb=False)
    shared.localPositionY.set(cb=False)
    shared.localPositionZ.set(cb=False)
    shared.localScaleX.set(cb=False)
    shared.localScaleY.set(cb=False)
    shared.localScaleZ.set(cb=False)

    add_to_ctrlset(shared)
    return shared


def match_ofs_to_matrix(ctrl_obj, matrix=None, x_axis=None, y_axis=None,
                        z_axis=None, euler_offset=[0, 0, 0]):
    """
    Matches a control's offset to a given matrix. Sometimes an ofs will be in
    a different orientation space than the matrix, so you can swap the axies
    with arguments. At least two of these axies need to be given

    For example, if you set x_axis="+y" and y_axis="-x", then the x-axis of the
    ofs will face the y axis of the matrix (i.e., the second row of the matrix),
    then it's y axis will face the negative x of the matrix (so the first row of
    the matrix multiplied by -1 to invert it). The z axis can either be given,
    or can be calculated with a cross product.

    If an additional offset is needed, then you can give an eular offset value.
    This can be useful for some mirroring techniques, for example.

    :params ctrl_obj: The control obj whose ofs we want to change
    :type ctrl_obj: PyNode

    :params matrix: The matrix to match
    :type matrix: MMatrix

    :params x_axis: for the ctrl's ofs, the axis from the matrix to use for x
    :type x_axis: string

    :params y_axis: for the ctrl's ofs, the axis from the matrix to use for y
    :type y_axis: string

    :params z_axis: for the ctrl's ofs, the axis from the matrix to use for z
    :type z_axis: string

    :params euler_offset: an eular offset for the ofs
    :type euler_offset: list of floats

    :rType: PyNode
    """
    # get the offset
    try:  # check for rigobjects
        zero = ctrl_obj.zero
        spc = ctrl_obj.spc
        ofs = ctrl_obj.ofs
        ctrl = ctrl_obj.obj
    except AttributeError:
        ctrl = ctrl_obj
        ofs = ctrl_obj.getParent()
        par = ofs.getParent()
        if par.name().endswith("ZERO"):
            spc = None
            zero = par
        else:
            spc = par
            zero = spc.getParent()

    # get the current matrix
    ctrl_matrix = mmtrx.get_matrix(ctrl)

    # add in the eular offset
    euler_matrix = om.MTransformationMatrix()
    euler = om.MEulerRotation()
    euler.setValue(math.radians(euler_offset[0]),
                   math.radians(euler_offset[1]),
                   math.radians(euler_offset[2])
                   )
    euler_matrix.rotateBy(euler, om.MSpace.kTransform)

    # set the zero and ofs
    offset_matrix = euler_matrix.asMatrix() * mmtrx.get_match_matrix_from_axies(matrix, x_axis, y_axis, z_axis)
    mmtrx.set_matrix(zero, offset_matrix)
    if spc:
        mmtrx.set_matrix(spc, offset_matrix)
        spc_inputs = spc.r.inputs(t="millMatrixBlend")
        # check to see whether there's a space and, if so, set the first matrix
        if spc_inputs:
            spc_inputs[0].inMatrix1.set(om.MMatrix())

    mmtrx.set_matrix(ofs, offset_matrix)

    # reset the control
    mmtrx.set_matrix(ctrl, ctrl_matrix)

    # find world_space transform
    world_space = [node for node in zero.getChildren() if node.name().endswith("world_SPACE")]
    if not world_space:
        return
    world_space = world_space[0]

    # find world_space constraint
    msc_con = world_space.r.inputs()
    if not msc_con:
        return
    msc_con = msc_con[0]
    rot = mmtrx.get_offset_rotation(mmtrx.get_matrix(zero))
    msc_con.rotateOffset.set(rot)
    return


def add_to_ctrlset(ctrl):
    '''
        if an existing "CONTROLS"-set is found the control will be added
    '''
    if pm.objExists('CONTROLS'):
        pm.sets('CONTROLS', forceElement=ctrl)
