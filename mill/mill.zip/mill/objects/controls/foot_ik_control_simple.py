import millrigger.objects.controls.control as mctrl
import millrigger.utils.fkik as mfkik
import millrigger.utils.name as mname
import millrigger.utils.attributes as mattr
import maya.api.OpenMaya as om
from pymel.core import createNode


class FootIkControlSimple(mctrl.Control):
    """

    """

    def __init__(self, name, foot_matrix, ball_matrix, inner_pivot_matrix, outer_pivot_matrix, front_pivot_matrix,
                 back_pivot_matrix, ankle_matrix, foot_size=1.0, toe_size=1.0, parent=None, world_space=None,
                 toe_part_name="toes", toe_offset=None, create_ctrls=False,
                 create_ankle_ctrl=False, create_floor_contact=False):

        self.name = name
        self.namer = mname.Name(name, add_to_tags='ik')

        super(FootIkControlSimple, self).__init__(self.namer.create_name(),
                                                  shape_type='square',
                                                  node_type='joint',
                                                  matrix=foot_matrix,
                                                  keep_rotation=False,
                                                  size=foot_size,
                                                  rotate_order="xyz",
                                                  parent=parent,
                                                  shape_aim='+y',
                                                  shape_up='+z',
                                                  shape_mirror=False,
                                                  lock_scl="xyz",
                                                  create_cnst=True,
                                                  offset_matrix=om.MMatrix(),
                                                  mirror_mode="NONE",
                                                  create_secondary=True
                                                  )

        mattr.add_footroll_visibility_attr(self.obj,
                                           controls=create_ctrls,
                                           ankle=create_ankle_ctrl,
                                           floor=create_floor_contact)

        self.twist_offset = mattr.add_twist_offset_attr(self.ctrl)
        if world_space:
            self.create_space(tag='ik', connect='rt', world_space=world_space, local_space=None, default='world')

        # make the footroll
        if create_ctrls:
            self.footroll = mfkik.create_footroll_ctrls(ctrl=self.obj,
                                                        inner_matrix=inner_pivot_matrix,
                                                        outer_matrix=outer_pivot_matrix,
                                                        ball_matrix=ball_matrix,
                                                        front_matrix=front_pivot_matrix,
                                                        back_matrix=back_pivot_matrix,
                                                        ankle_matrix=ankle_matrix,
                                                        create_ankle_ctrl=create_ankle_ctrl
                                                        )
        else:
            self.footroll = mfkik.create_footroll(ctrl=self.obj,
                                                  inner_matrix=inner_pivot_matrix,
                                                  outer_matrix=outer_pivot_matrix,
                                                  ball_matrix=ball_matrix,
                                                  front_matrix=front_pivot_matrix,
                                                  back_matrix=back_pivot_matrix,
                                                  ankle_matrix=ankle_matrix,
                                                  create_ankle_ctrl=create_ankle_ctrl
                                                  )

        # put the shape on the floor
        mfkik.set_footroll_ctrl_shape(self.obj,
                                      foot_matrix=foot_matrix,
                                      inner_matrix=inner_pivot_matrix,
                                      outer_matrix=outer_pivot_matrix,
                                      front_matrix=front_pivot_matrix,
                                      back_matrix=back_pivot_matrix
                                      )

        self.cnst = self.footroll.cnst
        self.toes_ctrl = mctrl.Control(self.namer.replace(part=toe_part_name),
                                       shape_type='toes',
                                       node_type='transform',
                                       matrix=ball_matrix,
                                       keep_rotation=False,
                                       size=toe_size,
                                       parent=self.footroll.toes.top,
                                       shape_aim='+y',
                                       shape_up='+z',
                                       shape_mirror=False,
                                       lock_pos="xyz",
                                       lock_rot="",
                                       lock_scl="xyz",
                                       create_cnst=False,
                                       shape_offset=toe_offset,
                                       mirror_mode="NONE"
                                       )
        if create_floor_contact:
            self._add_floor_ctrl(world_space=world_space)

        mattr.store_pose(self.ctrl)

    # our top node should be the ankle
    @ property
    def top(self):
        try:
            return self.footroll.ankle.top
        except AttributeError:
            reverse_flat = self.hierarchy(existing=True)
            reverse_flat.reverse()
            for item in reverse_flat:
                if item is not None:
                    return item

    def _add_floor_ctrl(self, world_space=None):
        """
        create simple control to use a floor-contact

        :param foot_ik_ctrl:
        :return:
        """
        ctrl = mctrl.Control(name=self.namer.replace(tags='floor'),
                             matrix=self.matrix,
                             parent=world_space,
                             keep_rotation=False,
                             size=self.size,
                             shape_type="square",
                             shape_aim="+y",
                             shape_up="+z",
                             lock_scl="xyz",
                             lock_rot="xyz",
                             lock_pos="xz",
                             create_ofs=False,
                             create_cnst=True
                             )
        ctrl.root.t.unlock()
        ctrl.root.tx.unlock()
        ctrl.root.ty.unlock()
        ctrl.root.tz.unlock()
        mpmm = createNode("pointMatrixMult", name=ctrl.namer.replace(suffix="MPMM"))
        self.cnst.worldPosition >> mpmm.inPoint
        world_space.worldInverseMatrix >> mpmm.inMatrix

        mpmm.ox >> ctrl.root.tx
        mpmm.oz >> ctrl.root.tz
        ctrl.root.ty.set(0)
        mattr.add_visibility_attr(self.obj, [ctrl.obj],
                                  name="floorVis",
                                  default=0,
                                  connect=True)
        return ctrl

def _get_vectors_from_shape(shape):
    """
    Gets all the vectors from a shape as a list of MVectors
    :param shape:
    :return:
    """
    out = []
    for cv in shape.comp('cv'):
        out.append(om.MVector(cv.getPosition()))
    return out


def _set_vectors_in_shape(shape, vectors):
    for cv, v in zip(shape.comp('cv'), vectors):
        cv.setPosition([v.x, v.y, v.z], space="preTransform")
    shape.updateCurve()
