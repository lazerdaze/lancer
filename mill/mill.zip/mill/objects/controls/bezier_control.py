"""
.. module:: utils.control
   :synopsis: Creation of controls based on the millRig-standards.

.. moduleauthor:: andreasg
"""

from copy import copy
# maya imports
from pymel.core import createNode

# package imports
from millrigger.objects.controls import control as mctrl
from millrigger.utils import matrix as mmtrx

class BezierControl(mctrl.Control):
    """Creates a control object for animated controls

    :param name: The basename of the control.
    :type name: String

    :param matrix: matrix or transform-node to match else "None".
    :type matrix: MMatrix or Transform

    :param rotate_order: Default is 'xyz'.
    :type rotate_order: String

    :param parent: If given, the zero-node will be parented to this transform.
    :type parent: Transform

    :param create_ofs: Add a ofs-transform to the hierarchy
    :type create_ofs: Boolean

    :param create_cnst: Add a locator child for constraints
    :type create_cnst: Boolean

    :param shape_type: Predefined shape imported from library.
                       If value is None: Suffix will be "CTRL_SRT"
                       and no ctrlShape is used
    :type shape_type: String

    :param size: Scaling-factor of standard sized controlShape (1 Unit).
    :type size: float/Tuple/List/MVector

    :param color: Indexcolor-value of type integer.
    :type color: int

    :param shape_aim: The facing direction for the shape
    :type shape_aim: +x/+y/+z/-x/-y/-z

    :param shape_up: The up direction for the shape
    :type shape_up: +x/+y/+z/-x/-y/-z

    :param shape_offset: The offset for the shape
    :type shape_offset: Vector/Tuple/List

    :param shape_mirror: mirrors shape for if side == "R". Default value: False
    :type shape_mirror: Boolean

    :param lock_pos: The transform axies to lock, "xyz" will lock everything
    :type lock_pos: String

    .. note::
        The used control-shape needs to be 1 Unit in size and
        needs to be aligned with Y-axis

    """

    def __init__(self, name,
                 matrix=None,
                 rotate_order='xyz',
                 parent=None,
                 create_ofs=True,
                 create_cnst=False,
                 add_to_tags=None,
                 shape_type='facialMain',
                 shape_aim='+x',
                 shape_up='+y',
                 shape_offset=None,
                 shape_mirror=False,
                 size=1.0,
                 color=None,
                 lock_pos="",
                 lock_rot="",
                 lock_scl=""
                 ):

        self.mirror = None  # prepare for creation

        super(BezierControl, self).__init__(name=name,
                                            node_type="transform",
                                            matrix=matrix,
                                            rotate_order=rotate_order,
                                            parent=parent,
                                            create_zero=True,
                                            create_ofs=create_ofs,
                                            create_secondary=False,
                                            create_cnst=create_cnst,
                                            create_mtx=True,
                                            keep_rotation=False,
                                            add_to_tags=add_to_tags,
                                            shape_type=shape_type,
                                            shape_aim=shape_aim,
                                            shape_up=shape_up,
                                            shape_offset=shape_offset,
                                            shape_mirror=shape_mirror,
                                            size=size,
                                            color=color,
                                            lock_pos=lock_pos,
                                            lock_rot=lock_rot,
                                            lock_scl=lock_scl,
                                            mirror_mode="FULL"
                                            )

    def build(self, ofs=True, cnst=False, **kwargs):
        """
        create hierarchy
        """
        parent = self.parent

        # if negative scaling is detected, make the matrix positive
        if self._get_worldscale(self.matrix) < 0:
            self.matrix = mmtrx.clean_scale(self.matrix)

        # create zero
        self.create_zero(parent)
        parent = self.zero

        # create mirror
        if self.namer.side[0] == "R":
            self.create_mirror(parent)
            parent = self.mirror

        # create ofs
        if ofs:
            self.create_ofs(parent)
            parent = self.ofs

        # make the main srt
        parent = self.create_obj(parent)

        self.create_mtx(parent, False)  # ignore clean_worldscale!

        # set mirror behaviour to whole hierarchy
        if self.mirror:
            self.mirror.sx.set(-1)
            self.mirror.s.lock()
            self.mirror.r.lock()
            self.mirror.t.lock()
            self.mtx.sx.set(-1)

        if cnst:
            self.cnst = createNode('locator',
                                   name=self.namer.replace(add_to_suffix='CNST') + 'Shape',
                                   parent=self.top
                                   )
            self.cnst.visibility.set(False)

    def create_mirror(self, parent=None):
        """ create and return offset-node"""
        self.mirror = self._create_transform(parent=parent,
                                             matrix=self.matrix,
                                             add_to_suffix='MIRROR')
        return self.mirror

    def hierarchy(self, existing=False):
        """
        Returns the nodes in this object. By default it will return the items that aren't there as well.
        This is so that blend functions can do so, even with objects
        :param existing: If true, only the existing nodes will be returned
        :return: a list of the items in the object
        """
        items = [self.zero, self.mirror, self.ofs, self.obj]
        if existing:
            return [item for item in items if item is not None]
        else:
            return items

