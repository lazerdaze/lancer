import control
import millrigger.utils.space as mspace
import millrigger.utils.name as mname


class HeadControl(control.Control):
    """
    A Control class for creating pole vector controls
    """
    def __init__(self, name, matrix=None, size=1.0, parent=None, world_space=None, chest_space=None):
        """

        :param name: a string for the name of the control, 'ik' will be added as a tag
        :param matrix: the placement of the matrix
        :param size: the size of the control
        :param parent: the parent of the control
        :param world_space: an object to use as a reference for the world space
        :param follow_obj: an object for the pole vector to follow
        :return:
        """
        namer = mname.Name(name)

        super(HeadControl, self).__init__(name=namer.create_name(),
                                          matrix=matrix,
                                          size=size,
                                          parent=parent,
                                          shape_type='head_aim',
                                          node_type='joint',
                                          keep_rotation=False,
                                          rotate_order='xyz',
                                          color=None,
                                          shape_aim='+z',
                                          shape_up='+y',
                                          shape_mirror=True,
                                          lock_pos="",
                                          lock_rot="",
                                          lock_scl="xyz",
                                          create_cnst=True,
                                          create_secondary=True
                                          )
        if world_space or chest_space:
            space_drivers = []
            space_tags = []

            if world_space:
                space_drivers.append(world_space)
                space_tags.append("world")
            if chest_space:
                space_drivers.append(chest_space)
                space_tags.append("chest")

            mspace.create_channel_spaces(self,
                                         space_drivers=space_drivers,
                                         space_tags=space_tags,
                                         connect='rt',
                                         separate_channels=True,
                                         create_custom_space=True,
                                         default_tag=None
                                         )
