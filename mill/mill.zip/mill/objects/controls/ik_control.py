import control
import millrigger.utils.name as mname


class IKControl(control.Control):
    """
    A Control class for creating pole vector controls
    """
    def __init__(self, name,
                 matrix=None,
                 offset_matrix=None,
                 size=1.0,
                 parent=None,
                 world_space=None,
                 local_space=None,
                 shape_type='hand',
                 node_type='joint',
                 keep_rotation=False,
                 rotate_order='xyz',
                 shape_aim='+x',
                 shape_up='+y',
                 shape_offset=None,
                 shape_mirror=False,
                 lock_pos="",
                 lock_rot="",
                 lock_scl="xyz",
                 create_cnst=True,
                 create_secondary=True,
                 shape_type2=None,
                 mirror_mode="ROTATE",
                 default_worldspace='world'):
        """

        :param name: a string for the name of the control, 'ik' will be added as a tag
        :param matrix: the placement of the matrix
        :param size: the size of the control
        :param parent: the parent of the control
        :param world_space: an object to use as a reference for the world space
        :param shape_type: controls-shape-type
        :param node_type: valid are 'transform' or 'joint'
        :param create_secondary: option to create a secondary control as child of the control
        :param shape_offset2: offset for secondary shape
        :return:
        """
        namer = mname.Name(name, add_to_tags="ik")
        super(IKControl, self).__init__(name=namer.create_name(),
                                        matrix=matrix,
                                        offset_matrix=offset_matrix,
                                        size=size,
                                        parent=parent,
                                        shape_type=shape_type,
                                        node_type=node_type,
                                        keep_rotation=keep_rotation,
                                        rotate_order=rotate_order,
                                        color=None,
                                        shape_aim=shape_aim,
                                        shape_up=shape_up,
                                        shape_offset=shape_offset,
                                        shape_mirror=shape_mirror,
                                        lock_pos=lock_pos,
                                        lock_rot=lock_rot,
                                        lock_scl=lock_scl,
                                        create_cnst=create_cnst,
                                        create_secondary=create_secondary,
                                        shape_type2=shape_type2,
                                        mirror_mode=mirror_mode
                                        )

        if world_space:
            self.create_space(tag='ik',
                              connect='rt',
                              world_space=world_space,
                              local_space=local_space,
                              default=default_worldspace)
