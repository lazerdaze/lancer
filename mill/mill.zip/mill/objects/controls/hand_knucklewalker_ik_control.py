import control
import millrigger.utils.name as mname
import millrigger.utils.attributes as mattr
import maya.api.OpenMaya as om


class HandKnuckleWalkerIKControl(control.Control):
    """
    A Control class for creating pole vector controls
    """
    def __init__(self, name, matrix, knuckle_matrix, size=1.0, parent=None, world_space=None):
        """

        :param name: a string for the name of the control, 'ik' will be added as a tag
        :param matrix: the placement of the matrix
        :param size: the size of the control
        :param parent: the parent of the control
        :param world_space: an object to use as a reference for the world space
        :param follow_obj: an object for the pole vector to follow
        :return:
        """
        self.knuckle_offset = None
        self.wrist_offset = None

        namer = mname.Name(name, add_to_tags="ik")

        shape_offset = om.MVector(0, -size, 0)
        knuckle_offset = om.MVector(0, -size * 3, 0)
        wrist_offset = om.MVector(-size, -size * 2.5, 0)
        if namer.side == "R":
            shape_offset *= -1
            knuckle_offset *= -1
            wrist_offset *= -1

        super(HandKnuckleWalkerIKControl, self).__init__(name=namer.create_name(),
                                                         matrix=matrix,
                                                         size=size,
                                                         parent=parent,
                                                         shape_type='hand',
                                                         node_type='joint',
                                                         keep_rotation=False,
                                                         rotate_order='xyz',
                                                         color=None,
                                                         shape_aim='+x',
                                                         shape_up='+y',
                                                         shape_offset=shape_offset,
                                                         shape_mirror=True,
                                                         lock_pos="",
                                                         lock_rot="",
                                                         lock_scl="xyz",
                                                         create_cnst=False,
                                                         create_secondary=True,
                                                         offset_matrix=om.MMatrix()
                                                         )
        self.twist_offset = mattr.add_twist_offset_attr(self.ctrl)
        if world_space:
            self.create_space(tag='ik', connect='rt', world_space=world_space, local_space=None, default='world')

        self.knuckle_offset = control.Control(name=namer.replace(add_to_tags="knuckle"),
                                              matrix=knuckle_matrix,
                                              size=size * 0.75,
                                              parent=self.top,
                                              shape_type="circle_ik",
                                              keep_rotation=False,
                                              node_type="transform",
                                              shape_offset=knuckle_offset,
                                              shape_aim="+z",
                                              lock_pos="",
                                              lock_rot="",
                                              lock_scl="xyz",
                                              create_secondary=False
                                              )

        self.wrist_offset = control.Control(name=namer.replace(add_to_tags="wrist"),
                                            matrix=matrix,
                                            size=size * 0.75,
                                            parent=self.knuckle_offset.top,
                                            shape_type="square",
                                            keep_rotation=False,
                                            node_type="transform",
                                            shape_offset=wrist_offset,
                                            lock_pos="",
                                            lock_rot="",
                                            lock_scl="xyz",
                                            create_secondary=False,
                                            create_cnst=True,
                                            shape_aim="+x",
                                            shape_up="-y",
                                            shape_mirror=True
                                            )

        self.cnst = self.wrist_offset.cnst

    @property
    def top(self):
        if self.wrist_offset is not None:
            return self.wrist_offset.top
        else:
            return super(HandKnuckleWalkerIKControl, self).top

    def get_shapes(self):
        out = []
        out.extend(super(HandKnuckleWalkerIKControl, self).get_shapes())
        out.extend(self.knuckle_offset.get_shapes())
        out.extend(self.wrist_offset.get_shapes())
        return out
