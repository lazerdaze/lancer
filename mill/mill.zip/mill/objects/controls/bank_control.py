'''
Created on 9 Feb 2017

@author: matthewk
'''
# python modules
import pymel.core as pm
import maya.api.OpenMaya as om

# package modules
import millrigger.objects.controls.control as mctrl
from millrigger.utils import name as mname
import millrigger.utils.matrix as mmtrx
import millrigger.utils.nodes.create as mcreate


class BankControl(mctrl.Control):

    def __init__(self, name, matrix=None, inner=0.5, outer=0.5, aim_axis='+x', up_axis='+y',
                 shape='bendArrowsTilt', size=1.0, parent=None):

        """
        :param name: a string for the name of the control, 'pole' will be added as a tag
        :param matrix: the placement of the matrix
        :param width: distance from mid point banking pivots will be placed
        :param axis: axis in which control will tilt x or z
        :param shape: control shape used
        :param size: the size of the control
        :param parent: the parent of the control
        :return:
        """

        self.namer = mname.Name(name, add_to_tags="bank")

        # get axis used for rotation (which is not the aim and not the up...)
        rot_axis = "+" + "xyz".translate(None, aim_axis + up_axis)
        pivot = mmtrx.get_as_mvector(aim_axis)

        # lock axis that are not the aim_axis
        lock = "xyz".translate(None, rot_axis)

        super(BankControl, self).__init__(name=self.namer.create_name(),
                                          matrix=matrix,
                                          size=size,
                                          parent=parent,
                                          shape_type=shape,
                                          node_type='transform',
                                          keep_rotation=True,
                                          rotate_order='xyz',
                                          shape_aim=rot_axis,
                                          shape_up=up_axis,
                                          shape_offset=None,
                                          shape_mirror=False,
                                          lock_pos="xyz",
                                          lock_rot=lock,
                                          lock_scl="xyz",
                                          create_ofs=False
                                          )

        cond = pm.createNode('condition', name=self.namer.replace(suffix='condition'))
        self.obj.attr("r" + rot_axis[1:]) >> cond.firstTerm
        cond.secondTerm.set(0)

        # if side is "R" switch inner and outer offsets
        if self.namer.side[0] == 'R':
            inner, outer = outer, inner

        # add pivot-positions to condition
        cond.operation.set(2)  # greater than
        cond.colorIfTrue.set(-inner * pivot)  # right pivot
        cond.colorIfFalse.set(outer * pivot)  # left pivot

        cond.outColor >> self.obj.rotatePivot
