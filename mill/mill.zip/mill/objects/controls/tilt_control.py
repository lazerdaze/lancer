'''
Created on 9 Feb 2017

@author: matthewk
'''
# python modules
import pymel.core as pm
import maya.api.OpenMaya as om

# package modules
import millrigger.objects.controls.control as mctrl
from millrigger.utils import name as mname
import millrigger.utils.nodes.create as mcreate


class TiltControl(mctrl.Control):

    def __init__(self, name, matrix, width=1, axis='x', shape='bendArrowsTilt', size=1.0, parent=None):
        
        """
        :param name: a string for the name of the control, 'pole' will be added as a tag
        :param matrix: the placement of the matrix
        :param width: distance from mid point banking pivots will be placed
        :param axis: axis in which control will tilt x or z
        :param shape: control shape used
        :param size: the size of the control
        :param parent: the parent of the control
        :return:
        """
        
        self.namer = mname.Name(name, add_to_tags="bank")
        '''
        if axis.lower() != 'x' or 'z':
            print 'Please use x or z axis'
            raise TypeError
        '''
        axis_dict = {'x':-4,
                     'y':-3,
                     'z':-2}
        directon_dict = {'x':'z',
                         'z':'x'}
    
        direction = axis_dict[directon_dict[axis]]
    
        lock = ""
        for pivot in "xyz":
            if pivot != axis:
                lock += pivot
                
        super(TiltControl, self).__init__(name=self.namer.create_name(),
                                          matrix=matrix,
                                          size=size,
                                          parent=parent,
                                          shape_type=shape,
                                          node_type='transform',
                                          keep_rotation=True,
                                          rotate_order='xyz',
                                          shape_aim='+'+axis,
                                          shape_up='+y',
                                          shape_offset=None,
                                          shape_mirror=False,
                                          lock_pos="xyz",
                                          lock_rot=lock,
                                          lock_scl="xyz",
                                          )

        self.create_tilt_control(matrix, axis, width, direction)
        
    def create_tilt_control(self, matrix, axis, width, direction):

        left_matrix = om.MMatrix(matrix)
        axis_value = left_matrix[direction]
        left_matrix[direction] = axis_value + width
        right_matrix = om.MMatrix(matrix)
        right_matrix[direction] = axis_value - width

        self.left_pivot = mcreate.node('transform',
                                     name=self.namer.replace(suffix='left_PVT'),
                                     parent=self.zero,
                                     matrix=left_matrix
                                     ).transform

        self.right_pivot = mcreate.node('transform',
                                      name=self.namer.replace(suffix="right_PVT"),
                                      parent=self.left_pivot,
                                      matrix=right_matrix
                                      ).transform

        # create setRange
        self.setrange = mcreate.node('setRange',
                                     name=self.namer.replace(suffix="bank_SRG")
                                     ).node

        # set the values of the SetRange
        self.setrange.minY.set(-360)
        self.setrange.maxZ.set(360)
        self.setrange.oldMinY.set(-360)
        self.setrange.oldMaxZ.set(360)

        pm.connectAttr(self.ctrl+'.r'+axis, self.setrange.vy)
        pm.connectAttr(self.ctrl+'.r'+axis, self.setrange.vz)

        if axis.lower() == 'z':
            self.setrange.outValue.outValueY >> self.left_pivot.rz
            self.setrange.outValue.outValueZ >> self.right_pivot.rz
        else:
            self.setrange.outValue.outValueY >> self.right_pivot.rx
            self.setrange.outValue.outValueZ >> self.left_pivot.rx
            
            
