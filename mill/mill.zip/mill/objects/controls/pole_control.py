import control
import millrigger.utils.name as mname
import millrigger.utils.attributes as mattr
import millrigger.utils.nodes.create as mcrt
import millrigger.utils.fkik as mfkik

import pymel.core as pm


class PoleControl(control.Control):
    """
    A Control class for creating pole vector controls
    """

    def __init__(self, name, matrix=None, size=1.0, parent=None,
                 world_space=None, local_space=None, follow_obj=None,
                 ik_handle=None, mode='side', twist_offset=None,
                 default_follow=0, default_space="local", create_side=True,
                 mirror_mode='NONE'):
        """

        :param name: a string for the name of the control, 'pole' will be added as a tag
        :param matrix: the placement of the matrix
        :param size: the size of the control
        :param parent: the parent of the control
        :param world_space: an object to use as a reference for the world space
        :param follow_obj: an object for the pole vector to follow
        :return:
        """
        self.namer = mname.Name(name, add_to_tags="pole")
        self.space_zero = mcrt.node('locator',
                                    name=self.namer.replace(tags=['pole', 'follow'], suffix='ORI_ZERO'),
                                    parent=parent)

        self.space_ori = mcrt.node('transform',
                                   name=self.namer.replace(tags=['pole', 'follow'], suffix='ORI'),
                                   parent=self.space_zero.transform).transform

        self.space_zero.transform.t.set(0, 0, 0)
        self.space_zero.shape.v.set(False)

        # make sure mode is lower case
        mode = mode.lower()

        super(PoleControl, self).__init__(name=self.namer.create_name(),
                                          matrix=matrix,
                                          size=size,
                                          parent=self.space_ori,
                                          shape_type='box',
                                          node_type='transform',
                                          keep_rotation=True,
                                          rotate_order='xyz',
                                          color=None,
                                          shape_aim='+x',
                                          shape_up='+y',
                                          shape_offset=None,
                                          shape_mirror=False,
                                          lock_pos="",
                                          lock_rot="xyz",
                                          lock_scl="xyz",
                                          create_cnst=True,
                                          create_secondary=False,
                                          mirror_mode=mirror_mode
                                          )

        if twist_offset is None:
            attr_data = mattr.add_polevector_attr(self.ctrl, make_twist=True, default_mode=mode)
            twist_offset = attr_data.twistOffset
        else:
            attr_data = mattr.add_polevector_attr(self.ctrl, default_mode=mode)

        if world_space:
            # if we're using follow and it's on, override any space default with local
            if follow_obj and default_follow:
                default_space = "local"

            # create the space
            self.create_space(tag='pole', connect='rt',
                              world_space=None,
                              local_space=None,
                              default=default_space
                              )

        if follow_obj:
            self.create_follow(follow_obj, default_follow)

        if ik_handle:
            self.create_pole_vector(ik_handle, twist_offset=twist_offset, create_side=create_side)
            zero = self._get_parent_for_annotationshape(ik_handle)
            arrow = pm.createNode("annotationShape", name=zero.name() + "Shape", parent=zero)
            pm.connectAttr("%s.worldMatrix[0]" % self.cnst.name(),
                           "%s.dagObjectMatrix[0]" % arrow.name(),
                           f=True)
            self.shape.overrideVisibility >> arrow.overrideVisibility
            arrow.overrideEnabled.set(True)
            arrow.overrideDisplayType.set(1)

    def create_pole_vector(self, ik_handles, twist_offset=None, create_side=True):
        if not isinstance(ik_handles, list):
            ik_handles = [ik_handles]

        if create_side:
            pole_vec = self._create_advanced_pole_vector()

            mdl = pm.createNode('multDoubleLinear',
                                name=self.namer.replace(tags='pole',
                                                        suffix='multDoubleLinear'))
            adl = pm.createNode('addDoubleLinear',
                                name=self.namer.replace(tags='pole',
                                                        suffix='addDoubleLinear'))

            # connect plane for polevector
            if twist_offset:
                twist_offset >> adl.i1
            self.ctrl.polePlane >> mdl.i1
            mdl.o >> adl.i2
            for ik_handle in ik_handles:
                adl.o >> ik_handle.twist

            # setting the offsets for the "side"-mode
            mdl.i2.set(90)

        else:
            pole_vec = self._create_simple_pole_vector()
            # connect the twist
            if twist_offset:
                for ik_handle in ik_handles:
                    twist_offset >> ik_handle.twist

        for ik_handle in ik_handles:
            pole_vec >> ik_handle.pv

    def _create_simple_pole_vector(self):

        # polevector = ctrl.cnst.wp - parent_loc_shape.wp
        # this works without creation of a polevector-constraint
        mpmm_aim = pm.createNode('pointMatrixMult',
                                 name=self.namer.replace(tags=['pole', 'aim'],
                                                         suffix='pointMatrixMult'))

        self.cnst.wp >> mpmm_aim.inPoint
        self.space_ori.worldInverseMatrix >> mpmm_aim.inMatrix

        return mpmm_aim.o

    def _create_advanced_pole_vector(self):
        # create a polevector with a switch-option between "aim" and "side"

        # get basic aim-vector
        pole_vec = self._create_simple_pole_vector()

        aimer = pm.createNode('transform',
                              name=self.namer.replace(tags=['pole', 'side'],
                                                      suffix='AIMER'),
                              parent=self.space_ori)

        angl = pm.createNode('angleBetween',
                             name=self.namer.replace(tags=['pole', 'side'],
                                                     suffix='angleBetween'))
        pole_vec.ox >> angl.v2x
        pole_vec.oz >> angl.v2z
        angl.v2y.set(0)
        angl.v1.set(0, 0, 1)

        mpmm_world = pm.createNode('pointMatrixMult',
                                   name=self.namer.replace(tags=['pole', 'world'],
                                                           suffix='pointMatrixMult'))

        mpmm_inverse = pm.createNode('pointMatrixMult',
                                     name=self.namer.replace(tags=['pole', 'inverse'],
                                                             suffix='pointMatrixMult'))

        mpmm_local = pm.createNode('pointMatrixMult',
                                   name=self.namer.replace(tags=['pole', 'local'],
                                                           suffix='pointMatrixMult'))

        sub = mcrt.node('sub', name=self.namer.replace(tags='pole', suffix='SUB')).node

        cond = pm.createNode('condition',
                             name=self.namer.replace(tags='pole',
                                                     suffix='condition'))

        angl.euler >> aimer.r
        aimer.worldMatrix >> mpmm_world.inMatrix
        mpmm_world.inPoint.set(1, 0, 0)

        self.space_ori.worldInverseMatrix >> mpmm_inverse.inMatrix
        mpmm_world.o >> mpmm_inverse.inPoint

        cond.secondTerm.set(0.5)
        cond.operation.set(4)  # less than
        pole_vec >> cond.colorIfTrue
        mpmm_inverse.o >> cond.colorIfFalse

        cond.oc >> mpmm_local.inPoint
        self.space_ori.worldMatrix >> mpmm_local.inMatrix
        mpmm_local.o >> sub.i3[0]
        self.space_zero.shape.wp >> sub.i3[1]

        self.ctrl.polePlane >> cond.firstTerm
        return sub.o3

    def create_follow(self, follow_obj, default=0):

        # create follow construct
        follow_attr, side_attr = mfkik.create_follow(self.space_ori,
                                                     follow_obj,
                                                     namer=self.namer)

        mattr.add_follow_attr(self.ctrl, default) >> follow_attr
        self.ctrl.polePlane >> side_attr

    def _get_parent_for_annotationshape(self, ik_handle):
        jnt = ik_handle.startJoint.inputs()[0]
        zero = jnt.getChildren(type='transform')[0]
        return zero

