import millrigger.objects.controls.control as mctrl
import millrigger.utils.fkik as mfkik
import millrigger.utils.matrix as mmtrx
import millrigger.utils.name as mname
import maya.api.OpenMaya as om


class FootIkControl(mctrl.Control):
    """

    """

    def __init__(self,
                 name,
                 foot_matrix,
                 ball_matrix=None,
                 ankle_matrix=None,
                 back_pivot_matrix=None,
                 inner_pivot_matrix=None,
                 outer_pivot_matrix=None,
                 front_pivot_matrix=None,
                 foot_size=1.0,
                 toe_size=1.0,
                 parent=None,
                 world_space=None,
                 create_footroll=True):

        self.name = name
        self.namer = mname.Name(name, add_to_tags='ik')

        super(FootIkControl, self).__init__(self.namer.create_name(),
                                            shape_type='square',
                                            node_type='transform',
                                            matrix=foot_matrix,
                                            keep_rotation=False,
                                            size=foot_size,
                                            rotate_order="xyz",
                                            parent=parent,
                                            shape_aim='+y',
                                            shape_up='+z',
                                            shape_mirror=False,
                                            lock_scl="xyz",
                                            create_cnst=True,
                                            mirror_mode="NONE"
                                            )
        if world_space:
            self.create_space(tag='ik', connect='rt',
                              world_space=world_space,
                              local_space=None,
                              default='world')

        if back_pivot_matrix and inner_pivot_matrix and front_pivot_matrix and back_pivot_matrix:
            # put the shape on the floor
            set_ik_shape(control=self,
                         foot_matrix=foot_matrix,
                         inner_matrix=inner_pivot_matrix,
                         outer_matrix=outer_pivot_matrix,
                         front_matrix=front_pivot_matrix,
                         back_matrix=back_pivot_matrix
                         )

        if create_footroll is True:
            # make the footroll
            self.footroll = mfkik.create_footroll(ctrl=self.obj,
                                                  inner_matrix=inner_pivot_matrix,
                                                  outer_matrix=outer_pivot_matrix,
                                                  ball_matrix=ball_matrix,
                                                  front_matrix=front_pivot_matrix,
                                                  back_matrix=back_pivot_matrix,
                                                  ankle_matrix=ankle_matrix
                                                  )
            self.cnst = self.footroll.cnst
            self.toes_ctrl = mctrl.Control(self.namer.replace(part='toes'),
                                           shape_type='toes',
                                           node_type='transform',
                                           matrix=ball_matrix,
                                           keep_rotation=False,
                                           size=toe_size,
                                           parent=self.footroll.toes,
                                           shape_aim='+y',
                                           shape_up='+z',
                                           shape_mirror=True,
                                           lock_pos="xyz",
                                           lock_rot="",
                                           lock_scl="xyz",
                                           create_cnst=False,
                                           mirror_mode="NONE"
                                           )
        else:
            self.footroll = None
            self.toes_ctrl = None

    # our top node should be the ankle
    @ property
    def top(self):
        try:
            return self.footroll.ankle
        except AttributeError:
            reverse_flat = self.hierarchy(existing=True)
            reverse_flat.reverse()
            for item in reverse_flat:
                if item is not None:
                    return item


def set_ik_shape(control, foot_matrix, inner_matrix, outer_matrix, front_matrix, back_matrix):
    """

    :param foot_matrix:
    :param inner_matrix:
    :param outer_matrix:
    :param front_matrix:
    :param back_matrix:
    :return:
    """
    # flatten the matrix positions
    inner_pos = mmtrx.get_posvector(inner_matrix)
    outer_pos = mmtrx.get_posvector(outer_matrix)
    heel_pos = mmtrx.get_posvector(back_matrix)
    toes_pos = mmtrx.get_posvector(front_matrix)
    ctrl_pos = mmtrx.get_posvector(foot_matrix)

    inner_pos.y = 0
    outer_pos.y = 0
    heel_pos.y = 0
    toes_pos.y = 0
    ctrl_pos.y = 0

    # get the distances
    height = mmtrx.get_posvector(foot_matrix).y
    length = (toes_pos - heel_pos).length()
    width = (inner_pos - outer_pos).length()
    back_length = (ctrl_pos - heel_pos).length()

    # get the shape data
    shape = control.obj.getShape()
    vectors = _get_vectors_from_shape(shape)

    new_vectors = []
    for vec in vectors:
        # change the length
        vec.x *= width
        vec.z *= length

        # move it down to the floor
        vec = vec - om.MVector(0, height, 0)

        # move it to the centre
        vec = vec + om.MVector(0, 0, (length / 2) - back_length)

        # scale it up a tiny bit
        vec.x *= 1.1
        vec.z *= 1.1
        new_vectors.append(vec)

    # set the vectors for the main shape
    _set_vectors_in_shape(shape, new_vectors)

    # scale up a bit if we have a secondary control
    if control.secondary_shape is not None:
        sec_vectors = []
        for vec in new_vectors:
            vec.x *= 1.5
            vec.z *= 1.2
            sec_vectors.append(vec)
        _set_vectors_in_shape(control.secondary_shape, sec_vectors)


def _get_vectors_from_shape(shape):
    """
    Gets all the vectors from a shape as a list of MVectors
    :param shape:
    :return:
    """
    out = []
    for cv in shape.comp('cv'):
        out.append(om.MVector(cv.getPosition()))
    return out


def _set_vectors_in_shape(shape, vectors):
    for cv, v in zip(shape.comp('cv'), vectors):
        cv.setPosition([v.x, v.y, v.z], space="preTransform")
    shape.updateCurve()
