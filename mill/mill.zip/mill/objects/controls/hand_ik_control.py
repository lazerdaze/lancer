import control
import millrigger.utils.name as mname
import millrigger.utils.attributes as mattr
import maya.api.OpenMaya as om


class HandIKControl(control.Control):
    """
    A Control class for creating pole vector controls
    """
    def __init__(self, name, matrix=None, size=1.0, parent=None, world_space=None, create_wrist_ctrl=False):
        """

        :param name: a string for the name of the control, 'ik' will be added as a tag
        :param matrix: the placement of the matrix
        :param size: the size of the control
        :param parent: the parent of the control
        :param world_space: an object to use as a reference for the world space
        :param follow_obj: an object for the pole vector to follow
        :param create_wrist_ctrl: create additional control to offset the wrist
        :return:
        """
        namer = mname.Name(name, add_to_tags="ik")
        shape_offset = om.MVector(0, -size / 2, 0)

        name = namer.create_name()
        super(HandIKControl, self).__init__(name=name,
                                            matrix=matrix,
                                            size=size,
                                            parent=parent,
                                            shape_type='hand',
                                            node_type='joint',
                                            keep_rotation=False,
                                            rotate_order='xyz',
                                            color=None,
                                            shape_aim='+x',
                                            shape_up='+y',
                                            shape_offset=shape_offset,
                                            shape_mirror=True,
                                            lock_pos="",
                                            lock_rot="",
                                            lock_scl="xyz",
                                            create_cnst=True,
                                            create_secondary=True,
                                            offset_matrix=om.MMatrix()
                                            )

        if create_wrist_ctrl:
            self.wrist_ctrl = control.Control(name=namer.replace(tags="wrist"),
                                              shape_type='sphere',
                                              size=size * 0.75,
                                              node_type='transform',
                                              matrix=matrix,
                                              parent=self.top,
                                              rotate_order='yzx',
                                              add_to_tags='ik',
                                              lock_scl=True,
                                              mirror_mode='FULL',
                                              )
            self.wrist_ctrl.drive_visibility(self.obj, attr_name="wristVisibility")
        else:
            self.wrist_ctrl = None

        self.twist_offset = mattr.add_twist_offset_attr(self.ctrl)
        if world_space:
            self.create_space(tag='ik', connect='rt', world_space=world_space, local_space=None, default='world')

    @property
    def ctrls(self):
        out = [self]
        if self.wrist_ctrl is not None:
            out.append(self.wrist_ctrl)
        return out

    @property
    def end_ctrl(self):
        if self.wrist_ctrl is not None:
            return self.wrist_ctrl
        else:
            return self
