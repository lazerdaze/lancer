"""
.. module:: space
   :synopsis: Spaceswitching world/local/custom

.. moduleauthor:: andreasg
"""

# maya imports
import pymel.core as pm

# package imports
from millrigger.globals.rig import GLOBAL_CTRL
import millrigger.utils.nodes.matrixblend as mbld
from millrigger.utils.nodes.constraints import create_simple_constraint
from millrigger.utils import attributes as mattr
from millrigger.utils import name as mname


class Space(object):
    """ create spaceblends and attributes

    :param rig_object: control-object (ctrl/ofs/zero)
    :type rig_object: ControlClass-Object

    :param tag: tag to name the attribute (ik, fk, polevec)
    :type tag: String

    :param connect: 'rt'
    :type connect: String

    :param world_space: world-space
    :type world_space: PyNode/MMatrix/None

    :param local_space: local-space
    :type local_space: PyNode/MMatrix/None

    :param custom_space: custom-space
    :type custom_space: PyNode/MMatrix/None

    :param world_attr: 'world' or whatever the worldspace should be called
    :type world_attr: String

    :param local_attr: 'local' or whatever the localspace should be called
    :type local_attr: String

    :param nice_name: however the worldspace should appear in the channelbox
    :type local_attr: String

    :param make_custom: create custom-space-blend
    :type make_custom: Boolean

    :param attr_obj: node for the spaceattributes. If None -> control-object will be used
    :type attr_obj: PyNode/None

    :param default: the defaultvalue for the spaceattributes: world/local/custom
    :type default: String

    :rType: PyNode-attribute
    """

    def __init__(self, rig_object, tag='ik', connect='rt',
                 world_space=None, local_space=None,
                 custom_space=None,
                 make_custom=True, follow_obj=None,
                 world_attr=None, local_attr=None,
                 nice_name=None,
                 attr_obj=None, default=None, rotate_order=None):
        self.rig_object = rig_object
        self.namer = mname.Name(rig_object.obj)
        self.worldspace = world_space or pm.PyNode(GLOBAL_CTRL)
        self.localspace = local_space
        self.customspace = custom_space
        self.world_attr = world_attr or 'world'
        self.local_attr = local_attr or 'local'
        self.nice_name = nice_name
        self.connect = connect
        self.make_custom = make_custom
        self.tag = tag
        self.attr_obj = attr_obj or rig_object.ctrl
        self.default = default or self.world_attr
        self.rotate_order = rotate_order
        self.build()

    def build(self):
        if self.world_attr == 'world':
            nice_name = None
        else:
            nice_name = self.nice_name or self.world_attr.capitalize()
        attr_data = mattr.add_space_attr(self.attr_obj,
                                         tag=self.tag,
                                         custom=self.make_custom,
                                         default_world=self.default == self.world_attr,
                                         default_custom=self.default == self.local_attr,
                                         nice_name=nice_name)

        # create and insert space switch node and add it to rigobject class

        spc_node = self.rig_object.create_spc()

        # create worldspace
        world_space = create_space_transform(rig_object=self.rig_object,
                                             driver=self.worldspace,
                                             tag=self.world_attr,
                                             connect=self.connect
                                             )

        if self.localspace is not None:
            local_space = create_space_transform(rig_object=self.rig_object,
                                                 driver=self.localspace,
                                                 tag=self.local_attr,
                                                 connect=self.connect
                                                 )
            source1 = local_space.matrix
        else:
            local_space = None
            source1 = None

        if self.make_custom is True:
            custom_space = create_space_transform(rig_object=self.rig_object,
                                                  driver=self.customspace,
                                                  tag='custom',
                                                  connect=self.connect
                                                  )

            # custom space blend
            self.custom_mblnd = mbld.MatrixBlend(source1=source1,
                                                 source2=custom_space.matrix,
                                                 target=spc_node,
                                                 connect=self.connect,
                                                 blend=attr_data.custom,
                                                 add_to_tags=['custom'],
                                                 rotate_order=self.rotate_order)

            # replace local-space with matrixblend
            source1 = self.custom_mblnd.node.outMatrix

        # world space blend
        self.matrix_blend = mbld.MatrixBlend(source1=source1,
                                             source2=world_space.matrix,
                                             target=spc_node,
                                             connect=self.connect,
                                             blend=attr_data.world,
                                             add_to_tags=[self.world_attr],
                                             rotate_order=self.rotate_order)

CHANNEL_DICT = {"s": "Scale", "r": "Rotate", "t": "Translate"}


def create_channel_spaces(rig_object, space_drivers, space_tags, connect='rt', attr_holder=None,
                          separate_channels=False, create_custom_space=True, default_tag=None,
                          custom_tag="custom"):
    """
    Gives the given rig object a number of spaces to drive it. Each space requires a transform node
    and a tag - each given in corresponding lists of the same length. If you choose to have
    separate channels then you'll get a different attribute for each of the connects you choose
    (so 'rt' would give you Rotate and Translate blends).

    Each driver will override the previous ones, with the custom space (if requested) being the
    last one. If all spaces are off then the rig object will follow it's parent.

    Unless a default tag is given then the spaces will be turned off.

    :param rig_object: A rig object class that needs the spaces
    :param space_drivers: A list of transforms that drive the spaces
    :param space_tags: A list of strings that are the name for each space
    :param connect: Which channels of the rig object to drive
    :param attr_holder: A PyNode that carries the attributes. If None then the rig_object.obj will be used
    :param separate_channels: If true, each channel in the connect argument will have a separate space
    :param create_custom_space: If true, an empty space will be made that can be linked to any object in the scene via the ui tools
    :param default_tag: If a tag matches this then it will be set to 1 (across all channels)
    :param custom_tag: In case you don't want the custom tag to be "custom"
    :return:
    """

    # create the spc node
    rig_object.create_spc()

    # test the inputs
    if len(space_drivers) != len(space_tags):
        raise AttributeError("")

    # add a custom space to the end, if needed
    if create_custom_space:
        space_drivers.append(None)
        space_tags.append(custom_tag)

    # make the space references
    rig_objs = [rig_object] * len(space_tags)
    connects = [connect] * len(space_tags)
    spaces = map(create_space_transform, rig_objs, space_drivers, space_tags, connects)

    # make attrs for each of the tags as we connect them
    if separate_channels:
        attr_suffixes = [CHANNEL_DICT[channel] for channel in connect]
    else:
        attr_suffixes = [""]

    # make the blends
    parent_blend = [[None] * len(attr_suffixes)] * len(space_tags)
    if attr_holder is None:
        attr_holder = rig_object.obj

    blends = []
    for i, suffix in enumerate(attr_suffixes):
        # add a title
        if suffix:
            mattr.add_headline(attr_holder, suffix + "_SPACES")
        else:
            mattr.add_headline(attr_holder, "SPACES")

        blend_index = 0
        for space, tag in zip(spaces, space_tags):
            # make the attr
            attr = mattr.add_generic_blend(node=attr_holder,
                                           attr_name=tag+suffix,
                                           default=int(tag == default_tag))

            # get the parent blend
            if parent_blend[blend_index][i]:
                source1 = parent_blend[blend_index][i].outMatrix
            else:
                source1 = None

            # make the matrix blend
            blend = mbld.MatrixBlend(source1=source1,
                                     source2=space.matrix,
                                     blend=attr,
                                     add_to_tags=suffix.lower(),
                                     name=space.name())

            # store it as a parent
            parent_blend[blend_index][i] = blend.node
            blends.append(blend.node)

            blend_index += 1

    # connect the blends to the rig object
    for i, channel in enumerate(connect):
        pm.connectAttr(source="%s.out%s" % (parent_blend[-1][i].name(), CHANNEL_DICT[channel]),
                       destination="%s.%s" % (rig_object.spc.name(), channel))

    # hook up the rotate orders
    for blend in blends:
        rig_object.spc.rotateOrder >> blend.rotateOrder
    return spaces


def create_space_transform(rig_object, driver, tag, connect='rt'):
    """
    creates a space transform that's constrained to the driver

    :param rig_object: A rigobject class for the control
    :param driver: A PyNode that drives the
    :param tag:
    :param connect:
    :return:
    """
    namer = mname.Name(rig_object.name)

    space = pm.createNode('transform',
                          name=namer.replace(add_to_tags=tag,
                                             suffix='SPACE'),
                          parent=rig_object.zero)
    space.visibility.set(False)

    if driver:
        create_simple_constraint(driver, space, snap=False, connect=connect)
    return space
