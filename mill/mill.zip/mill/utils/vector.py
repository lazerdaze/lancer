"""
.. module:: matrix
   :synopsis: vector related functions

.. moduleauthor:: petera, andreasg
"""

# python imports
from math import pi as PI

# maya imports
# import pymel.core.datatypes as dt
import maya.api.OpenMaya as om
import maya.OpenMaya as old_om
import maya.cmds as cmds
import pymel.core as pm

# package imports
from ..globals import rig as RIG

ROTORDER_SWITCH = {"xyz": om.MEulerRotation.kXYZ,
                   "xzy": om.MEulerRotation.kXZY,
                   "yxz": om.MEulerRotation.kYXZ,
                   "yzx": om.MEulerRotation.kYZX,
                   "zxy": om.MEulerRotation.kZXY,
                   "zyx": om.MEulerRotation.kZYX
                   }


def get_vector(obj, ws=True):
    '''
    returns a MVector from the position of an object

    :param obj: transform
    :type obj: Transform

    :param ws: return position in worldspace
    :type obj: Boolean

    :rType: MVector
    '''
    if isinstance(obj, pm.PyNode):
        obj = obj.name()

    return om.MVector(cmds.xform(obj, ws=ws, a=True, q=True, t=True))


def get_as_mvector(vector):
    """
    Always returns the given vector as an MVector type object.
    Old style MVectors will be converted to new type.

    :param vector:
    :return:
    """

    if isinstance(vector, om.MVector):
        return vector

    if isinstance(vector, old_om.MVector):
        return om.MVector(vector)

    if isinstance(vector, pm.datatypes.Vector):
        return om.MVector(vector)

    if isinstance(vector, (list, tuple)):
        return om.MVector(vector)

    if isinstance(vector, om.MMatrix):
        return om.MVector(vector[-4], vector[-3], vector[-2])

    if isinstance(vector, basestring) and vector in RIG.AXIS_KEYS:
        return om.MVector(RIG.STR_TO_VEC_SWITCH[vector])

    raise TypeError("Need to add vector type '%s' millrigger.utils.vector.get_as_vector()" % vector.__class__)


def get_axis_vector(axis):
    '''
    returns a MVector from a string

    :param axis: One of +x/+y/+z/-x/-y/-z as a string
    :type axis: string

    :rType: MVector
    '''
    if axis not in RIG.STR_TO_VEC_SWITCH.keys():
        raise ValueError("axis must be one of: " + str(RIG.STR_TO_VEC_SWITCH.keys()))
    return om.MVector(RIG.STR_TO_VEC_SWITCH[axis])


def mult_vector_by_vector(vec_a, vec_b):
    ''' multiply each axis of 2 vectors with each other (no dot-product) '''
    return om.MVector(vec_a.x * vec_b.x,
                      vec_a.y * vec_b.y,
                      vec_a.z * vec_b.z)


def get_cv_vectorlist(crv, ws=True):
    '''
    return a list of vectors for each cv of a nurbscurve
    '''
    cv_list = cmds.ls(crv + '.cv[*]', fl=True)
    unsorted_list = cmds.xform(cv_list, ws=ws, os=not ws, a=True, q=True, t=True)
    sorted_list = zip(*[unsorted_list[i::3] for i in range(3)])
    pos_list = map(om.MVector, sorted_list)
    return pos_list


def get_vectorlist(obj, ws=True):
    '''
    returns the positionlist of the objects components as a list of vectors

    :param obj: transform or shape
    :type obj: string

    :rType: List of MVectors
    '''
    type_dict = {'nurbsCurve': 'cv[*]',
                 'nurbsSurface': 'cv[*][*]',
                 'mesh': 'vtx[*]',
                 'lattice': 'pt[*][*][*]'
                 }

    if cmds.objectType(obj, isAType='transform'):
        shp = cmds.listRelatives(obj, shapes=True)[0]
        nodetype = cmds.objectType(shp)
    elif cmds.objectType(obj, isAType='shape'):
        nodetype = cmds.objectType(obj)
    else:
        return

    component_list = cmds.ls('%s.%s' % (obj, type_dict[nodetype]), fl=True)
    unsorted_list = cmds.xform(component_list, ws=ws, os=not ws, a=True, q=True, t=True)
    sorted_list = zip(*[unsorted_list[i::3] for i in range(3)])
    pos_list = map(om.MVector, sorted_list)
    return pos_list


def angle_between_deg(*vec_list):
    '''
    returns angle between vectors in degrees.

    :param vec_list: list of 2 or 3 vectors. If 3 vectors are given, the 2nd
    will be subtracted from the first and last
    :type vec_list: string

    :rType: Float
    '''
    if len(vec_list) == 2:
        angle = vec_list[0].angle(vec_list[1])
    else:
        aVec = vec_list[0] - vec_list[1]
        bVec = vec_list[-1] - vec_list[1]
        angle = aVec.angle(bVec)
    return om.MAngle.asDegrees(angle)


def compare_aim(a_vec, b_vec, threshold=0.5 * PI):
    '''
    checks if to vectors are similar enough by the given threshold

    :param a_vec: First Vector
    :type a_vec: MVector
    :param b_vec: Second Vector
    :type b_vec: MVector

    :rType: Boolean
    '''
    return a_vec.angle(b_vec) < threshold


def upvector(*vec_list):
    '''
    Calculate a normalized up-vector of a list of 2/3 vectors. If 3 vectors
    are given, the 2nd will be subtracted from the first and last

    :param vec_list: One of +x/+y/+z/-x/-y/-z as a string
    :type vec_list: list of MVectors

    :rType: MVector
    '''
    arg_len = len(vec_list)

    norm_vec = None
    if arg_len == 2:
        norm_vec = vec_list[1] ^ vec_list[0]
    elif arg_len > 2:
        a_vec = vec_list[0] - vec_list[1]
        b_vec = vec_list[1] - vec_list[-1]
        norm_vec = b_vec ^ a_vec

    if norm_vec:
        norm_vec.normalize()
    return norm_vec


def normalvector(*vec_list):
    '''
    Calculate the normalized normal-vector for a point on a line
    of a list of 3 vectors. If more than 3 vectors are provided,
    the 2nd will be subtracted from the first and last.
    Returns Zero-Vector if point is on curve.
    First vector defines the point, second and last the line

    :param vec_list: min 3 Vectors,
    :type vec_list: list of MVectors
    :rType: MVector
    '''
    a_vec = vec_list[0] - vec_list[1]
    b_vec = vec_list[0] - vec_list[-1]
    n_vec = b_vec ^ (a_vec ^ b_vec)
    e_vec = vec_list[1] - vec_list[-1]
    n_mag = n_vec.length()
    if n_mag > 0:
        result = n_vec * ((e_vec * n_vec) / n_mag ** 2.0)
        result.normalize()
    else:
        result = om.MVector.kZeroVector
    return result


def polevector(*vec_list, **kwargs):
    '''
    "side"-mode means the upvector will be placed to the side of the ik-chain and
    it will get a twist of 90deg. This works best for legs as the upvector doesn't
    get in the way of the feet.

    :param vec_list: min 3 Vectors,
    :type vec_list: list of MVectors
    :param mode: "side" or "standard"
    :type mode: String

    :rType: MVector
    '''

    mode = kwargs.get('mode', 'side').lower()
    if mode == 'side':
        pole_vec = upvector(*vec_list)
    else:
        pole_vec = normalvector(*vec_list)
    return pole_vec


def average(vec_list):
    '''
    simple average function

    :param vec_list: vector-list,
    :type vec_list: list of MVectors

    :rType: MVector
    '''
    num = len(vec_list)
    sum = om.MVector(0, 0, 0)
    for vec in vec_list:
        sum += vec
    return sum / num


def normal_axis(aim_axis='+x', up_axis='+y', as_vector=False):
    '''
    get the ortoghonal axis to the given axis

    :param aim_axis: +x, -x, +y, -y, +z, -z
    :type aim_axis: String

    :param up_axis: +x, -x, +y, -y, +z, -z
    :type up_axis: String

    :param as_vector: convert the resulting stirng to a MVector
    :type as_vector: Boolean

    :rType: String/MVector
    '''
    if aim_axis[1] == up_axis[1]:
        raise ValueError('Aim-axis and up-axis must be different!')
    normal_axis = 'xyz'.translate(None, aim_axis + up_axis)
    if aim_axis[0] == up_axis[0]:
        normal_axis = '+' + normal_axis
    else:
        normal_axis = '-' + normal_axis
    if as_vector is True:
        return om.MVector(RIG.STR_TO_VEC_SWITCH[normal_axis])
    return normal_axis


def get_mirrorvector(obj, **kwargs):
    # initialize parameters
    mirList = kwargs.get('mirror', None)
    if isinstance(mirList[0], (list, tuple)):
        mVecList = map(om.MVector, mirList)
    elif isinstance(mirList[0], om.MVector):
        mVecList = mirList
    else:
        return None

    scl = kwargs.get('scl', -1.0)
    pVec = get_vector(obj)
    if len(mVecList) == 1:
        xVec = pVec - mVecList[0]
    elif len(mVecList) == 2:
        aVec = mVecList[0] - mVecList[1]
        bVec = mVecList[0] - pVec
        nVec = aVec ^ (aVec ^ bVec)
        eVec = pVec - mVecList[1]
        nMag = nVec.length()
        if nMag > 0:
            xVec = nVec * ((eVec * nVec) / nMag ** 2.0)
        else:
            xVec = get_as_mvector(0, 0, 0)
    elif len(mVecList) == 3:
        aVec = mVecList[0] - mVecList[1]
        bVec = mVecList[0] - mVecList[2]
        nVec = aVec ^ bVec
        eVec = pVec - mVecList[0]
        nMag = nVec.length()
        xVec = nVec * ((eVec * nVec) / nMag ** 2.0)
    vec = (pVec - xVec) + (xVec * scl)
    return vec


def reorder_eulerrotation(vec, src="xyz", tgt="xyz"):
    """
    convert a and return a eulertranslation with a source and target rotationOrder
    :param vec: rotation in degrees as MVector
    :type vec: MVector
    :param src: 'xyz', 'yzx', 'zxy', 'xzy', 'yxz', 'zyx'
    :type src: String
    :param tgt: 'xyz', 'yzx', 'zxy', 'xzy', 'yxz', 'zyx'
    :type tgt: String
    :return: converted EulerRotation in degrees
    :rtype: MVector
    """

    ro = ROTORDER_SWITCH[src]

    # convert to radians
    x = om.MAngle(vec.x, ro).asRadians()
    y = om.MAngle(vec.y, ro).asRadians()
    z = om.MAngle(vec.z, ro).asRadians()

    # create Api2.0 object
    euler = om.MEulerRotation(x, y, z, order=ro)
    euler.reorderIt(ROTORDER_SWITCH[tgt])

    result = om.MVector(om.MAngle(euler.x, om.MAngle.kRadians).asDegrees(),
                        om.MAngle(euler.y, om.MAngle.kRadians).asDegrees(),
                        om.MAngle(euler.z, om.MAngle.kRadians).asDegrees())
    return result


def get_as_eulerrotation(vec, ro="xyz"):
    rotorder = ROTORDER_SWITCH[ro]
    x = om.MAngle(vec.x, om.MAngle.kDegrees).asRadians()
    y = om.MAngle(vec.y, om.MAngle.kDegrees).asRadians()
    z = om.MAngle(vec.z, om.MAngle.kDegrees).asRadians()
    euler = om.MEulerRotation(x, y, z, order=rotorder)
    return euler


