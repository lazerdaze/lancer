import maya.cmds as cmds


# HIERARCHY ------------------------------------------------------------------
def get_parent(obj):
	"""
	simple wrapper for returning a single parent, not a list
	:param obj:
	:return:
	"""
	parent = cmds.listRelatives(obj, p=True)
	if parent:
		return parent[0]


def get_children(obj, type=None):
	"""
	simple wrapper for returning a list of children nodes with optional type-filter
	:param obj:
	:param type:
	:return:
	"""
	if type:
		children = cmds.listRelatives(obj, children=True, type=type)
	else:
		children = cmds.listRelatives(obj, children=True)
	return children


def get_shapes(obj, type=None):
	"""
	simple wrapper for returning a list of shape nodes with optional type-filter
	:param obj:
	:param type:
	:return:
	"""
	if type:
		shapes = cmds.listRelatives(obj, s=True, type=type)
	else:
		shapes = cmds.listRelatives(obj, s=True)
	return shapes


def get_shape(obj, type=None):
	"""
	simple wrapper for returning a single shape with optional type-filter
	:param obj:
	:return:
	"""
	shapes = get_shapes(obj, type)
	if shapes:
		return shapes[0]


# CONNECTIONS ----------------------------------------------------------------

def get_inputs(plug, **kwargs):
	"""
	simple wrapper for returning all input-connections to the given plug.
	All listConnections-parameters are still valid
	:param plug:
	:return:
	"""
	return cmds.listConnections(plug, s=True, d=False, **kwargs)


def get_outputs(plug, **kwargs):
	"""
	simple wrapper for returning all output-connections to the given plug.
	All listConnections-parameters are still valid
	:param plug:
	:return:
	"""
	return cmds.listConnections(plug, s=False, d=True, **kwargs)
