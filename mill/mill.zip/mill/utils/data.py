"""
.. module:: data
   :synopsis: Class for collecting and accessing data in a nice way

.. moduleauthor:: petera, andreasg
"""


class RigData(object):
    """
    Generic class that acts like a dictionary, but avoids KeyErrors
    """

    def __init__(self, items=[], values=[], **kwargs):
        """ fill any given values """
        self.set(items, values)
        self.set_kwargs(**kwargs)

    def __str__(self):
        """ print stored dict """
        return str(self.__dict__)

    def __iter__(self):
        """ return all items in stored dict """
        for k, v in self.__dict__.iteritems():
            yield k, v

    def __getattr__(self, item):
        """ get single item in stored dict """
        return self.__dict__.get(item, None)

    def get(self, *items):
        """ get item(s) in stored dict """
        return [self.__dict__.get(i, None) for i in items]

    def set(self, items, values):
        """ sets more data """
        if not isinstance(items, list):
            items = [items]
        if not isinstance(values, list):
            values = [values]
        if len(items) != len(values):
            raise ValueError("Given items and values must be of the same length")
        self.__dict__ = dict(zip(items, values))

    def set_kwargs(self, **kwargs):
        ''' sets items by keyword-args '''
        for item in kwargs:
            self.__dict__[item] = kwargs.get(item)

    def update(self, data):
        """  updates this data with another """
        for key, value in data:
            self.__dict__[key] = value

    def has_attr(self, attr):
        return self.get(attr) != [None]
