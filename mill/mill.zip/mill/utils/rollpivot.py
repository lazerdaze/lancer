from maya import cmds
import maya.api.OpenMaya as api

'''

#===============================================================================

:definition

    This rigging module is a transformation feature to simulate object rotation
    on its own shape with a constant and logical evaluation of the contact point
    creating a kind of dynamic pivot based on gravity and potential collisions.

    Like if you grab a coffee mug standing on a table with your hand
    and rotate it against the table. The rotation on the external edges of the
    mug is the curve where our pivot slide and it is found by finding the lowest
    point at contact (without using dynamics or time frame expression).
    It's stable and safe to use.

    Creating a "controler" and output a "locator" as worldspace transformation,
    (just constraint your objects to that loc). Based on a "curve" that represent
    the object's contour ( can have history for dynamic collision area ).

    The curve used to compute the contact area (where the pivot can be) can be:
        1. given directly
        2. curve not given but create one with edge selection
        3. curve not given but create one using bounding box
        4. curve not given but create one using bounding box and project on mesh (see :TODO)

    Originally developed to improve the foot roll locators setup. This can be
    ported to fk controlers, any props rig or as an animation tool in order to animate
    any contact point of an object with its environment.

:usage

    from millrigger.utils.rollpivot import *

    parent = 'C_parent_CTRL'
    target = 'C_rollpivot_1_GEO'
    name = 'C_rollpivot'

    # 1. use edge selection
    rollpivot(parent=parent, target=target, name=name ,useEdgeSel=True)

    # 2. use custom curve
    rollpivot(parent=parent, target=target, name=name, crv='myCurve1')

    # 3. and 4. create default curve with or without auto CVs projection
    rollpivot(parent=parent, target=target, name=name, projCrvOnPoly=True)
    rollpivot(parent=parent, target=target, name=name)

    # Additional kwargs root.
    # Will parent the output locator, curve and ctrl offset to 'my_root_node' instead of creating a default group
    rollpivot(parent=parent, target=target, name=name, root='my_root_node')

    # Additional kwargs methodParent.
    # will parent or constraint the controler top group to the specify parent (an other flag run by the rollpivot function)
    rollpivot(parent=parent, target=target, name=name, methodParent='parent')
    rollpivot(parent=parent, target=target, name=name, methodParent='constraint')

:return

    The roll pivot main function return always a list as follow (see function's docstring for more details):
        returnArgs = [root_group, output_locator, curve, controler_offset_group, controler]

:note

    This is a curve based setup. I thought while doing it that a
    3D implementation on mesh could be also doable.
    As there is geometry processing involved, I would recommend this to be a plugin.
    For now this fast maya "vanilla" curve based approach sounds a good bet.
    But keep that in mind !

#===============================================================================

'''

def rollpivot(parent=None, target=None, name=None, curve=None, projCrvOnPoly=False, useEdgeSel=False, root=None, methodParent='parent'):
    '''
    This is the main function - create a rollpivot setup (curve based).
    The curve used to roll can be given or created via edge selection
    or default placement (use target mesh BBox) Besides the default placement
    have a projection feature to fit the crv cvs to the target geometry.
    See args and kwargs of that function for more details.

    :kwargs
        :parent 'str' the parent node who drive the new controler
        :target 'str' the node name which receive the final transformations
        :name 'str' name pattern to assign to nodes created 'C_rollpivotA'
        :curve 'str' curve name used for rolling around. Default is None (create one)
        :projCrvOnPoly 'bool' Project the crv cvs to the target poly. Default is False
        :useEdgeSel 'bool' Convert edge selection to curve. Default is False
        :root 'str' specify a node name (typically a group) all the DAG objects
                from this function will be parented to it. Default is None

    :return
        [root_group, output_locator, curve, controler_offset_group, controler]
    '''
    # process all the curves creation and get relative data
    root, crvTransform, crvShape, crvPos = _curveSetup(curve, name, target, useEdgeSel, projCrvOnPoly, root=root)

    # create offset
    ctrl_ofs = cmds.group(em=1, n=name + '_CTRL_OFS')
    cmds.xform(ctrl_ofs, ws=1, t=crvPos)
    cmds.parent(ctrl_ofs, root)

    # createCtrl (temp)
    spans = cmds.getAttr(crvShape + '.s')
    degree = cmds.getAttr(crvShape + '.d')
    ctrl = cmds.circle(n=name + '_CTRL', nry=90, s=spans, d=degree, c=crvPos, ch=0)[0]
    for i in range(cmds.getAttr(crvShape + '.s')):
        cv = cmds.xform(crvShape + '.cv[' + str(i) + ']', q=1, t=1)
        cmds.xform(cmds.listRelatives(ctrl, s=1)[0] + '.cv[' + str(i) + ']', t=cv)
    cmds.parent(ctrl, ctrl_ofs)
    cmds.CenterPivot(ctrl)
    for x in ['tx', 'ty', 'tz', 'ry', 'sx', 'sy', 'sz', 'v']:
        cmds.setAttr(ctrl + '.' + x, l=1, k=0)

    # parent space - offset space - inject parentMatrix (for multiple space contact hierarchy)
    if parent and parent is not cmds.listRelatives(ctrl, p=1)[0]:
        if methodParent == 'constraint':
            cmds.parentConstraint(parent, ctrl_ofs, mo=1)
        if methodParent == 'parent':
            cmds.parent(ctrl_ofs, parent)

    # graph until pointOnCurveInfo
    mcp = cmds.createNode('composeMatrix', n=name + '_rotateCurve_MCP')
    cmds.connectAttr(ctrl + '.rotate', mcp + '.inputRotate')
    tgeo = cmds.createNode('transformGeometry', n=name + '_rotateCurve_TGEO')
    cmds.connectAttr(mcp + '.outputMatrix', tgeo + '.transform')
    cmds.connectAttr(crvShape + '.worldSpace', tgeo + '.inputGeometry')
    cpoc_info = cmds.createNode('nearestPointOnCurve', n=name + '_CPOC_INFO')
    cmds.setAttr(cpoc_info + ".inPositionY", -1000)
    cmds.connectAttr(tgeo + '.outputGeometry', cpoc_info + '.inputCurve')
    poc_info = cmds.createNode('pointOnCurveInfo', n=name + '_POC_INFO')
    cmds.connectAttr(cpoc_info + '.parameter', poc_info + '.parameter')
    cmds.connectAttr(crvShape + '.worldSpace', poc_info + '.inputCurve')

    pma = cmds.createNode('plusMinusAverage', n=name + '_pointToLocal_PMA')
    cmds.setAttr(pma + '.operation', 2)
    cmds.connectAttr(poc_info + '.position', pma + '.input3D[0]')
    cmds.connectAttr(crvTransform + '.rotatePivot', pma + '.input3D[1]')

    # graph until switch wolrdPivot/ShapeInject
    mcp2 = cmds.createNode('composeMatrix', n=name + '_rotationMatrix_MCP')
    cmds.connectAttr(ctrl + '.rotate', mcp2 + '.inputRotate')
    mpmm = cmds.createNode('pointMatrixMult', n=name + '_pivotMul_MPMM')
    cmds.connectAttr(mcp2 + '.outputMatrix', mpmm + '.inMatrix')
    cmds.connectAttr(pma + '.output3D', mpmm + '.inPoint')
    pma2 = cmds.createNode('plusMinusAverage', n=name + '_pivotLocal_PMA')
    cmds.connectAttr(pma + '.output3D', pma2 + '.input3D[0]')
    cmds.connectAttr(mpmm + '.output', pma2 + '.input3D[1]')
    cmds.setAttr(pma2 + '.operation', 2)
    mcp3 = cmds.createNode('composeMatrix', n=name + '_pivotLocalMat_MCP')
    cmds.connectAttr(pma2 + '.output3D', mcp3 + '.inputTranslate')
    cmds.connectAttr(ctrl + '.rotate', mcp3 + '.inputRotate')

    mmlt2 = cmds.createNode('multMatrix', n=name + '_pivotWorlMat_MMLT')
    cmds.connectAttr(mcp3 + '.outputMatrix', mmlt2 + '.matrixIn[0]')
    # PREVIOUS: cmds.connectAttr(parent+'.worldMatrix',mmlt2+'.matrixIn[1]')
    cmds.connectAttr(ctrl_ofs + '.worldMatrix', mmlt2 + '.matrixIn[1]')
    mdcp2 = cmds.createNode('decomposeMatrix', n=name + '_pivotWorlMat_MDCP')
    cmds.connectAttr(mmlt2 + '.matrixSum', mdcp2 + '.inputMatrix')

    # locator storing output transformations (handy to have it in the DAG)
    loc = cmds.spaceLocator(n=name + '_output_LOC')[0]
    cmds.xform(loc, t=cmds.xform(ctrl, q=1, rp=1))
    cmds.parent(loc, root)

    cmds.connectAttr(mdcp2 + '.outputTranslate', loc + '.translate')
    cmds.connectAttr(mdcp2 + '.outputRotate', loc + '.rotate')
    cmds.connectAttr(mdcp2 + '.outputScale', loc + '.scale')
    cmds.setAttr(loc + "Shape.v", 0)

    # connect output world matrix to target if any
    if target:
        cmds.parentConstraint(loc, target, mo=1)

    # shapeInjection: transform
    minv = cmds.createNode('inverseMatrix', n=name + '_pivotCtrlShape_MINV')
    cmds.connectAttr(mcp3 + '.outputMatrix', minv + '.inputMatrix')
    mmlt2 = cmds.createNode('multMatrix', n=name + '_pivotCtrlShape_MMLT')
    cmds.connectAttr(ctrl + '.matrix', mmlt2 + '.matrixIn[0]')
    cmds.connectAttr(minv + '.outputMatrix', mmlt2 + '.matrixIn[1]')

    # shapeInjection: create intermediateShape and mix with transform.
    tgeo2 = cmds.createNode('transformGeometry', n=name + '_pivotCtrlShape_TGEO')
    cmds.setAttr(tgeo2 + '.invertTransform', 1)
    cmds.connectAttr(mmlt2 + '.matrixSum', tgeo2 + '.transform')
    crvIntermediateShapeX = cmds.duplicate(ctrl)[0]
    crvIntermediateShape = cmds.listRelatives(crvIntermediateShapeX, s=True)[0]
    cmds.parent(crvIntermediateShape, ctrl, s=True, r=True)
    cmds.delete(crvIntermediateShapeX)
    translation = [x * -1 for x in cmds.xform(ctrl, q=1, rp=1)]
    cmds.xform(crvIntermediateShape + '.cv[*]', r=1, t=translation)
    cmds.setAttr(crvIntermediateShape + '.intermediateObject', 1)
    cmds.setAttr(crvIntermediateShape + '.v', 0)
    cmds.connectAttr(crvIntermediateShape + '.local', tgeo2 + '.inputGeometry')
    ctrlShape = cmds.listRelatives(ctrl, s=True)[0]
    cmds.connectAttr(tgeo2 + '.outputGeometry', ctrlShape + '.create')

    cmds.hide(crvTransform)
    cmds.select(ctrl, r=1)

    ctrl_zero = None  # not implemented

    return root, loc, crvTransform, ctrl_ofs, ctrl


def _curveSetup(crv, name, target, useEdgeSel, projCrvOnPoly, root=None):
    '''
    Prepare the curves for the rollpivot, possible scenarios are:

        1. curve     given
        2. curve not given and use edge selection
        3. curve not given and use bounding box
        4. curve not given and use bounding box and project on mesh (see :TODO)

    :args
        please check rollpivot main function's docstring for more info.

    :TODO
        scipy finds the closest intersection of a ray against a poly with pure math.
        or find a hack with api 2.0 undo system like pymel.internal.factory does.

    '''
    defaultCrv = name + '_CRV'

    #===============================================================================
    # Below are scenario where the curve is not given
    #===============================================================================

    if not crv:

        #=======================================================================
        # Use edge selection to get a curve
        #=======================================================================

        if useEdgeSel:
            crv = convert_selection_to_curve()

        #=======================================================================
        # ...Or create a new curve ( will use target mesh bounding box and topology)
        #=======================================================================

        else:
            tmpMesh = ''
            if not target:
                 raise RuntimeError('This mode require to set a target !')
            # this is temp but a MPointArray * inclusiveMatrix or similar sounds the way to go.
            # then
            if not cmds.xform(target, q=1, m=1, ws=1) == list(api.MMatrix()):

                tmpMesh = cmds.duplicate(target)[0]
                _ = [cmds.setAttr(tmpMesh + '.' + att, l=0, k=1) for att in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz', 'sx', 'sy', 'sz']]
                not cmds.listRelatives(tmpMesh, p=1) or cmds.parent(tmpMesh, w=1)
                cmds.makeIdentity(tmpMesh, a=1)

                print('INFO >>> ROLL-PIVOT: Target mesh had transformation, next time try to freeze it first to improve execution time')

            sel = api.MSelectionList()
            sel.add(tmpMesh)
            bbox = api.MFnDagNode(sel.getDagPath(0).extendToShape()).boundingBox
            xyRadius = api.MFloatVector(bbox.width, 0, bbox.depth).length() / 2.0  # to make sure all the points are outside the mesh for projection
            center = [bbox.center[0], bbox.min[1], bbox.center[2]]

            crv = cmds.circle(d=3, nry=90, r=xyRadius, ch=0, n=defaultCrv, c=center)[0]

            #===============================================================================
            # # WIP - project cvs on target mesh (based on MFnMesh.closestIntersection)
            #
            # TODO:
            #      Extract an optimal result from the correlation between two equations:
            #      hitPoint ray length and the offset vector length.
            #      Also the bounding box for single mesh like human is not a good ref.
            #           maybe looking at bbox clamped to ctrl hierarchy (so we )
            #
            # This solve the projection node based.
            # cmds.polyProjectCurve('curveToProject', 'convexPolygonName', ch=1, direction=[0,0,1],pointsOnEdges=0,automatic=1)
            #===============================================================================

            if projCrvOnPoly:
                convexName, convexMesh = create_convexHull(target)  # convexHull highly improve ray tracing results

                for x in range(cmds.getAttr(crv + '.spans')):
                    cv = crv + '.cv[' + str(x) + ']'
                    sourcePoint = api.MFloatPoint(cmds.xform(cv, q=1, ws=1, t=1))
                    # the offset vector give us a better impact while casting the rays we are testing values until hitPoint
                    # 100 means a boundingbox.height/100 precision

                    # test with expo: for x in reversed(range(1,51)): print math.exp(x/10.0)
                    offsetIterRange = [300, 200, 100, 90, 80, 70, 60, 50, 40, 30, 20, 10, 9, 8, 7, 6, 5, 4, 3, 2]
                    for offsetIter in offsetIterRange:
                        offsetVector = api.MFloatVector(0, (bbox.height) / offsetIter)
                        rayDirection = api.MFloatVector(center) - api.MFloatVector(sourcePoint) + offsetVector
                        sourcePointY = api.MFloatPoint(sourcePoint[0] , sourcePoint[1] + offsetVector.y, sourcePoint[2])
                        hitPoint = convexMesh.closestIntersection(sourcePointY, rayDirection, api.MSpace.kWorld, 1, False, tolerance=1)[0]

                        # Debug projection
                        # cmds.spaceLocator(n='source_'+str(x),p=list(sourcePointY)[:-1])
                        # cmds.spaceLocator(n='hitPoint_'+str(x),p=list(hitPoint)[:-1])
                        # cmds.spaceLocator(n='final_'+str(x),p=[hitPoint.x,center[1],hitPoint.z])

                        # if a hitPoint was found then break the offsetIter loop
                        if not [hitPoint.x, hitPoint.y, hitPoint.z] == [0, 0, 0]:
                            break

                        # None of the offsetIter worked, return the source point instead
                        elif [hitPoint.x, hitPoint.y, hitPoint.z] == [0, 0, 0] and offsetIter == offsetIterRange[-1]:
                            hitPoint = api.MFloatVector(sourcePoint)

                    # set current cv to projection result
                    cmds.xform(cv, ws=1, t=[hitPoint.x, center[1], hitPoint.z])

                cmds.delete(convexName)
            not tmpMesh or cmds.delete(tmpMesh)

    #===========================================================================
    # # This happen in any case, also if a curve is given.
    #===========================================================================

    # parent grp of the curve or create <name>_GRP
    defaultCrvParent = name + '_GRP'
    if not root:
        root = cmds.listRelatives(crv, p=1)[0] if cmds.listRelatives(crv, p=1) else cmds.group(em=True, n=defaultCrvParent)
        if root == defaultCrvParent:
            cmds.parent(crv, root)
        crv = crv if not defaultCrv else cmds.rename(crv, defaultCrv)
    # or use the given root (check if not parent already)
    else:
        if cmds.listRelatives(crv, p=1) and not cmds.listRelatives(crv, p=1)[0] == root:
            cmds.parent(crv, root)
        elif not cmds.listRelatives(crv, p=1):
            cmds.parent(crv, root)

    cmds.makeIdentity(crv, a=1)
    cmds.CenterPivot(crv)
    crvShape = cmds.listRelatives(crv, s=True)[0]
    crvPos = cmds.xform(crv, q=1, ws=1, rp=1)

    return root, crv, crvShape, crvPos


def convert_selection_to_curve():
    if cmds.nodeType(cmds.ls(sl=1)[-1]) == 'mesh' and '.e[' in cmds.ls(sl=1)[-1]:
        curve = cmds.polyToCurve(form=1, degree=3, ch=0)[0]
    else:
        raise RuntimeError('Select a edge loop !')
    return curve
