"""
.. module:: attributes
   :synopsis: Collection of helperfunctions for attributes

.. moduleauthor:: andreasg
"""

# python-libraries
import yaml

# maya imports
import pymel.core as pm

# package imports
from millrigger.utils.data import RigData
from millrigger.globals import rig as RIG
import millrigger.utils.name as mname


# =============================================================================
# rig attributes --------------------------------------------------------------
# =============================================================================

def add_generic_switch(node, attr_name, nicename=None, default=1, keyable=False):
    """
    A generic function for adding an integer on/off attribute
    :param default:
    :return:
    """
    if nicename:
        node.addAttr(attr_name, nn=nicename, at='long', min=0, max=1, dv=default, k=keyable)
    else:
        node.addAttr(attr_name, at='long', min=0, max=1, dv=default, k=keyable)
    attr = node.attr(attr_name)
    if keyable is False:
        attr.set(channelBox=True)
    return attr


def add_generic_blend(node, attr_name, nicename=None, default=1.0, min=0.0, max=1.0, keyable=True):
    """
    A generic function for adding an integer on/off attribute
    :param default:
    :return:
    """
    if nicename:
        node.addAttr(attr_name, nn=nicename, min=min, max=max, dv=default, k=keyable)
    else:
        node.addAttr(attr_name, min=min, max=max, dv=default, k=keyable)
    attr = node.attr(attr_name)
    if keyable is False:
        attr.set(channelBox=True)
    return attr


def add_headline(node, attr_name):
    ''' adds a "headline"- to the attributes

    :param node: node to receive the attribute.
    :type node: PyNode

    :param attr_name: attribute-name
    :type attr_name: string

    :rType: PyNode-attribute
    '''
    attr_name = attr_name.upper()
    node.addAttr(attr_name, at='enum', nn='_', en=attr_name)
    node.attr(attr_name).set(cb=True, l=True)
    return node.attr(attr_name)


def add_visibility_attr(node, items, name=None, nicename=None, default=1, connect=False):
    """
    For each name in items, adds a displayable integer for each one

    :param node: the node to add the attribute to
    :param items: the items to add visibility switches for
    :param name: name for attribute
    :param nicename: nicename for attribute
    :param default: the default value of the attrs
    :param connect: if True, connect the items to
    :return: list of attrs
    """
    out = []
    if not isinstance(items, list):
        items = [items]

    # single attribute drives several visibilities
    if name:
        if not node.hasAttr(name):
            if nicename:
                node.addAttr(name, nn=nicename, at='long', min=0, max=1, dv=default)
            else:
                node.addAttr(name, at='long', min=0, max=1, dv=default)
        else:
            node.attr(name).set(default)
        attr = node.attr(name)
        attr.set(k=False, cb=True)
        if connect:
            for item in items:
                shape = item.getShape(type="nurbsCurve", noIntermediate=True)
                if shape:
                    attr >> shape.visibility
        return attr

    # each item has individual visibility-attribute
    for item in items:
        if isinstance(item, pm.PyNode):
            namer = mname.Name(item)
            name = namer.side.lower()
            name += namer.part.capitalize()
            if namer.partindex:
                name += namer.partindex
            if namer.index:
                name += namer.index
        else:
            name = item

        attr_name = name + 'Visibility'
        node.addAttr(attr_name, at='long', min=0, max=1, dv=default)
        attr = node.attr(attr_name)
        attr.set(k=False, cb=True)
        if connect:
            shape = item.getShape(type="nurbsCurve", noIntermediate=True)
            attr >> shape.visibility
        out.append(attr)
    return out


def add_stretchy_attr(node, tag='', default=0.0):
    '''
    Creates set of stretch-attributes on given node.

    :param node: node to receive the attribute.
    :type node: PyNode

    :param item_list: list of lowercase tags
    :type item_list: list of strings

    :returns: adds headline, "stretchy" and "stretchy_*tag*" to attributes
    :rType: Attribute
    '''
    attr_name = 'stretchy' + tag.capitalize()
    node.addAttr(attr_name, dv=default, min=0.0, max=1.0, k=True)
    return pm.Attribute(node.attr(attr_name))


def add_length_offset_attr(node, tag='', min=None, max=None, headline=True):
    """
    Adds a lengthOffset attribute to a given node
    """
    attr_name = 'lengthOffset' + tag.capitalize()

    if headline:
        add_headline(node=node, attr_name="LENGTH")

    # make the arguments as a dict
    args = {"dv": 0.0, "k": True}
    if min is not None:
        args["min"] = -abs(min)
    if max is not None:
        args["max"] = abs(max)

    # make the attr
    node.addAttr(attr_name, **args)
    return pm.Attribute(node.attr(attr_name))


def add_bendy_attr(node, data=None, detail=True):
    '''
    Creates set of bendy-attributes on given node.

    :param node: node to receive the attribute.
    :type node: PyNode

    :param data: if data is given elements will just be added to existing RigData-class
    :type data: RigDataClass

    :param detail: if data is given elements will just be added to existing RigData-class
    :type detail: RigDataClass

    :returns: adds headline, "bendyVisibility" (and "bendyDetailVisibility") to attributes
    :rType: RigData
    '''

    attr_data = data or RigData()
    attr_data.headline = add_headline(node, 'bendy')

    node.addAttr('bendyVisibility', at='long', min=0, max=1, dv=1)
    node.bendyVisibility.set(k=False, cb=True)
    attr_data.bendyVisibility = pm.Attribute(node.bendyVisibility)

    if detail:
        node.addAttr('bendyDetailVisibility', at='long', min=0, max=1, dv=1)
        node.bendyDetailVisibility.set(k=False, cb=True)
        attr_data.bendyDetailVisibility = pm.Attribute(node.bendyDetailVisibility)

    return attr_data


def add_footroll_visibility_attr(node, data=None, controls=None, ankle=None, floor=None):
    '''
    Creates set of footroll-attributes on given node.

    :param node: node to receive the attribute.
    :type node: PyNode

    :param data: if data is given elements will just be added to existing RigData-class
    :type data: RigDataClass

    :param controls: List of controls. Visibility is driven by newly created "rollVis"-attribute
    :type controls: List of PyNodes

    :param ankle: ankle-control
    :type ankle: Pynode

    :returns: adds visibility-attributes
    :rType: RigData
    '''

    attr_data = data or RigData()
    if ankle:
        attr_data.ankleVis = add_generic_switch(node,
                                                attr_name='ankleVis',
                                                nicename='Ankle Visibility',
                                                default=0)
    if controls:
        attr_data.rollVis = add_generic_switch(node,
                                               attr_name='rollVis',
                                               nicename='Roll Visibility',
                                               default=0)
    if floor:
        attr_data.floorVis = add_generic_switch(node,
                                                attr_name='floorVis',
                                                nicename='Floor Visibility',
                                                default=0)
    return attr_data


def add_footroll_attr(node, data=None, controls=[], ankle=None, floor=None):
    '''
    Creates set of footroll-attributes on given node.

    :param node: node to receive the attribute.
    :type node: PyNode

    :param data: if data is given elements will just be added to existing RigData-class
    :type data: RigDataClass

    :param controls: List of controls. Visibility is driven by newly created "rollVis"-attribute
    :type controls: List of PyNodes

    :param ankle: ankle-control
    :type ankle: Pynode

    :returns: adds headline, "footroll" to attributes
    :rType: RigData
    '''

    attr_data = data or RigData()
    # visibilities first
    # check for a shape on the ankle, otherwise it's an SRT
    if ankle.listRelatives(s=True, type="nurbsCurve"):
        attr_data.ankleVis = add_visibility_attr(node, [ankle],
                                                 name='ankleVis',
                                                 nicename='Ankle Visibility',
                                                 default=0,
                                                 connect=True)
    if floor:
        attr_data.floorVis = add_visibility_attr(node, [floor],
                                                 name='floorVis',
                                                 nicename='Floor Visibility',
                                                 default=0,
                                                 connect=True)

    if controls:
        attr_data.rollVis = add_visibility_attr(node, controls,
                                                name='rollVis',
                                                nicename='Roll Visibility',
                                                default=0,
                                                connect=True)
        attr_data.headline = add_headline(node, 'footroll')
    else:
        attr_data.headline = add_headline(node, 'footroll')
        node.addAttr('roll', dv=0.0, k=True)
        attr_data.roll = node.roll
        attr_data.headline = add_headline(node, 'thresholds')
        node.addAttr('bend', dv=22.5, k=True)
        attr_data.bend = node.bend
        node.addAttr('straight', dv=45.0, k=True)
        attr_data.straight = node.straight

    node.addAttr('bank', dv=0.0, k=True)
    attr_data.bank = node.bank

    attr_data.headline = add_headline(node, 'swivel')
    node.addAttr('swivelPivot', at='enum', nn='Pivot', en='heel:ball:toes')
    node.swivelPivot.set(k=True)
    attr_data.swivelPivot = node.swivelPivot
    node.addAttr('swivel', dv=0.0, k=True)
    attr_data.swivel = node.swivel

    return attr_data


def add_foot_attr(node, data=None):
    '''
    Creates set of swivel and bank-attributes on given node.

    :param node: node to receive the attribute.
    :type node: PyNode

    :param data: if data is given elements will just be added to existing RigData-class
    :type data: RigDataClass

    :returns: adds headline, "foot" to attributes
    :rType: RigData
    '''
    attr_data = data or RigData()
    attr_data.headline = add_headline(node, 'foot')
    node.addAttr('swivelPivot', at='enum', nn='Pivot', en='heel:ball:toes')
    node.swivelPivot.set(k=True)
    attr_data.swivelPivot = node.swivelPivot
    node.addAttr('swivel', dv=0.0, k=True)
    attr_data.swivel = node.swivel
    node.addAttr('bank', dv=0.0, k=True)
    attr_data.bank = node.bank
    return attr_data


def add_fkik_blend_attr(node, digit=False, default=1.0):
    """
    Creates fkik blend attribute.

    :param node: node to receive the attribute.
    :type node: PyNode

    :param digit: if True adds "digit" to the blendAttr
    :type digit: Boolean

    :param default: default value, can be float or "ik"/"fk"
    :type node: float/string
    """
    if isinstance(default, str):
        if default == "fk":
            default = 0.0
        elif default == "ik":
            default = 1.0
        else:
            raise ValueError("default should be 'ik', 'fk' or a float value")

    if digit is True:
        node.addAttr('digitFkikBlend', dv=default, min=0, max=1, k=True)
        return node.digitFkikBlend
    else:
        node.addAttr('fkikBlend', dv=default, min=0, max=1, k=True)
        return node.fkikBlend


def add_fkik_attr(node, headline=True, digit=False, default=1.0, data=None):
    """
    Creates fkik blend attribute.

    :param node: node to receive the attribute.
    :type node: PyNode

    :param headline: if True adds a "FKIK"-headline
    :type digit: Boolean

    :param digit: if True adds "digit" to the blendAttr
    :type digit: Boolean

    :param default: default value, can be float or "ik"/"fk"
    :type node: float/string
    """
    if isinstance(default, str):
        if default == "fk":
            default = 0.0
        elif default == "ik":
            default = 1.0
        else:
            raise ValueError("default should be 'ik', 'fk' or a float value")

    attr_data = data or RigData()
    attr_data.headline = add_headline(node, 'fkik')
    node.addAttr('fkikBlend', dv=default, min=0, max=1, k=True)
    attr_data.fkikBlend = node.fkikBlend
    if digit is True:
        node.addAttr('digitFkikBlend', dv=default, min=0, max=1, k=True)
        attr_data.digitFkikBlend = node.digitFkikBlend

    return attr_data


def add_eye_attr(node, data=None):
    '''
    Creates set of bendy-attributes on given node.

    :param node: node to receive the attribute.
    :type node: PyNode

    :param data: if data is given elements will just be added to existing RigData-class
    :type data: RigDataClass

    :returns: "blinkLeft", "blinkLeft", headline, "pupilSize" to attributes
    :rType: RigData
    '''

    attr_data = data or RigData()

    node.addAttr('blinkLeft', min=0, max=1, dv=0.0, k=True)
    attr_data.blinkLeft = pm.Attribute(node.blinkLeft)

    node.addAttr('blinkRight', min=0, max=1, dv=0.0, k=True)
    attr_data.blinkRight = pm.Attribute(node.blinkRight)

    attr_data.headline = add_headline(node, 'pupil')
    node.addAttr('pupilSize', nn='size', min=-1, max=1, dv=0.0, k=True)

    return attr_data


def add_aim_attr(node):
    '''
    Creates set of fkik-attributes on given node.

    :param node: node to receive the attribute.
    :type node: PyNode

    :rType: Attribute
    '''
    node.addAttr('aimBlend', dv=1.0, min=0, max=1, k=True)
    return node.aimBlend


def add_follow_attr(node, default=0.0):
    """
    Adds a follow attribute

    :param default:
    :return:
    """
    node.addAttr('follow', dv=default, min=0, max=1, k=True)
    return node.follow


def add_tiproll_attr(node, default=0.0):
    """
    Adds a tiproll attribute

    :param default:
    :return:
    """
    node.addAttr('tiproll', dv=default, min=-90, max=90, k=True)
    return node.tiproll


def add_space_attr(node, tag='ik', custom=None,
                   default_world=0.0, default_custom=0.0,
                   nice_name=None, data=None):
    '''
    Creates set of fk-attributes on given node.

    :param node: node to receive the attribute.
    :type node: PyNode

    :param tag: 'fk', 'ik', 'aim' or 'polevec'
    :type tag: String

    :param default_world: defaultvalue for world-blend-attribute
    :type default_world: Float (0.0-1.0)

    :param default_custom: defaultvalue for custom-blend-attribute
    :type default_custom: Float (0.0-1.0)

    :param nice_name: set the NiceName for the world-attribute if given
    :type nice_name: String

    :param data: if data is given elements will just be added to existing RigData-class
    :type data: RigDataClass

    :returns: "fkSpace", "ikSpace" or 'aimSpace' to attributes
    :rType: Attribute
    '''
    attr_data = data or RigData()

    if tag is None:
        attr_name = 'space'
    else:
        attr_name = tag + 'Space'
    attr_data.headline = add_headline(node, attr_name)

    # workdspace (world <-> local)
    if not pm.objExists(node.name() + '.world'):
        if nice_name is None:
            node.addAttr('world', min=0, max=1, dv=default_world, at='double', k=True)
        else:
            node.addAttr('world', nn=nice_name, min=0, max=1, dv=default_world, at='double', k=True)
    attr_data.world = pm.Attribute(node.world)

    # customspace (local <-> custom)
    attr_data.custom = None
    if custom is True:
        if not pm.objExists(node.name() + '.custom'):
            node.addAttr('custom', min=0, max=1, dv=default_custom, at='double', k=True)
        attr_data.custom = pm.Attribute(node.custom)

    return attr_data


def add_polevector_attr(node, data=None, make_twist=False, default_mode="aim"):
    '''
    Creates set of polevector-attributes on given node.

    :param node: node to receive the attribute.
    :type node: PyNode

    :param data: if data is given elements will just be added to existing RigData-class
    :type data: RigDataClass

    :returns: adds headline, "twist_offset", "ik_follow" to attributes
    :rType: RigDataClass
    '''

    attr_data = data or RigData()

    attr_data.headline = add_headline(node, 'polevector')

    # get the default mode as an integer
    default_mode = [s.lower() for s in RIG.POLE_PLANES].index(default_mode.lower())

    node.addAttr('polePlane', at='enum', en=":".join(RIG.POLE_PLANES), dv=default_mode)
    node.polePlane.set(cb=True, l=False)
    attr_data.polePlane = node.polePlane

    if make_twist:
        attr_data.twistOffset = add_twist_offset_attr(node, headline=False)
    return attr_data


def add_twist_offset_attr(node, headline=True):
    """
    creates a twist offset attribute
    :return:
    """
    if headline:
        add_headline(node, "TWIST")
    node.addAttr('twistOffset', dv=0.0, k=True)
    return node.twistOffset


def add_multibone_attr(node, data=None):
    '''
    Creates set of multi-bone-attributes on given node.

    :param node: node to receive the attribute.
    :type node: PyNode

    :param data: if data is given elements will just be added to existing RigData-class
    :type data: RigDataClass

    :returns: adds "twist_distribute" to attributes
    :rType: RigDataClass
    '''
    attr_data = data or RigData()

    attr_data.headline = add_headline(node, 'multibone')

    node.addAttr('twistDistribute', dv=1.0, min=0, max=1, k=True)
    attr_data.twistDistribute = pm.Attribute(node.twistDistribute)

    return attr_data


def add_zipper_attr(node, vertical=False, data=None):
    '''
    Creates set of zipper-attributes on given node.

    :param node: node to receive the attribute.
    :type node: PyNode

    :param vertical: use "upper" and "lower" instead of "right" and "left"
    :type vertical: Boolean or None

    :param data: if data is given elements will just be added to existing RigData-class
    :type data: RigDataClass

    :returns: adds "ZIPPER"-headline, 'zipStart', 'zipEnd', 'smoothStart', 'smoothEnd' to attributes
    :rType: RigDataClass
    '''
    vertical_dict = {None: ('Start', 'End'),
                     True: ('Upper', 'Lower'),
                     False: ('Right', 'Left')}

    attr_data = data or RigData()
    attr_data.headline = add_headline(node, 'zipper')
    node.addAttr('zipBlend', min=0.0, max=1.0, dv=0.5, k=True)
    node.addAttr('zip' + vertical_dict[vertical][0], min=-0.5, max=1.5, dv=0, k=True)
    node.addAttr('zip' + vertical_dict[vertical][1], min=-0.5, max=1.5, dv=1.0, k=True)
    node.addAttr('zipSmooth' + vertical_dict[vertical][0], min=0.01, max=1.0, dv=.5, k=True)
    node.addAttr('zipSmooth' + vertical_dict[vertical][1], min=0.01, max=1.0, dv=.5, k=True)
    attr_data.zipBlend = pm.Attribute(node.zipBlend)
    attr_data.zipStart = pm.Attribute(node.attr('zip' + vertical_dict[vertical][0]))
    attr_data.zipEnd = pm.Attribute(node.attr('zip' + vertical_dict[vertical][1]))
    attr_data.zipSmoothStart = pm.Attribute(node.attr('zipSmooth' + vertical_dict[vertical][0]))
    attr_data.zipSmoothEnd = pm.Attribute(node.attr('zipSmooth' + vertical_dict[vertical][1]))

    return attr_data


def add_millspring_attr(node, data=None, shared=None, start_frame=False):
    '''
    Creates set of millspring-attributes on given node.

    :param node: node to receive the attribute.
    :type node: PyNode

    :param data: if data is given elements will just be added to existing RigData-class
    :type data: RigDataClass

    :returns: adds headline and all the useraccessible millSpring-attributes
    :rType: RigData
    '''

    attr_data = data or RigData()
    attr_data.local = RigData()
    attr_data.chain = RigData()

    # local attributes
    if not pm.attributeQuery("DYNAMICS", n=node, exists=True):
        add_headline(node, 'DYNAMICS')
        node.addAttr('angularStiffness', dv=0.1, k=True)
        node.angularStiffness.set(cb=True)
        node.addAttr('angularDamping', dv=0.01, k=True)
        node.angularDamping.set(cb=True)
        node.addAttr('maxAngle', min=0, max=180, dv=180, at='double', k=True)
        node.maxAngle.set(cb=True)
        node.addAttr('maxAngleBounce', min=0, max=1, dv=1, at='double', k=True)
        node.maxAngleBounce.set(cb=True)

    attr_data.local.angularStiffness = node.angularStiffness
    attr_data.local.angularDamping = node.angularDamping
    attr_data.local.maxAngle = node.maxAngle
    attr_data.local.maxAngleBounce = node.maxAngleBounce

    if not shared or not pm.attributeQuery("CHAIN", n=shared, exists=True):
        add_headline(shared, 'CHAIN')
        shared.addAttr('enable', dv=True, at='bool', k=True)
        shared.enable.set(cb=True)
        shared.addAttr('cache', dv=True, at='bool', k=True)
        shared.cache.set(cb=True)
        shared.addAttr('startFrame', dv=1, at='double')
        shared.startFrame.set(k=False)
        shared.addAttr('mass', dv=1, k=True)
        shared.mass.set(cb=True)
        shared.addAttr('noiseMagnitude', min=0.0, dv=0.0, k=True)
        shared.addAttr('noiseFrequency', dv=0.0, k=True)
        shared.addAttr('gravityMagnitude', dv=0, k=True)
        attr_data.gravityMagnitude = shared.gravityMagnitude
        add_vector_attr(shared, "gravityVector", value=(0, -1, 0), cb=True)
        shared.gravityVector.set(cb=True)
        shared.addAttr('windMagnitude', dv=0, k=True)
        attr_data.windMagnitude = shared.windMagnitude
        add_vector_attr(shared, "windVector", value=(0, 0, 0), cb=True)
        shared.windVector.set(cb=True)

    attr_data.chain.mass = shared.mass
    attr_data.chain.noiseMagnitude = shared.noiseMagnitude
    attr_data.chain.noiseFrequency = shared.noiseFrequency
    attr_data.chain.gravityVector = shared.gravityVector
    attr_data.chain.windVector = shared.windVector

    attr_data.enable = shared.enable
    attr_data.cache = shared.cache
    attr_data.startFrame = shared.startFrame

    return attr_data


def add_suspension_attr(node, data=None):
    '''
    Creates set of millspring-attributes on given node that are needed for the suspension-module.

    :param node: node to receive the attribute.
    :type node: PyNode

    :param data: if data is given elements will just be added to existing RigData-class
    :type data: RigDataClass

    :returns: adds headline and all the useraccessible millSpring-attributes
    :rType: RigData
    '''

    attr_data = data or RigData()

    # adding required Attributes
    node.addAttr('EXTRAS', en='__', at='enum', k=False)
    node.EXTRAS.set(cb=True)
    node.EXTRAS.lock()
    node.addAttr('offsetVis', dv=0, k=False, minValue=0, maxValue=1, at=int)
    node.offsetVis.set(cb=True)
    node.addAttr('DYNAMICS', en='___', at='enum', k=False)
    node.DYNAMICS.set(cb=True)
    node.DYNAMICS.lock()
    node.addAttr('enable', at=bool, k=False, dv=0)
    node.enable.set(cb=True)
    node.addAttr('cache', at=bool, k=False, dv=1)
    node.cache.set(cb=True)
    node.addAttr('startFrame', dv=1, k=False, at='long')
    node.addAttr('blend', dv=0, k=False, minValue=0, maxValue=1, at=float)
    node.blend.set(cb=True)
    node.addAttr('stiffness', dv=2.0, k=False, at=float)
    node.stiffness.set(cb=True)
    node.addAttr('dampening', dv=0.18, k=False, at=float)
    node.dampening.set(cb=True)
    node.addAttr('mass', dv=1, k=False, at=float)
    node.mass.set(cb=True)
    node.addAttr('maxAngle', dv=70, k=False, at=float)
    node.maxAngle.set(cb=True)
    node.addAttr('bodyRollMultiplier', dv=0.05, k=False, at=float)
    node.bodyRollMultiplier.set(cb=True)

    # provide easy access to attributes
    attr_data.offsetVis = node.offsetVis
    attr_data.enable = node.enable
    attr_data.cache = node.cache
    attr_data.startFrame = node.startFrame
    attr_data.blend = node.blend
    attr_data.stiffness = node.stiffness
    attr_data.dampening = node.dampening
    attr_data.mass = node.mass
    attr_data.maxAngle = node.maxAngle
    attr_data.bodyRollMultiplier = node.bodyRollMultiplier


def add_millrigcontrol_attr(ctrl):
    """
    Creates a stringAttribute as identifier for MillRig.
    If MillRig finds this attribute the controlshape will be saved and restored while
    switching between Live- and Layout-mode

    :param ctrl: control to receive the attribute.
    :type ctrl: PyNode with shape

    :returns: Attribute "millRigControlCurve"
    :rType: Pymel-Attribute
    """
    ctrl.addAttr('millRigControlCurve', at="message")
    return ctrl.millRigControlCurve

# =============================================================================
# generic attributes ----------------------------------------------------------
# =============================================================================

def add_switch_attr(node, attr_name, nice_name=None, default=1):
    ''' adds a not-keyable switch-attribute to the node.
    :param node: node to receive the attribute.
    :type node: PyNode

    :param node: node to receive the attribute.
    :type node: PyNode
    :param attr_name: attribute-name
    :type attr_name: string
    :rType: PyNode-attribute
    '''
    if pm.attributeQuery(attr_name, node=node, exists=True) == False:
        if nice_name:
            node.addAttr(attr_name, nn=nice_name, min=0, max=1, dv=default, at='short')
        else:
            node.addAttr(attr_name, min=0, max=1, dv=default, at='short')
        node.attr(attr_name).set(cb=True)
    return node.attr(attr_name)


def add_blend_attr(node, attr_name, nice_name=None, headline=None, default=1):
    ''' adds a not-keyable switch-attribute to the node.
    :param node: node to receive the attribute.
    :type node: PyNode

    :param node: node to receive the attribute.
    :type node: PyNode
    :param attr_name: attribute-name
    :type attr_name: string
    :param default: default-value
    :type default: float
    :rType: PyNode-attribute
    '''
    if not pm.attributeQuery(attr_name, node=node, exists=True):
        if headline is not None:
            add_headline(node, headline)
        if nice_name:
            node.addAttr(attr_name, nn=nice_name, min=0, max=1, dv=default, at='double')
        else:
            node.addAttr(attr_name, min=0, max=1, dv=default, at='double')
        node.attr(attr_name).set(k=True)
    return node.attr(attr_name)


def add_rotateorder_attr(node):
    '''
    adds rotationorder attribute on nodes that match the transform mnode
    rotationorder attribute

    :param node: node to receive the attribute.
    :type node: PyNode

    :rType: PyNode-attribute
    '''

    if not pm.attributeQuery('rotateOrder', node=node, exists=True):
        node.addAttr('rotateOrder', sn='ro', nn='Rotate Order',
                     at='enum', en='xyz:yzx:zxy:xzy:yxz:zyx', k=False)
        node.rotateOrder.set(cb=True)
    return node.rotateOrder


def add_curvelength_attr(node, curve, absolute=False, world_length=False, global_scale=None,
                         attr_name="curveLength"):
    '''
    adds a read-only, driven attribute to show the length of a curve

    :param node: the node to be given the attribute
    :param curve: the curve shape that needs to be driven
    :param absolute: if True then the attr will display the absolute length of the curve.
    If False then the attribute will be a factor of the original length
    :param world_length: whether to use the world or local space of the curve
    :param global_scale: if given, divides the length by the global scale
    :return:
    '''
    namer = mname.Name(curve)

    # get the length attr
    if curve.type() == "transform":
        curve = curve.getShape()

    if curve.type() == "nurbsCurve":
        # get the curve info
        curve_info = pm.createNode("curveInfo", n=namer.replace(suffix="curveInfo"))
        if world_length:
            input_curve = curve.worldSpace
        else:
            input_curve = curve.local
        input_curve >> curve_info.inputCurve
        length = curve_info.arcLength

    elif curve.type() == "millMatrixRamp":
        length = curve.outLength
    else:
        raise TypeError("curve must be of type nurbsCurve or millMatrixRamp, recieved '%s'" % curve.type())

    # get the driver attr
    if global_scale is not None:
        gdiv = pm.createNode("multiplyDivide", n=namer.replace(add_to_tags="global",
                                                               suffix="DIV")
                             )
        gdiv.operation.set(2)  # divide
        length >> gdiv.input1X
        global_scale >> gdiv.input2X
        length = gdiv.outputX

    # get the driver
    if absolute:
        driver = length
    else:
        div = pm.createNode("multiplyDivide", n=namer.replace(add_to_tags="length",
                                                              suffix="DIV")
                            )
        div.operation.set(2)  # divide
        length >> div.input1X
        div.input2X.set(length.get())
        driver = div.outputX

    # make the attr
    node.addAttr(attr_name, dv=0.0, k=False)
    node.attr(attr_name).set(channelBox=True)
    driver >> node.attr(attr_name)
    return node.attr(attr_name)


def add_matrix_attr(node, attr_name):
    ''' adds a matrix-attribute to a node

    :param node: node to receive the attribute.
    :type node: PyNode
    :param attr_name: attribute-name
    :type attr_name: string
    :rType: PyNode-attribute
    '''

    if not pm.attributeQuery(attr_name, node=node, exists=True):
        node.addAttr(attr_name, at='fltMatrix')
    return node.attr(attr_name)


def add_vector_attr(node, attr_name, value=(0.0, 0.0, 0.0), k=True, cb=True):
    ''' adds a vector-attribute to a node

    :param node: node to receive the attribute.
    :type node: PyNode
    :param attr_name: attribute-name
    :type attr_name: string
    :param value: default-value
    :type value: vector
    :param k: appears in channelbox as keyable
    :type k: Boolean
    :param cb: appears in channelbox as not keyable
    :type cb: Boolean
    :rType: PyNode-attribute
    '''

    if not pm.attributeQuery(attr_name, node=node, exists=True):
        node.addAttr(attr_name, at='double3')
        node.addAttr(attr_name + 'X', dv=value[0], at='double', parent=attr_name, k=k)
        node.addAttr(attr_name + 'Y', dv=value[1], at='double', parent=attr_name, k=k)
        node.addAttr(attr_name + 'Z', dv=value[2], at='double', parent=attr_name, k=k)
        if cb:
            for axis in 'XYZ':
                node.attr(attr_name + axis).set(cb=True)
    return node.attr(attr_name)


def add_mirror_behaviour_attr(node, default=RIG.MIRROR_MODES[1]):
    """
    A generic function for adding an integer on/off attribute
    :param default:
    :return:
    """
    default = RIG.MIRROR_MODES.index(default.upper())
    try:
        attr = node.attr('mirrorMode')
        attr.unlock()
        attr.set(default)
    except pm.MayaAttributeError:
        node.addAttr('mirrorMode', at='enum', en=":".join(RIG.MIRROR_MODES),
                     dv=default)
        attr = node.mirrorMode

    attr.lock()
    return attr


# =============================================================================
# functions -------------------------------------------------------------------
# =============================================================================

def link_srt(src, *target_list, **kwargs):
    '''
    quick way to link several "srt" and jointOrient-attributes

    :param src: all target-objects will be linked to this node
    :type src: PyNode-Transform
    :param target_list: all given transforms will be linked to the src-transforms
    :type target_list: list of PyNode-Transforms
    :param srt: links all given attributes found in the passed string. Valid values are "srtj"
    :type srt: string
    :param axis: if given, the elements of the compound attributes are linked. Valid values are "xyz"
    :type axis: string
    '''

    srt = kwargs.get('srt', 'srtj').lower()
    axis = kwargs.get('axis', '').lower()
    if axis == '':
        attr_list = [attr for attr in srt]
    else:
        attr_list = ['{0}{1}'.format(attr, xyz) for attr in srt for xyz in axis]

    for tgt in target_list:
        link_attr(src, tgt, attr_list)


def link_attr(src, tgt, attr_list):
    '''
    quick method to link 2 nodes by the given attr_list

    :param src: target will be linked to this node
    :type src: PyNode-Transform
    :param tgt: source will drive this node
    :type tgt: PyNode-Transform
    :param attr_list: links all given attributes (shortname) found in the passed list
    :type attr_list: list of strings
    '''

    if 'r' in attr_list or 'rx' in attr_list or 'ry' in attr_list or 'rz' in attr_list:
        attr_list.append('ro')

    for attr in attr_list:
        try:
            src.attr(attr) >> tgt.attr(attr)
        except pm.MayaAttributeError:
            pass


def transfer_connections(old, new, plugs=[], keep=False):
    '''
    quick method to transfer plugs of nodes by the given attr_list

    :param old: target will be linked to this node
    :type old: PyNode-Transform
    :param new: source will drive this node
    :type new: PyNode-Transform
    :param plugs: list of attributeNames that should be connected
    :type plugs: list of strings
    :param keep: if True, keeps the in-connections of the old node
    :type keep: boolean
    '''
    existing_plugs = old.listConnections(p=True, c=True)
    if plugs:
        existing_plugs[:] = [plug[0] for plug in existing_plugs if plug[0].attrName() in plugs]
    else:
        existing_plugs[:] = [plug[0] for plug in existing_plugs]

    for plug in existing_plugs:
        transfer_plug(plug, new, keep=keep)


def transfer_plug(plug, new, keep=False):
    '''
    quick method to transfer a connection from one node to another

    :param plug: the plug you want to transfer to the new object
    :type plug: PyNode-Attribute
    :param new: the node that should be connected
    :type new: PyNode-Transform
    :param keep: if True, keeps the in-connections of the old node
    :type keep: boolean
    '''
    attr = plug.attrName()
    lock_state = plug.get(l=True)
    plug.set(l=False)
    new_plug = new.attr(attr)
    new_lock_state = new_plug.get(l=True)

    if plug.isSource():  # plug is output
        out_plugs = plug.outputs(p=True)
        print "OUT:", out_plugs
        for out_plug in out_plugs:
            out_lock_state = out_plug.get(l=True)
            new_plug >> out_plug
            out_plug.set(l=out_lock_state)

    else:  # plug is input
        in_plugs = plug.inputs(p=True)
        print "IN:", in_plugs
        for in_plug in in_plugs:
            in_lock_state = in_plug.get(l=True)
            in_plug >> new_plug
            in_plug.set(l=in_lock_state)
            if not keep:
                pm.disconnectAttr(in_plug, plug)
    new_plug.set(l=new_lock_state)
    plug.set(l=lock_state)


def lock_hide_srt(node, srt=""):
    ''' locks and hides the srt attributes of a node

    :param node: the node that should be connected
    :type node: PyNode-Transform

    :param srt: the attribute that should be affected. Valid values are 'srt'
    :type srt: string
    '''
    srt = srt.lower()
    for item in srt:
        node.attr(item).set(l=False)
        for axis in 'xyz':
            node.attr(item + axis).set(l=True, k=False)


def lock_hide_axis(node, pos="", rot="", scl=""):
    ''' locks and hides the srt attributes of a node

    :param node: the node that should be connected
    :type node: PyNode-Transform

    :param pos: Which translation axis to lock
    :type pos: string

    :param rot: Which rotation axis to lock
    :type rot: string

    :param scl: Which scale axis to lock
    :type scl: string
    '''
    dic = {"t": pos.lower(),
           "r": rot.lower(),
           "s": scl.lower()}

    for item in dic:
        for axis in dic[item]:
            node.attr(item + axis).set(l=True, k=False)
    if rot == "":
        node.ro.set(lock=False, cb=True)


# pose functions

def store_pose(node, pose_name='bindPose', pose_attr="millPose"):
    '''
    create or use existing attribute to save all keyable/visible attributes
    as a dictionary-string

    :param node: Any node...
    :type node: PyNode
    :param pose_name: "bindPose", "groomPose", "tPose", ...
    :type pose_name: String
    :param pose_attr: name of dictionary-attribute, standard is "millPose"
    :type pose_attr: String
    :rtype: PyAttribute
    '''
    # create pose string-attribute

    if not pm.attributeQuery(pose_attr, node=node, exists=True):
        node.addAttr(pose_attr, dt='string')

    pose_attr = node.attr(pose_attr)
    pose_string = pose_attr.get() or ""
    pose_dict = yaml.load(pose_string) or {}

    # build attribute list
    channel_box_list = [at for at in node.listAttr(cb=1) if not at.isLocked()] or []
    channel_box_list[:] = [str(item.shortName()) for item in channel_box_list]
    keyable_list = [at for at in node.listAttr(k=1, sn=True) if not at.isLocked()] or []
    keyable_list[:] = [str(item.shortName()) for item in keyable_list]
    attr_list = set(channel_box_list + keyable_list)

    # create dictionary with attribute-values
    attr_dict = {}
    for at in attr_list:
        attr_dict[at] = node.attr(at).get()
    pose_dict[pose_name] = attr_dict
    pose_attr.set(yaml.dump(pose_dict), type='string')
    return pose_attr


def restore_pose(node, pose_name='bindPose', pose_attr="millPose"):
    '''
    read attribute to set all keyable/visible attributes
    using Yaml to convert a string-attribute to a dictionary

    :param node: Any node...
    :type node: PyNode
    :param pose_name: "bindPose", "groomPose", "tPose", ...
    :type pose_name: String
    :param pose_attr: name of dictionary-attribute, standard is "millPose"
    :type pose_attr: String
    :rtype: PyAttribute
    '''

    # check for pose string-attribute
    if not pm.attributeQuery(pose_attr, node=node, exists=True):
        pm.warning("%s.%s doesn't exist!" % (node, pose_attr))
        return

    # read attribute and convert to dictionary
    pose_string = node.attr(pose_attr).get() or ""
    pose_dict = yaml.load(pose_string) or {}

    # apply pose-values
    attr_dict = pose_dict.get(pose_name)
    if not attr_dict:
        return

    valid = True
    for at in attr_dict:
        try:
            node.attr(at).set(attr_dict[at])
        except RuntimeError:
            valid = False
        except pm.MayaAttributeError:
            pm.warning("'%s' doesn't have an attribute called '%s'" % (node.name(), at))

    if not valid:
        pm.warning("Some attributes seem to be locked !")
    return pose_attr


def unlock_srt(node):
    '''
    unlock all "SRT"-attributes and give back a dictionary with the lock-states

    :param node: Any transform-node...
    :type node: PyNode
    :rtype: dictionary
    '''
    lock_dict = {}
    for at in 'srt':
        for axis in ["", "x", "y", "z"]:
            lock_dict[at, axis] = node.attr(at + axis).isLocked()
            node.attr(at + axis).set(l=False)
    return lock_dict


def restore_srt(node, lock_dict):
    '''
    lock all "SRT"-attributes referring to dictionary with the lock-states

    :param node: Any transform-node...
    :type node: PyNode

    :param lock_dict: dictionary of lockstates for each SRT-attribute
    :type lock_dict: dictionary
    '''
    for at in 'srt':
        for axis in ["", "x", "y", "z"]:
            node.attr(at + axis).set(l=lock_dict[at, axis])

