"""
.. module:: Name
   :synopsis: Collection of functions for generating and dealing with names on
   the basis of our naming convention

.. moduleauthor:: andreasg
"""

# library imports
from copy import deepcopy

# maya imports
import pymel.core as pm

# package imports
from millrigger.globals.name import TYPE_SUFFIX_DICT, SYNTAX_DICT, SYNTAX_STYLE_DICT, SYNTAX_TAGS_LIST
from millrigger.globals.rig import SIDE_SWITCH
from millrigger.globals import name as NAME
from millrigger.utils import info as minf


NONUNIQUE_SUFFIX = 'NONUNIQUE'


class RigNameError(Exception):
    """ Mill's Rig-Error """

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)


class Name(object):
    ''' Base-class for all Naming-Convention based name-issues

    :param name: The name that should be used/analysed
    :type name: String/PyNode
    :param side: Side of object.
    :type side: String
    :param part: The main-element of the name.
    :type part: String
    :param partindex: Alpha-Index for multiple occurences of an element
    :type partindex: String
    :param index: Numeric index
    :type index: String
    :param pad: padding for index
    :type pad: Integer
    :param tags: List of tags
    :type tags: List of Strings
    :param suffix: Suffix of object (or objectType/PyNode-object for type-based-suffix)
    :type suffix: String or PyNode
    :param add_to_tags: add single tag or List of tags to existing tags
    :type add_to_tags: List of Strings
    :param add_to_suffix: add to existing suffix
    :type add_to_suffix: List of Strings
    :param warnings: Hide the display of warnings
    :type warnings: Boolean
    :param unique: check scene for existing name-conflicts
    :type unique: Boolean
    :param autocorrect: fix elements to match namingconvention
    :type autocorrect: Boolean

    '''

    def __init__(self, name=None, **kwargs):

        # globals
        self._syntax_list = NAME.SYNTAX_LIST
        self._short_dict = NAME.SYNTAX_SHORTNAME_DICT
        self._splitname_RE = NAME.splitname_RE

        # init locals
        self._name = None
        self._shape_suffix = None
        self._namespace = None
        self.fix_tags = kwargs.get('fix_tags', False)

        self.init_dict = {item: None for item in self._syntax_list}

        self.padding = 2

        self._elem_dict = {}
        self._warnings = kwargs.get('warnings', False)
        self._warning_list = []

        self._unique = kwargs.get('unique', False)
        self._init_name(name, **kwargs)
        self._split_name(kwargs)  # split name (init self._name if it is None)
        self._name = self.create_name()
        self._template = self._create_syntax_template()

    def __str__(self):
        '''
        Returns string representation of the Name()
        '''
        return self.create_name()

    @property
    def name(self):
        shp_suffix = NAME.shape_RE.findall(self._name)
        if shp_suffix:
            return self._name.replace(shp_suffix[0], '')
        else:
            return self._name

    @property
    def shape_suffix(self):
        if self._shape_suffix is None:
            shp_suffix = NAME.shape_RE.findall(self._name)
            if shp_suffix:
                return shp_suffix[0]
        else:
            return self._shape_suffix

    @property
    def namespace(self):
        return self._namespace

    @namespace.setter
    def namespace(self, namespace):
        if namespace is None or namespace == ':':
            self._elem_dict['namespace'] = None
            self._namespace = None
            return

        if not namespace.endswith(":"):
            namespace += ":"
        self._elem_dict['namespace'] = namespace
        self._namespace = namespace

    @property
    def side(self):
        return self._elem_dict['side']

    @side.setter
    def side(self, value):
        '''Set side-property '''
        value = self._check_input(value, 'side')
        if value is None:
            self._warning_list.append('<side> not provided! Using "C" as stand-in')
            self._elem_dict['side'] = 'C'
        else:
            self._elem_dict['side'] = self._spellcheck('side', value)

    @property
    def part(self):
        # warning if <part> is capitalized
        part = self._elem_dict.get('part')
        if part[0].isupper():
            self._warning_list.append('<part> should begin with lower case >> "%s"' % part)
        if not part.isalpha():
            self._warning_list.append('Numbers are not valid in <part> : "%s"' % part)
        return part

    @part.setter
    def part(self, value):
        '''Set part-property '''
        if value in [None, "", []]:
            self._elem_dict['part'] = None
        else:
            # last letter is capital >> it is partindex
            if value[-1].isupper():
                part = value[:-1]
                partindex = value[-1]
            else:
                part = value
                partindex = None

            self._elem_dict['part'] = part
            if partindex is not None:
                self._elem_dict['partindex'] = partindex

    @property
    def partindex(self):
        return self._elem_dict.get('partindex')

    @partindex.setter
    def partindex(self, value):
        '''Set partindex-property '''
        self._elem_dict['partindex'] = value

    @property
    def index(self):
        return self._elem_dict.get('index')

    @index.setter
    def index(self, value):
        '''Set index-property '''
        if value is not None:
            self._elem_dict['index'] = index(str(value), self.padding)

    @property
    def tags(self):
        return self._tags_to_string(self._elem_dict.get('tags'))

    @tags.setter
    def tags(self, value):
        '''Set tags-property '''

        self._elem_dict['tags'] = self._tags_to_list(self._check_input(value, 'tags'))

    @property
    def suffix(self):
        suffix = self._elem_dict.get('suffix')
        if suffix in [None, "", []]:
            self._warning_list.append('<suffix> not provided! Using "TMP" as stand-in')
            self._elem_dict['suffix'] = 'TMP'
        return self._elem_dict['suffix']

    @suffix.setter
    def suffix(self, value):
        '''Set suffix-property '''
        self._elem_dict['suffix'] = self._spellcheck('suffix', self._check_input(value, 'suffix'))

    @property
    def basename(self):
        '''returns basename consisting of side, part and partindex '''
        basename = self.create_name(syntax_list=self._syntax_list[1:4])
        return basename

    # =========================================================================
    # Public Functions --------------------------------------------------------
    # =========================================================================

    def get(self, *args):
        ''' Returns elements of the name based on given keywords

        :param args: The name that should be used/analysed
        :type args: String
        :rType: single String or List of Strings
        '''

        # return list
        if len(args) > 1:
            result_list = []
            for elem in args:
                result_list.append(self._elem_dict.get(elem))
            return result_list
        # or return single element
        else:
            return self._elem_dict.get(args[0])

    def create_name(self, syntax_list=None, elem_dict=None, sort_tags=False, unique=None):
        ''' creates a name based on the given element-dictonary and syntax-list

        :param syntax_list: List of element to create the name of in the right order
        :type syntax_list: List of Strings
        :param elem_dict: The name that should be used/analysed
        :type elem_dict: Dictionary
        :param sort_tags: Reorder the taglist based on standard order
        :type sort_tags: Boolean
        :param unique: check scene for existing name-conflicts
        :type unique: Boolean
        :rType: String
        '''

        # create unique name option can be set globally or locally
        unique = unique or self._unique

        if syntax_list is None:
            syntax_list = self._syntax_list

        if elem_dict is None:
            temp_elem_dict = deepcopy(self._elem_dict)
        else:
            temp_elem_dict = deepcopy(elem_dict)

        if isinstance(temp_elem_dict.get('tags'), list):
            if sort_tags is True:
                temp_elem_dict['tags'][:] = self._reorder_tags(temp_elem_dict['tags'])
            temp_elem_dict['tags'] = '_'.join(temp_elem_dict['tags'])

        if temp_elem_dict.get('index'):
            temp_elem_dict['index'] = index(temp_elem_dict['index'], self.padding)

        template = self._create_syntax_template(syntax_list, temp_elem_dict)
        name = template.format(**temp_elem_dict)

        # this section checks the scene for duplcated of the name or duplicates
        # of the name including "NONUNIQUE" plus any number.
        # It then generates an additon to the beginning of the suffix with the
        # amount of found name-conflicts.
        if unique is True:
            # if node with same name is found, add "NONUNIQUE#" to tags
            if pm.objExists(name):
                # find number of existing duplicates
                nb = len(pm.ls(name))

                # temporarly store the existing suffix-part to be able to recover
                # it after generating a "NONUNIQUE#"-wildcard
                tmp = temp_elem_dict['suffix']

                # create wildcard
                temp_elem_dict['suffix'] = '_'.join([NONUNIQUE_SUFFIX + '*', temp_elem_dict['suffix']])
                wildcard_template = self._create_syntax_template(syntax_list, temp_elem_dict)
                wildcard_name = wildcard_template.format(**temp_elem_dict)
                # find nameconflicts and add them to the "NONUNIQUE"-index
                nb += len(pm.ls(wildcard_name))

                # restore original suffix-part
                temp_elem_dict['suffix'] = tmp

                # create new "NONUNIQUE"-suffix
                nu_suffix = NONUNIQUE_SUFFIX + str(nb)
                temp_elem_dict['suffix'] = '_'.join([nu_suffix, temp_elem_dict['suffix']])
                template = self._create_syntax_template(syntax_list, temp_elem_dict)
                name = template.format(**temp_elem_dict)
        return name

    def get_basename(self, namespace=True):
        ''' creates a name-segment based on side, part and partindex
        :param namespace: if namespace exists, add it to the name
        :type namespace: Boolean
        :rtype: String
        '''
        basename = self.create_name(syntax_list=self._syntax_list[1:4])
        if namespace is True:
            if self.namespace:
                basename = self.namespace + basename
        return basename

    def add_to_tags(self, value, elem_dict=None):
        ''' add new tags to existing tags-list

        :param value: 1 or more tag-name, or tagname with underscores
        :type value: String/List of Strings
        '''
        if elem_dict is None:
            elem_dict = self._elem_dict
        new_tags = self._tags_to_list(self._spellcheck('tags', value))
        if elem_dict.get('tags'):
            elem_dict['tags'].extend(new_tags)
        else:
            elem_dict['tags'] = new_tags

    def remove_from_tags(self, value, elem_dict=None):
        ''' removes tags to existing tags-list

        :param value: 1 or more tag-name, or tagname with underscores
        :type value: String/List of Strings
        '''
        if elem_dict is None:
            elem_dict = self._elem_dict
        remove_tags = self._tags_to_list(self._spellcheck('tags', value))

        if elem_dict.get('tags'):
            for tag in remove_tags:
                if tag in elem_dict['tags']:
                    elem_dict['tags'].remove(tag)

    def add_to_suffix(self, value, elem_dict=None):
        ''' add new Suffix-element to existing suffix

        :param value: Additional element to attach to suffix
        :type value: String
        '''
        if elem_dict is None:
            elem_dict = self._elem_dict
        new_suffix = self._spellcheck('suffix', value)
        if elem_dict.get('suffix'):
            elem_dict['suffix'] += '_' + new_suffix
        else:
            elem_dict['suffix'] = new_suffix

    def flip(self):
        ''' generates the mirror-name of the name if possible, else returns the
        original name

        :rType: String
        '''
        if self.side:
            side = SIDE_SWITCH[self.side[0]] + self.side[1:]
            return self.replace(side=side)
        else:
            pm.warning('Element has no side!')
            return self.name

    def replace(self, syntax_list=None, spellcheck=True, sort_tags=False,
                add_to_tags=None, add_to_suffix=None, unique=None, **kwargs):
        ''' replaces elements of the name by keyword-argument.

        | If *None* is given as value, the element of the name will be removed
        | Possible keywords are side, part, partindex, index, tags, suffix

        :param syntax_list: Ordered list of elements to create the name from
        :type syntax_list: List of Strings
        :param spellcheck: Check and fix the format of the given elements
        :type spellcheck: Boolean
        :param sort_tags: Reorder the taglist based on standard order
        :type sort_tags: Boolean
        :param add_to_tags: additional tags
        :type add_to_tags: String/List of Strings
        :param side: Side of object.
        :type side: String
        :param part: The main-element of the name.
        :type part: String
        :param partindex: Alpha-Index for multiple occurences of an element
        :type partindex: String
        :param index: Numeric index
        :type index: String
        :param pad: padding for index
        :type pad: Integer
        :param tags: List of tags
        :type tags: List of Strings
        :param suffix: Suffix of object (or PyNode-object for type-based-suffix)
        :type suffix: String or PyNode
        :param add_to_suffix: attachment to existing suffix
        :type add_to_suffix: String
        :param unique: check scene for existing name-conflicts >> add "duplicate"-tag
        :type unique: Boolean
        :rType: String

        .. note::

            | Names follow this naming-convention:
            | *<namespace>:<side>_<part><partindex>_<index>_<tags>_<suffix>*
            |
            | Example:
            | *L_armB_01_upper_fk_CTRL_OFS*
            |
            | Important: "END" is also recognised as an index and can't be used
              as suffix.
            | The format of the elements will also be checked and if neccessary
            fixed before returning the name

        .. warning::

            side, part and suffix are not optional and need to exist in any name

        '''
        # if no syntax_list is provided use the standard full list
        if syntax_list is None:
            syntax_list = self._syntax_list[:]

        # use a duplicate of the elem_dict as it might be manipulated
        temp_elem_dict = deepcopy(self._elem_dict)
        pad = kwargs.get("pad", self.padding)
        try:
            del kwargs['pad']
        except KeyError:
            pass

        for key in kwargs:
            # deal with shortnames of keywords
            if key in self._short_dict:
                temp_elem_dict[self._short_dict[key]] = kwargs.get(key)

            elif key in syntax_list:
                if key == 'tags':
                    # format tags to work properly with Name-class
                    temp_elem_dict['tags'] = self._tags_to_list(kwargs.get(key))

                elif key == 'suffix':
                    # deal with descriptive suffices like "matrixBlend"
                    temp_elem_dict['suffix'] = get_suffix_by_nodetype(kwargs.get(key))

                else:
                    temp_elem_dict[key] = kwargs.get(key)

        # "add_to_tags" adds on tag or a list of tags to the existing tags
        if add_to_tags:
            self.add_to_tags(add_to_tags, temp_elem_dict)

        # make sure there is no None value in tags-list
        if temp_elem_dict.get('tags') is not None:
            temp_elem_dict['tags'][:] = [tag for tag in temp_elem_dict['tags'] if tag is not None]

        # "add_to_suffix" attached extra element to the suffix
        if add_to_suffix:
            self.add_to_suffix(add_to_suffix, temp_elem_dict)

        if spellcheck:
            for item in temp_elem_dict.keys():
                # check and fix the format of the element
                temp_elem_dict[item] = self._spellcheck(item, temp_elem_dict[item])

        try:
            temp_elem_dict['index'] = index(temp_elem_dict.get("index"), padding=pad)
        except:
            pass

        return self.create_name(syntax_list, temp_elem_dict, sort_tags, unique)

    def wildcard(self, *args):
        ''' replaces elements of the name by wildcard-letters "?" and "*".

        | Possible elements are "side", "part", "partindex", "index", "tags", "suffix"

        :param args: Ordered list of elements to create the name from
        :type list: List of Strings
        :rType: String
        '''

        temp_elem_dict = deepcopy(self._elem_dict)

        # convert tags into string
        if temp_elem_dict.get('tags') and 'tags' not in args:
            temp_elem_dict['tags'] = self._tags_to_string(temp_elem_dict.get('tags'))

        for item in args:
#             if temp_elem_dict.get(item) is not None:
            if item == 'index':
                temp_elem_dict['index'] = '?' * self.padding
            elif item == 'partindex':
                temp_elem_dict['partindex'] = '?'
            else:
                temp_elem_dict[item] = '*'

        template = self._create_syntax_template(elem_dict=temp_elem_dict)
        return template.format(**temp_elem_dict)

    def pprint(self):
        ''' prints the splitted elements of the name '''
        for elem in self._syntax_list:
            print ('%s : %s' % (elem, self._elem_dict.get(elem)))

    # =========================================================================
    # Non-Public Functions ----------------------------------------------------
    # =========================================================================

    def _split_name(self, kwargs):
        '''
        | uses a regex to filter out the components of a typical name
        | <namespace>:<side>_<part><partindex>_<index>_<tags>_<Suffix>
        '''
        # check for overrides
        for key in kwargs:
            self._set_values(key, kwargs.get(key))

        # no name was given, just parts of the name
        if self._name is None:
            self._name = self.get_basename(namespace=False)

        self.name
        r = self._splitname_RE.search(self._name)
        result_list = list(r.groups())

        # special case "END" in index
        if result_list[5] == '_END' and not self._elem_dict.get('suffix'):
            raise RigNameError("END is not a valid Suffix!")

        for key, value in zip(self._syntax_list[1:], result_list):
            # if value is not None and the elem_dict is not yet set by overrides...
            if not self.init_dict.get(key):
                # just remove underscores
                if value is not None:
                    value = value.strip('_')
                self._set_values(key, value)

        # "add_to_tags" must be applied after elem_dict is populated
        add_to_tags = kwargs.get('add_to_tags')
        if add_to_tags:
            self.add_to_tags(add_to_tags, self._elem_dict)

        # "add_to_tags" must be applied after elem_dict is populated
        add_to_suffix = kwargs.get('add_to_suffix')
        if add_to_suffix:
            self.add_to_tags(add_to_suffix, self._elem_dict)

        # =====================================================================
        # WARNINGS ------------------------------------------------------------
        # =====================================================================

        # just to trigger the TMP-suffix:
        self.suffix

        if self._warnings is True:

            # warning but not breaking the flow

            # check if <part> is valid for proper error-message
            if self.part is None:
                raise RigNameError("couldn't find <part> '%s'" % self._name)

            # warning if <suffix> is not found... maybe because it was not capitals?
            if self.suffix is None:
                if self.tags is not None:
                    pm.warning("<tags> don't match the naming-convention!")
                else:
                    pm.warning('<suffix> not found! "%s"' % self._name)

            # print collected warnings
            for item in self._warning_list:
                pm.warning(item)

    def _create_syntax_template(self, syntax_list=None, elem_dict=None):
        ''' creates a template string based on the given element-dictonary
        and syntax-list'''
        if elem_dict is None:
            elem_dict = self._elem_dict
        if syntax_list is None:
            syntax_list = self._syntax_list
        return ''.join([SYNTAX_DICT[elem] for elem in syntax_list
                        if elem_dict.get(elem) is not None])

    def _reorder_tags(self, unsorted_tags):
        ''' Reorder the tags based on keywords '''
        sorted_tags = []

        for check_list in SYNTAX_TAGS_LIST:
            for item in unsorted_tags:
                if item in check_list:
                    sorted_tags.append(item)
                    unsorted_tags.remove(item)

        sorted_tags = sorted_tags + unsorted_tags
        return sorted_tags

    def _spellcheck(self, elem=None, value=None):
        ''' Double-check and fix the spelling '''
        if elem is not None and value is not None:
            if elem == 'tags':
                value = self._spellcheck_tags(value)
            elif elem == 'suffix':
                value = get_suffix_by_nodetype(value).upper()
            else:
                value = namestyle(value,
                                  style=SYNTAX_STYLE_DICT[elem],
                                  padding=self.padding)
        return value

    def _spellcheck_tags(self, value):
        ''' this is a bit more tricky as it very likely is a list '''
        if isinstance(value, basestring):
            if self.fix_tags is True:
                return value.lower()
            else:
                return value
        if isinstance(value, list):
            # filter out any None-value
            value = [item for item in value if item is not None]

            # if result is an empty list return None
            if value == []:
                return None

            for i, tag in enumerate(value):
                value[i] = tag
            if self.fix_tags is True:
                for tag in value:
                    value[i] = value[i].lower()
            return value

    def _tags_to_list(self, value):
        ''' filter tags input and return list '''
        # value is single string
        if isinstance(value, basestring):
            # create list if undescores are found in string
            value = [item for item in value.split('_') if item != '']
            return value
        # value is list >> return list without None-values
        elif isinstance(value, list):
            value = [item for item in value if item is not None]
            return value

    def _tags_to_string(self, value):
        ''' return a single string with underscores'''
        # value is single string
        if self._elem_dict.get('tags'):
            value = '_'.join(self._elem_dict['tags'])
        return value

    def _set_values(self, key, value):
        # read out the keyword arguments and assign them through the property-filter
        if key in SYNTAX_STYLE_DICT:
            value = self._spellcheck(elem=key, value=value)
        if key == 'namespace':
            self.namespace = value
        elif key == 'side':
            self.side = value
        elif key == 'part':
            self.part = value
        elif key == 'partindex':
            self.partindex = value
        elif key == 'index':
            self.index = value
        elif key == 'tags':
            self.tags = value
        elif key == 'suffix':
            self.suffix = value

        # register that value is set
        self.init_dict[key] = True

    def _init_name(self, name, **kwargs):
        '''
        initialize the name by splitting namespace and finding the shortname
        '''
        if name is None:
            return

        # pymel_check
        name = _pymel_check(name)

        # look for namespace
        namespace, name = get_namespace(name, empty=None)

        self._namespace = kwargs.get('namespace', namespace)
        self._elem_dict['namespace'] = self._namespace

        # get shortname
        name = get_shortname(name)

        # split shapesuffix from suffix
        name, self._shape_suffix = get_shapesuffix(name)

        # split suffix for NONUNIQUE
        self._name = "_".join([s for s in name.split("_") if not s.startswith(NONUNIQUE_SUFFIX)])

    def _check_input(self, value, msg):
        if value in ["", []]:
            pm.warning('<%s> is empty! Using "None" instead.' % msg)
            return None
        else:
            return value


# =============================================================================
# Non-Public Functions --------------------------------------------------------
# =============================================================================

def _pymel_check(node):
    # check if a name was given and if it is a PyNode

    if isinstance(node, pm.PyNode):
        name = node.name()
    else:
        name = node
    return name


# =============================================================================
# Public Functions ------------------------------------------------------------
# =============================================================================

def get_namespace(name, empty=''):
    ''' returns namespace and name as list '''
    namespace = name.rsplit(':', 1)
    if len(namespace) > 1:
        if namespace[0] == '':
            ns = empty
        else:
            ns = namespace[0] + ':'
        name = namespace[1]
    else:
        ns = empty
    return ns, name


def get_shortname(name):
    ''' returns shortname '''
    shortname = name.rsplit('|', 1)
    if len(shortname) > 1:  # split was successfull
        name = shortname[1]
    return name


def get_shapesuffix(name):
    ''' returns name and shape-suffix as list '''
    # split shapesuffix from suffix
    found = NAME.shape_RE.findall(name)
    if found:
        shape_suffix = found[0]
        name = name.replace(shape_suffix, '')
    else:
        shape_suffix = ''
    return name, shape_suffix


def get_namespacelist():
    ''' collect and sort all useful namespaces'''
    pm.namespace(set=":")
    namespaceList = ['{0}:'.format(ns) for ns in pm.namespaceInfo(lon=True)
                     if ns not in ('UI', 'shared')]
    namespaceList.append(':')
    namespaceList.sort()
    return namespaceList


def remove_namespace(name, dest=':'):
    ''' moves content of name to destination and removes name'''
    if (name == ':'):
        print (" -- can't remove world-namespace --")
    else:
        pm.namespace(set=dest)
        pm.namespace(f=True, mv=(name, dest))
        pm.namespace(rm=name)


def get_suffixlist(obj_list):
    ''' little helperfunction to list all found suffixes in a selection '''
    suffix_set = set()
    for obj in obj_list:
        try:
            sfx = obj.rsplit('_', 1)[1]
            suffix_set.add(sfx)
        except:
            pass
    for obj in suffix_set:
        print obj


def create_abc_dict(item_list):
    ''' Creates a dictionary where elements are grouped alphabetical
    by their first letter

    :param item_list: List of names
    :type item_list: List of Strings
    :rType: dictionary
    '''
    abc_dict = {}
    abc_list = sorted(list(set([item[0].upper() for item in item_list])))

    for abc in abc_list:
        collect_list = sorted([item for item in item_list
                               if item[0].upper() == abc])
        abc_dict.setdefault(abc, collect_list)

    return abc_dict


def camelcase(name, cap=False):
    ''' camelCase a string of elements connected by underscore

    :param name: Name
    :type name: String
    :param cap: capitalize result if True
    :type cap: Boolean
    :rType: String

    .. note::

        This_is_an_example >> thisIsAnExample
    '''

    if '_' in name:
        split_list = name.lower().split('_')
        if (len(split_list) > 1):
            for i, item in enumerate(split_list):
                if i > 0:
                    split_list[i] = item.capitalize()
                name = ''.join(split_list)

    if name.isupper():
        name = name.lower()

    if cap:
        return (name[0].upper() + name[1:])
    else:
        return (name[0].lower() + name[1:])


def index(name, padding=2):
    ''' format name according index-guidelines (accepts "END" as index)

    :param name: Name
    :type name: String
    :param padding: amount of leading zeros
    :type padding: Integer
    :rType: String
    '''

    if name == 'END':
        return name
    elif name == '*':
        return name
    else:
        return pad(unpad(name), padding)


def namestyle(name, style=None, padding=3):
    ''' format name according to style

    :param name: Name
    :type name: String
    :param style: Styles available: *UPPER, lower, camelCase, Capitalize*
    :type style: String
    :rType: String
    '''
    if style == 'upper':
        return name.upper()
    elif style == 'lower':
        return name.lower()
    elif style == 'camelcase':
        return camelcase(name)
    elif style == 'capitalize':
        return camelcase(name, cap=True)
    elif style == 'index':
        return index(name, padding)
    elif style == 'suffix':
        suffix = name.upper()
        if suffix.endswith('SHAPE'):
            suffix = suffix[:-5] + 'Shape'
        return suffix
    else:
        return name


def unpad(name):
    if name is not None:
        regex = NAME.unpad_RE
        match_list = regex.findall(str(name))
        return ''.join(match_list)


def pad(name, padding=2):
    return name.zfill(padding)


def get_typesuffix(node):
    ''' Creates a suffix based on the object-type by using predefined names '''
    obj_type = pm.objectType(node)
    if (obj_type == 'nonLinear'):
        obj_type = minf.get_nonlinear_deformertype(node)
    return TYPE_SUFFIX_DICT[obj_type]


def get_index(name):
    ''' extracts the integer index of a given component-string '''
    index = name.split('[', 1)[-1]
    index = index.rsplit(']', 1)[0]
    return int(index)


def remove_enddigits(name):
    ''' removes any digit found at the end of a string '''
    regex = NAME.enddigit_RE
    try:
        name = name.rsplit('|', 1)[1]
    except IndexError:
        pass

    new_name = regex.findall(name)[0]
    return new_name


def fix_shapenames(obj):
    ''' Fixes the name of any shape-node based on it's transform-name '''
    node = None
    shp_list = []
    # sort out transforms and shapes
    if obj.type() in ('transform', 'joint'):
        node = obj
        shp_list = obj.getShapes()
    else:
        shp_list.append(obj)
        node = obj.getParent()

    # filter out instances
    shp_list[:] = [shp for shp in shp_list if not shp.isInstanced()]

    name_cls = Name(node)
    if len(shp_list) == 1:  # if only one shape exists
        shp_name = name_cls.create_name() + 'Shape'
        print ('{0} >> {1}'.format(shp_list[0], shp_name))
        shp_list[0].rename(shp_name)

    else:
        for shp in shp_list:  # if several shapenodes exist, rename by type
            if (name_cls.suffix == 'CTRL' and shp.type() == 'nurbsCurve'):
                shp_name = name_cls.replace(suffix='CTRLShape')
            else:
                shp_name = name_cls.replace(suffix=get_typesuffix(shp) + 'Shape')
            shp.rename(shp_name)


def get_component(name):
    ''' splits name into name and component-element '''
    if '.' in name:
        i = name.index('.')
        return name[:i], name[i:]
    else:
        return name, ''


def remove_last_element(name):
    ''' removes last element of a camelCase-Name '''
    r = NAME.camelcase_RE.search(name)
    last_element = list(r.groups())[-1]
    return name.replace(last_element, '')


def split_last_element(name):
    ''' splits last element of a camelCase-Name and returns the splitted parts'''
    r = NAME.camelcase_RE.search(name)
    last_element = list(r.groups())[-1]
    return name.replace(last_element, ''), last_element


def get_suffix_by_nodetype(node):
    ''' get the suffix by nodetype '''
    if isinstance(node, pm.PyNode):
        if node is not None:
            return get_typesuffix(node)
        else:
            raise RigNameError('Type-suffix not defined')
    else:
        suffix = TYPE_SUFFIX_DICT.get(node, node)
        return suffix


def get_mirrorname(node):
    ''' replace the side if possible '''
    if isinstance(node, pm.PyNode):
        name = node.name()
    else:
        name = node

    ns, name = get_namespace(name)
    short_name = get_shortname(name)
    return '%s%s%s' % (ns, SIDE_SWITCH[short_name[0]], short_name[1:])


def mirror_partindex_generator(amount=3):
    ''' create a tring like "ABCDDCBA" for even or "DCBABCD" for odd numbers '''
    num = amount // 2
    offset = amount % 2
    indices = ''.join([chr(65 + i) for i in range(num)])
    result = "%s%s%s" % (indices, offset * chr(65 + num), indices[::-1])
    return result


def mirror_side_generator(amount=3):
    ''' create a string like "LLLRRR" for even or "LLLCRRR" for odd numbers '''
    num = amount // 2
    offset = amount % 2
    result = "%s%s%s" % (num * 'L', offset * 'C', num * 'R')
    return result


# =============================================================================
# Wrapper Functions using the Name-Class  -------------------------------------
# =============================================================================


def create_name(**kwargs):
    ''' creates a name based on the given element-dictonary and syntax-list.
        *(Uses the Name-Class)*
    '''
    return Name(**kwargs).create_name()


def replace(name, **kwargs):
    ''' replaces name-elements by keyword-argument.
        *(Uses the Name-Class)*
    '''
    return Name(name).replace(**kwargs)


def create_chain_names(count, last=True, startindex=1, force_index=False, **kwargs):
    """creates a chain of names """

    add_to_tags = kwargs.get("add_to_tags")
    if add_to_tags:
        del kwargs["add_to_tags"]
    namer = Name(**kwargs)
    out = []

    # if a list of tags is given, use them
    if isinstance(count, list):
        # make sure the new tags are set before the existing ones
        existing_tags = namer.tags
        if existing_tags:
            existing_tags = "_" + existing_tags
        else:
            existing_tags = ""
        for tag in count:
            tags = "%s%s" % (tag, existing_tags)
            out.append(namer.replace(tags=tags, add_to_tags=add_to_tags))

    # otherwise use the length
    elif isinstance(count, int):
        if count == 1:
            if force_index is True:
                out.append(namer.replace(index=1, add_to_tags=add_to_tags))
            else:
                out.append(namer.replace(add_to_tags=add_to_tags))
        else:
            index_list = range(startindex, count + startindex)

            # add all the numbers
            for index in index_list:
                out.append(namer.replace(index=index, add_to_tags=add_to_tags))
    else:
        raise ValueError('value must be of type list or int!')

    # replace the last one if needed
    if last:
        index = 'END'
#         if suffix == 'CTRL':
#             add_to_suffix = 'SRT'
#         else:
#             add_to_suffix = None

        out[-1] = namer.replace(index=index,
                                add_to_tags=add_to_tags)
    return out


def _make_list(item, length):
    if isinstance(item, list):
        return item
    return [item] * length
