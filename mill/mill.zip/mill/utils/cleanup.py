import rig as mrig
import attributes as mattr
import pymel.core as pm
import maya.cmds as cmds


def general_cleanup(top_node, rig_sets=()):
    """
    Cleanup stuff that has to be done for every res of a millrig
    :return:
    """
    out_nodes = []

    if mrig is None:
        pm.warning("Could not find mill rig cleaning scripts!")
        return

    print "Merging modules..."
    mrig.merge_modules(pm.PyNode(top_node))

    print "Create sets..."
    for _set in mrig.create_sets(pm.PyNode(top_node)):
        if _set not in rig_sets:
            out_nodes.append(_set)

    print "Remove MillRig-Nodes..."
    mrig.remove_millrig_nodes(pm.PyNode(top_node))

    if mrig is not None:
        print "Apply Publish Pose...",
        for ctrl in pm.ls('*_CTRL'):
            mattr.restore_pose(ctrl, pose_name="publishPose", pose_attr='millPose')
    return out_nodes


def lowres_cleanup(top_node, rig_sets):
    """
    Cleanup stuff that has to be done to the low res version of the rig.
    """
    # delete the render level geo
    nodes = cmds.ls("*|geo_GRP|render")
    if nodes:
        cmds.delete(nodes)
    cmds.setAttr("C_global_CTRL.LOD", 1)
    return []

# arguments needed for the publish tool
cleanup_options = ["base", "lowres"]
cleanup_funcs = [None, lowres_cleanup]
custom_stream = True
info_text = "Mill Rig Detected"