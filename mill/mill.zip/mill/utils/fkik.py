'''
Created on 27 Apr 2015

@author: andreasg, petera
'''

# python lib imports
import numpy as np

# maya imports
import pymel.core as pm
import maya.api.OpenMaya as om

# package imports
from millrigger.utils import name as mname
from millrigger.utils import matrix as mmtrx
from millrigger.utils import vector as mvec
from millrigger.utils.nodes import transforms as mntrs
from millrigger.objects import rigobject as rigobj
from millrigger.utils.nodes import utility as mutil
from millrigger.utils.nodes import create as mcreate
from millrigger.utils.nodes import curveinterp as mcint
from millrigger.utils.nodes import pairblend as mpb
from millrigger.utils import attributes as mattr
from millrigger.utils.data import RigData
import millrigger.objects.srtgroup as msrt
import millrigger.objects.controls.control as mctrl

pm.loadPlugin("matrixNodes", qt=True)


# ========================================================================
# Public -----------------------------------------------------------------
# ========================================================================


def calculate_pole_matrix(root_matrix, mid_matrix,
                          end_matrix, distance, placement="mid",
                          aim='+x', up='+y', fit_to_world=True):
    """
    Calculates the position for a pole control from 3 matrices

    Returns the matrix for the pole and the matrix for the pole twist matrix
    (so we can make the aim/side offsets)

    .. note::
        Only the positions of the 3 matrices are used. Orientation is ignored
    '''

    :param root_matrix: Root world matrix
    :type root_matrix: Matrix

    :param mid_matrix: Mid world matrix
    :type mid_matrix: Matrix

    :param end_matrix: End world matrix
    :type end_matrix: Matrix

    :param distance: Distance from the mid matrix
    :type distance: Float

    :param placement: whether the pole is to be calculated for the "mid" or
                    "top" position
    :type placement: String: "mid" or "top"

    :param aim: Aim Axis
    :type aim: String = +x/+y/+z/-x/-y/-z

    :param up: Up Axis
    :type up: String = +x/+y/+z/-x/-y/-z

    :param fit_to_world: If True, tries to reorient the control to match the world matrix
    :type fit_to_world: Boolean

    :rType: TransformationMatrix
    """
    # up = NEG_SWITCH[UP_SWITCH[up]]
    # create an aim from the mid matrix to the first, using the
    # last as an upvector

    root_pos = mmtrx.get_posvector(root_matrix)
    mid_pos = mmtrx.get_posvector(mid_matrix)
    end_pos = mmtrx.get_posvector(end_matrix)

    # use the position of the mid matrix, but replace with the aim orientation
    if placement.lower() == "top":
        pole_matrix = om.MTransformationMatrix(end_matrix)
    else:
        pole_matrix = om.MTransformationMatrix(mid_matrix)

    aimed_matrix = mmtrx.get_aim_matrix(base_vec=root_pos,
                                        aim_pos=end_pos,
                                        up_pos=mid_pos,
                                        aim_axis=aim,
                                        up_axis=up
                                        )
    aimed_matrix = mmtrx.to_tmatrix(aimed_matrix)
    pole_matrix.setRotation(aimed_matrix.rotation())

    # add on the distance for the final matrix
    aim_vec = mvec.get_axis_vector(up) * distance

    distance_vector = aim_vec.rotateBy(pole_matrix.rotation())
    pole_matrix.translateBy(distance_vector, om.MSpace.kTransform)

    pole_matrix = mmtrx.to_mmatrix(pole_matrix)

    if fit_to_world:
        return mmtrx.fit_matrix_to_world(pole_matrix)
    else:
        return pole_matrix


def create_ik_handle(name, start_jnt, end_jnt, eff_ctrl=None,
                     ikh_parent=None, twist=None, twist_offset=0.0,
                     snap=False):
    """ Creates the IK Handle

    :param name: The base name for all the parts
    :type name: string

    :param eff_ctrl: The control for the ik handle to follow
    :type eff_ctrl: millrigger.utils.Control/worldMatrix-Attribute

    :param start_jnt: start of the joint chain
    :type end_jnt: Joint

    :param ikh_parent: end of the joint chain
    :type ikh_parent: PyNode

    :param twist: Either the value or attribute to set or drive the twist
    :type twist: float or Attribute

    :param twist_offset: Permanent offset to the twist
    :type twist_offset: float

    :param snap: snap srt to ikh_parent
    :type snap: Boolean

    :param as_child: parent under ikh_parent instead of just linking it
    :type as_child: Boolean

    :rType: RigData
    """
    namer = mname.Name(name)

    # make ikHandle (creates data.ikh and data.eff)
    ikh, eff = mcreate.ik_handle(start_jnt, end_jnt)

    if ikh_parent is not None:
        ikh.setParent(ikh_parent)
        if snap:
            ikh.t.set(0, 0, 0)
            ikh.r.set(0, 0, 0)
            ikh.s.set(1, 1, 1)
        mntrs.offset(ikh)
    else:
        # connect it with the ik_matrix
        world_pos_attr = get_world_pos_attr(eff_ctrl, namer)
        world_pos_attr >> ikh.translate

    if twist or twist_offset:
        # make a plus node for the twist, add an offset if needed and link
        twist_add = pm.createNode("addDoubleLinear")

        # set the twist attr
        if twist:
            twist >> twist_add.input1
        if twist_offset:
            twist_add.input2.set(twist_offset)

        twist_add.output >> ikh.twist
    return ikh


def create_follow(node, follow_obj, namer=None):
    """
    :param node: transform-node that will be rotated by the construct
    :type node: PyNode-Transform

    :param follow_obj: node used as driver for the follow
    :type follow_obj: Pynode-Attribute

    :param namer: Name-Class
    :type namer: Name-Class or None

    :rType: PyAttribute
    """

    namer = namer or mname.Name(node)

    # ROTATION
    # create base and follow-vector

    follow_loc = mcreate.node('locator',
                              name=namer.replace(tags='follow', suffix='LOC'),
                              parent=node.getParent())
    follow_loc.transform.t.set(0, 0, 0)
    follow_loc.shape.localPosition.set(1, 0, 0)
    follow_loc.shape.v.set(False)

    # convert follow_obj to local_space
    mmlt = pm.createNode('multMatrix', name=namer.replace(tags='follow', suffix='multMatrix'))
    follow_obj.worldMatrix >> mmlt.matrixIn[0]
    follow_loc.transform.parentInverseMatrix >> mmlt.matrixIn[1]

    # extract rotation with decompose node
    mdcp = pm.createNode('decomposeMatrix', name=namer.replace(tags='follow', suffix='decomposeMatrix'))
    mmlt.matrixSum >> mdcp.inputMatrix
    mdcp.outputRotate >> follow_loc.transform.r

    # create local up-vector
    mpmm = pm.createNode('pointMatrixMult',
                         name=namer.replace(tags='follow',
                                            suffix='pointMatrixMult'))
    node.parentInverseMatrix >> mpmm.inMatrix
    follow_loc.shape.worldPosition >> mpmm.inPoint

    # get angle between base and follow
    angl = pm.createNode('angleBetween',
                         name=namer.replace(tags='follow',
                                            suffix='angleBetween'))
    angl.v1x.set(mpmm.ox.get())
    angl.v1y.set(0)
    angl.v1z.set(mpmm.oz.get())
    mpmm.ox >> angl.v2x
    angl.v2y.set(0)  # just care about the y-rotation
    mpmm.oz >> angl.v2z

    # TRANSLATION
    # get worldposition of follow_obj
    mpmm_world = pm.createNode('pointMatrixMult',
                               name=namer.replace(tags=['follow', 'world'],
                                                  suffix='pointMatrixMult'))

    follow_obj.worldMatrix >> mpmm_world.inMatrix
    mpmm_world.inPoint.set(0, 0, 0)

    # get localposition of the follow_obj
    mpmm_local = pm.createNode('pointMatrixMult',
                               name=namer.replace(add_to_tags=['offset'],
                                                  suffix='pointMatrixMult'))

    node.parentInverseMatrix >> mpmm_local.inMatrix
    mpmm_world.o >> mpmm_local.inPoint

    sub_local = pm.createNode('plusMinusAverage',
                              name=namer.replace(tags=['follow', 'local'],
                                                 suffix='SUB'))
    sub_local.operation.set(2)
    mpmm_local.o >> sub_local.i3[0]
    sub_local.i3[1].set(mpmm_local.o.get())

    blnd = pm.createNode('pairBlend',
                         name=namer.replace(tags='follow',
                                            suffix='pairBlend'))

    # in "side"-mode the transalation has to stay 0,0,0
    cond = pm.createNode('condition',
                         name=namer.replace(tags='follow',
                                            suffix='condition'))
    cond.secondTerm.set(0.5)
    cond.operation.set(4)  # less than
    cond.colorIfFalse.set(0, 0, 0)
    sub_local.o3 >> cond.colorIfTrue

    angl.euler >> blnd.inRotate2
    cond.oc >> blnd.inTranslate2
    blnd.outTranslate >> node.t
    blnd.outRotate >> node.r

    # return the blend-attribute
    return blnd.weight, cond.firstTerm


def create_footroll(ctrl,
                    inner_matrix,
                    outer_matrix,
                    back_matrix,
                    front_matrix,
                    ball_matrix,
                    ankle_matrix=None,
                    create_ankle_ctrl=False,
                    ankle_size=1.0,
                    create_floor_contact=False,
                    attr_obj=None):
    """

    :param ctrl: The ik-control the footroll should be added to
    :type ctrl: PyNode

    :param inner_matrix: Matrix for inner bank
    :type inner_matrix: Matrix

    :param outer_matrix: Matrix for outer bank
    :type outer_matrix: Matrix

    :param back_matrix: Matrix for heel-roll/swivel
    :type back_matrix: Matrix

    :param front_matrix: Matrix for tip-roll/swivel
    :type front_matrix: Matrix

    :param ball_matrix: Matrix for toes-roll/swivel
    :type ball_matrix: Matrix

    :rtype: RigData

    """
    # to make things neater...
    inner = inner_matrix
    outer = outer_matrix
    heel = back_matrix
    toes = front_matrix
    ball = ball_matrix

    data = RigData()
    namer = mname.Name(ctrl.name())

    # swivel-setup
    swivel_srt = msrt.SRTGroup(name=namer.replace(add_to_tags='swivel', suffix='SRT'),
                               parent=ctrl,
                               matrix=heel)
    heel_attr = mattr.add_vector_attr(swivel_srt.obj, 'heel')
    ball_attr = mattr.add_vector_attr(swivel_srt.obj, 'ball')
    toes_attr = mattr.add_vector_attr(swivel_srt.obj, 'toes')

    tmp = pm.createNode('transform', parent=swivel_srt.top)
    mmtrx.set_matrix(tmp, ball, ws=True)
    ball_attr.set(tmp.t.get())
    mmtrx.set_matrix(tmp, toes, ws=True)
    toes_attr.set(tmp.t.get())
    pm.delete(tmp)

    swivel_chce = pm.createNode('choice',
                                name=namer.replace(add_to_tags='swivel', suffix='choice')
                                )
    heel_attr >> swivel_chce.input[0]
    ball_attr >> swivel_chce.input[1]
    toes_attr >> swivel_chce.input[2]
    swivel_chce.output >> swivel_srt.obj.rotatePivot

    # create hierarchy
    data.inner = msrt.SRTGroup(name=namer.replace(add_to_tags=['bank', 'inner'], suffix='SRT'),
                               parent=swivel_srt.top,
                               create_zero=False,
                               matrix=inner)

    data.outer = msrt.SRTGroup(name=namer.replace(add_to_tags=['bank', 'outer'], suffix='SRT'),
                               parent=data.inner.top,
                               create_zero=False,
                               matrix=outer)

    data.heel = msrt.SRTGroup(name=namer.replace(add_to_tags=['footroll', 'heel'], suffix='SRT'),
                              parent=data.outer.top,
                              create_zero=False,
                              matrix=heel)

    data.toes = msrt.SRTGroup(name=namer.replace(add_to_tags=['footroll', 'toes'], suffix='SRT'),
                              parent=data.heel.top,
                              create_zero=False,
                              matrix=toes)

    data.ball = msrt.SRTGroup(name=namer.replace(add_to_tags=['footroll', 'ball'], suffix='SRT'),
                              parent=data.toes.top,
                              create_zero=False,
                              matrix=ball)

    if not ankle_matrix:
        ankle_matrix = ctrl

    if create_ankle_ctrl:
        data.ankle = mctrl.Control(name=namer.replace(add_to_tags='footroll', suffix='CTRL'),
                                   shape_type="sphere",
                                   parent=data.ball.top,
                                   create_zero=True,
                                   create_ofs=False,
                                   create_cnst=True,
                                   matrix=ankle_matrix,
                                   lock_pos='',
                                   lock_rot='xyz',
                                   lock_scl='yxz',
                                   size=ankle_size
                                   )
        data.ankle.drive_visibility(attr_obj, attr_name="ankleVis", default=0.0)
    else:
        data.ankle = msrt.SRTGroup(name=namer.replace(add_to_tags=['footroll', 'ankle'], suffix='SRT'),
                                   parent=data.ball.top,
                                   create_zero=False,
                                   matrix=ankle_matrix,
                                   create_cnst=True)
    data.cnst = data.ankle.cnst

    # bank
    bank_cond = pm.createNode('condition', name=namer.replace(add_to_tags='bank',
                                                              suffix='condition'))
    if namer.side.startswith('R'):
        bank_cond.operation.set(4)  # less than
    else:
        bank_cond.operation.set(2)  # greater than
    bank_cond.colorIfTrue.set(0, 0, 0)  # to be sure
    bank_cond.colorIfFalse.set(0, 0, 0)  # to be sure
    bank_cond.outColorR >> data.inner.obj.rz
    bank_cond.outColorG >> data.outer.obj.rz

    # footroll attributes
    if not attr_obj:
        attr_obj = ctrl
    attr_data = mattr.add_footroll_attr(attr_obj, ankle=data.ankle.obj)
    attr_data.swivel >> swivel_srt.obj.ry
    attr_data.swivelPivot >> swivel_chce.selector
    attr_data.bank >> bank_cond.firstTerm
    attr_data.bank >> bank_cond.colorIfTrueR
    attr_data.bank >> bank_cond.colorIfFalseG

    # footroll
    footroll_rmc = mutil.footroll_rmc(footroll_in=attr_data.roll,
                                      bend_in=attr_data.bend,
                                      straight_in=attr_data.straight,
                                      toes_out=data.toes.obj.rx,
                                      ball_out=data.ball.obj.rx,
                                      heel_out=data.heel.obj.rx,
                                      name=namer.replace(add_to_tags='footroll',
                                                         suffix='remapColor')
                                      )
    return data


def create_footroll_ctrls(ctrl,
                          inner_matrix,
                          outer_matrix,
                          back_matrix,
                          front_matrix,
                          ball_matrix,
                          ankle_matrix=None,
                          create_ankle_ctrl=False,
                          ankle_size=1.0,
                          create_floor_contact=False,
                          attr_obj=None):
    """

    :param ctrl: The ik-control the footroll should be added to
    :type ctrl: PyNode

    :param inner_matrix: Matrix for inner bank
    :type inner_matrix: Matrix

    :param outer_matrix: Matrix for outer bank
    :type outer_matrix: Matrix

    :param back_matrix: Matrix for heel-roll/swivel
    :type back_matrix: Matrix

    :param front_matrix: Matrix for tip-roll/swivel
    :type front_matrix: Matrix

    :param ball_matrix: Matrix for toes-roll/swivel
    :type ball_matrix: Matrix

    :rtype: RigData

    """
    # to make things neater...
    inner = inner_matrix
    outer = outer_matrix
    heel = back_matrix
    toes = front_matrix
    ball = ball_matrix

    data = RigData()
    namer = mname.Name(ctrl.name())

    # swivel-setup
    swivel_srt = msrt.SRTGroup(name=namer.replace(add_to_tags='swivel', suffix='SRT'),
                               parent=ctrl,
                               matrix=heel)
    heel_attr = mattr.add_vector_attr(swivel_srt.obj, 'heel')
    ball_attr = mattr.add_vector_attr(swivel_srt.obj, 'ball')
    toes_attr = mattr.add_vector_attr(swivel_srt.obj, 'toes')

    tmp = pm.createNode('transform', parent=swivel_srt.top)
    mmtrx.set_matrix(tmp, ball, ws=True)
    ball_attr.set(tmp.t.get())
    mmtrx.set_matrix(tmp, toes, ws=True)
    toes_attr.set(tmp.t.get())
    pm.delete(tmp)

    swivel_chce = pm.createNode('choice',
                                name=namer.replace(add_to_tags='swivel', suffix='choice')
                                )
    heel_attr >> swivel_chce.input[0]
    ball_attr >> swivel_chce.input[1]
    toes_attr >> swivel_chce.input[2]
    swivel_chce.output >> swivel_srt.obj.rotatePivot

    # get footsize:
    foot_width = mmtrx.matrix_distance(inner, outer)
    foot_length = mmtrx.matrix_distance(heel, toes)

    # create hierarchy
    data.inner = msrt.SRTGroup(name=namer.replace(add_to_tags=['bank', 'inner'], suffix='SRT'),
                               parent=swivel_srt.top,
                               create_zero=False,
                               matrix=inner)

    data.outer = msrt.SRTGroup(name=namer.replace(add_to_tags=['bank', 'outer'], suffix='SRT'),
                               parent=data.inner.top,
                               create_zero=False,
                               matrix=outer)

    data.heel = mctrl.Control(name=namer.replace(add_to_tags=['heel']),
                              parent=data.outer.top,
                              create_zero=True,
                              create_ofs=False,
                              shape_type='circle',
                              shape_aim='+x',
                              shape_up='-z',
                              lock_pos='xyz',
                              lock_rot='yz',
                              lock_scl='xyz',
                              size=foot_length / 6.0,
                              matrix=heel)

    data.toes = mctrl.Control(name=namer.replace(add_to_tags=['toes']),
                              parent=data.heel.top,
                              create_zero=True,
                              create_ofs=False,
                              shape_type='circle',
                              shape_aim='+x',
                              shape_up='+z',
                              lock_pos='xyz',
                              lock_rot='yz',
                              lock_scl='xyz',
                              size=foot_length / 6.0,
                              matrix=toes)

    data.ball = mctrl.Control(name=namer.replace(add_to_tags=['ball']),
                              parent=data.toes.top,
                              create_zero=True,
                              create_ofs=False,
                              shape_type='circle',
                              shape_aim='+z',
                              shape_up='+y',
                              lock_pos='xyz',
                              lock_rot='yz',
                              lock_scl='xyz',
                              size=foot_width,
                              matrix=ball)

    # bank
    bank_cond = pm.createNode('condition', name=namer.replace(add_to_tags='bank',
                                                              suffix='condition'))
    if namer.side.startswith('R'):
        bank_cond.operation.set(4)  # less than
    else:
        bank_cond.operation.set(2)  # greater than
    bank_cond.colorIfTrue.set(0, 0, 0)  # to be sure
    bank_cond.colorIfFalse.set(0, 0, 0)  # to be sure

    if not ankle_matrix:
        ankle_matrix = ctrl

    if create_ankle_ctrl:
        data.ankle = mctrl.Control(name=namer.replace(add_to_tags='ankle', suffix='CTRL'),
                                   shape_type="sphere",
                                   parent=data.ball.top,
                                   create_zero=True,
                                   create_ofs=False,
                                   create_cnst=True,
                                   matrix=ankle_matrix,
                                   lock_pos='',
                                   lock_rot='xyz',
                                   lock_scl='yxz',
                                   size=ankle_size)
    else:
        data.ankle = msrt.SRTGroup(name=namer.replace(add_to_tags=['footroll', 'ankle'], suffix='SRT'),
                                   parent=data.ball.top,
                                   create_zero=False,
                                   matrix=ankle_matrix,
                                   create_cnst=True)
    data.cnst = data.ankle.cnst

    # footroll attributes
    if not attr_obj:
        attr_obj = ctrl
    attr_data = mattr.add_footroll_attr(attr_obj,
                                        controls=[data.heel.obj,
                                                  data.ball.obj,
                                                  data.toes.obj],
                                        ankle=data.ankle.obj)

    attr_data.swivel >> swivel_srt.obj.ry
    attr_data.swivelPivot >> swivel_chce.selector

    attr_data.bank >> bank_cond.firstTerm
    attr_data.bank >> bank_cond.colorIfTrueR
    attr_data.bank >> bank_cond.colorIfFalseG
    bank_cond.outColorR >> data.inner.obj.rz
    bank_cond.outColorG >> data.outer.obj.rz

    return data


def set_footroll_ctrl_shape(footroll_ctrl, foot_matrix, inner_matrix, outer_matrix, front_matrix, back_matrix,
                            scale=1):
    """

    :param foot_matrix:
    :param inner_matrix:
    :param outer_matrix:
    :param front_matrix:
    :param back_matrix:
    :return:
    """
    # flatten the matrix positions
    inner_pos = mmtrx.get_posvector(inner_matrix)
    outer_pos = mmtrx.get_posvector(outer_matrix)
    heel_pos = mmtrx.get_posvector(back_matrix)
    toes_pos = mmtrx.get_posvector(front_matrix)
    ctrl_pos = mmtrx.get_posvector(foot_matrix)

    inner_pos.y = 0
    outer_pos.y = 0
    heel_pos.y = 0
    toes_pos.y = 0
    ctrl_pos.y = 0

    # get the distances
    height = mmtrx.get_posvector(foot_matrix).y
    length = (toes_pos - heel_pos).length()
    width = (inner_pos - outer_pos).length()
    back_length = (ctrl_pos - heel_pos).length()

    # scale the lengths
    scaled_length = length * scale
    new_back_length = back_length + ((scaled_length - length) / 2)

    # get the shape data
    shape = footroll_ctrl.getShape(type="nurbsCurve")
    vectors = _get_vectors_from_shape(shape)

    new_vectors = []
    for vec in vectors:
        # change the length
        vec.x *= width * scale
        vec.z *= scaled_length

        # move it down to the floor
        vec = vec - om.MVector(0, height, 0)

        # move it to the centre
        vec = vec + om.MVector(0, 0, (scaled_length / 2) - new_back_length)
        new_vectors.append(vec)

    # set the vectors for the main shape
    _set_vectors_in_shape(shape, new_vectors)


def create_aimer(node, world_pos_attr, namer=None, aim_vec=(0, 1, 0)):
    namer = namer or mname.Name(node)
    mpmm = pm.createNode('pointMatrixMult',
                         name=namer.replace(suffix='pointMatrixMult'))
    angl = pm.createNode('angleBetween',
                         name=namer.replace(suffix='angleBetween'))
    node.parentInverseMatrix >> mpmm.inMatrix
    world_pos_attr >> mpmm.inPoint
    mpmm.o >> angl.v2
    angl.v1.set(aim_vec)
    return angl.euler


def create_orients(ctrl, parent, world_pos_attr, blend_attr=None, aim_vec=(0, 1, 0)):
    # create auto orient setup
    ori_zero = pm.createNode('transform',
                             name=ctrl.namer.replace(suffix='ORI_ZERO'),
                             parent=parent)
    ori = pm.createNode('transform',
                        name=ctrl.namer.replace(suffix='ORI'),
                        parent=ori_zero)
    # create aimer
    aimer = create_aimer(ori, world_pos_attr, namer=ctrl.namer, aim_vec=aim_vec)

    if blend_attr is not None:
        mpb.PairBlend(name=ctrl.namer.replace(suffix='pairBlend'),
                      source1=aimer.get(),
                      source2=aimer,
                      target=ori,
                      weight=blend_attr,
                      connect="r")
    else:
        aimer >> ori.r
    ctrl.zero.setParent(ori)
    return ori


def create_pole_vector(root, ik_ctrl, namer=None):
    # create pole-vector

    namer = namer or mname.Name(root.node())
    root_pos = get_world_pos_attr(root, namer)
    ik_ctrl_pos = get_world_pos_attr(ik_ctrl, namer)

    mvcp = mcreate.node('vectorProduct',
                        name=namer.replace(add_to_tags='pole',
                                           suffix='MVCP'),
                        operation=2).node
    vec = mcreate.node('sub', name=namer.replace(add_to_tags='pole',
                                                 suffix='SUB')).node
    mvmp = mcreate.node('vectorProduct',
                        name=namer.replace(add_to_tags='pole',
                                           suffix='MVMP'),
                        operation=3).node

    ik_ctrl.ctrl.worldMatrix >> mvmp.matrix
    mvmp.input1.set(0, 0, -1)
    root_pos >> vec.i3[1]
    ik_ctrl_pos >> vec.i3[0]
    mvmp.o >> mvcp.i1
    vec.o3 >> mvcp.i2
    return mvcp.o


# ========================================================================
# Non-Public -------------------------------------------------------------
# ========================================================================

def _make_transform(namer, suffix, parent=None, match=None):
    transform = pm.createNode("transform",
                              n=namer.replace(suffix=suffix),
                              p=parent
                              )
    if match:
        transform.setMatrix(match.getMatrix(ws=True),
                            ws=True
                            )
    return transform


def _make_decompose_node(matrix_in_attr, namer):
    """ makes a decompose node """
    name = namer.replace(suffix="decomposeMatrix")
    # avoid creation of already existing node
    if pm.objExists(name):
        return pm.PyNode(name)

    decompose = pm.createNode("decomposeMatrix", name=name)
    matrix_in_attr >> decompose.inputMatrix
    return decompose


def get_world_pos_attr(node, namer):
    """ from the effector control, get an attribute to drive an effector """
    # if the eff_ctrl is a matrix attribute, decompose and use
    if isinstance(node, pm.Attribute):
        if node.type() != "matrix":
            raise ValueError
        world_pos_attr = node

    # if it has a cnst, use the world position
    # if just a control, then decomp it's world matrix
    elif isinstance(node, rigobj.RigObject):
        if node.cnst:
            world_pos_attr = node.cnst.worldPosition
        else:
            world_pos_attr = node.top.worldMatrix

    # otherwise use it as a control
    else:
        # check for a locator shape
        if node.getShape().type() == "locator":
            world_pos_attr = node.getShape().worldPosition
        else:
            world_pos_attr = node.worldMatrix

    # convert a matrix attr into a translation
    if world_pos_attr.type() == "matrix":
        dcmp = _make_decompose_node(world_pos_attr,
                                    namer)
        world_pos_attr = dcmp.outputTranslate
    return world_pos_attr


def _create_spine_ik_ctrl_cint(crv, matrices, num_ctrls=1, aim='+y', up='+z'):
    ''' create curveInterp-node for given curve '''

    cint = mcint.CurveInterp(crv, matrix_objs=matrices, add_to_tags='ctrl')
    cint.samplemode = 1
    cint.arclen = 'Maya'
    val_list = list(np.linspace(0.0, 1.0, num=num_ctrls + 2))[1:-1]
    insamples = []
    for val in val_list:
        insamples.append(val)
        insamples.append(val + 0.01)  # for aiming reasons
    cint.insamples = insamples
    cint.set_orientation('aim_ahead', aim, up[-1])
    return cint


def _create_spine_cint(crv, matrices, ctrl_list,
                       numsamples=5, sample_type='transform',
                       aim='+y', up='+z', parent=None):
    ''' create curveInterp-node for given curve '''
    cint = mcint.CurveInterp(crv, matrix_objs=matrices, num_samples=numsamples)
    cint.samplemode = 0
    cint.arclen = 'Maya'
    cint.set_orientation('aim_ahead', aim, up[-1])

    cint.create_sample_objs(node_type=sample_type,
                            suffix='SRT',
                            last=False,
                            parent=parent,
                            hierarchy=True,
                            create_offsets=True
                            )

    _create_offset_arrayramp(ctrl_list, cint.sample_offsets, name=cint.namer.replace(suffix='ARMP'))

    return cint


def _create_ik_spine_curve(loc_list, global_scale, namer):
    ''' sort out hierarchy of the locators and deal with the scaling
    of the tangents '''

    do_extra = len(loc_list) > 3

    # sort out hierarchy
    loc_list[1].transform.setParent(loc_list[0].transform)
    loc_list[1].shape.localPosition.set(loc_list[1].transform.t.get())
    loc_list[1].transform.t.set(0, 0, 0)
    loc_list[1].transform.r.set(0, 0, 0)

    if do_extra:
        loc_list[-2].transform.setParent(loc_list[-1].transform)
        loc_list[-2].shape.localPosition.set(loc_list[-2].transform.t.get())
        loc_list[-2].transform.t.set(0, 0, 0)
        loc_list[-2].transform.r.set(0, 0, 0)

    # distance
    dist = pm.createNode('distanceBetween',
                         name=namer.replace(suffix='DIST'))
    loc_list[0].transform.wm >> dist.inMatrix1
    loc_list[-1].transform.wm >> dist.inMatrix2

    div = mcreate.node('div', name=namer.replace(suffix='DIV')).node
    mdl = mcreate.node('mdl', name=namer.replace(tags='globalscale',
                                                 suffix='MDL')).node
    mdl.i2.set(1.0)
    dist.distance >> mdl.i1
    mdl.output >> div.i1x
    div.i2x.set(dist.distance.get())

    # tangent-scaling
    div.ox >> loc_list[1].transform.sx
    div.ox >> loc_list[1].transform.sy
    div.ox >> loc_list[1].transform.sz
    if do_extra:
        div.ox >> loc_list[-2].transform.sx
        div.ox >> loc_list[-2].transform.sy
        div.ox >> loc_list[-2].transform.sz

    global_scale >> mdl.i2

    crv = pm.curve(name=namer.replace(add_to_tags='ik', suffix='CRV'), d=2,
                   p=[(0, 0, 0)] * len(loc_list))
    for i, loc in enumerate(loc_list):
        loc.shape.wp >> crv.cv[i]

    return crv


def _create_offset_arrayramp(ctrl_list, srt_list, name='C_generic_ARMP'):
    '''
    create millArrayRampSRT-node and link it with the given ctrls and transforms.
    It is assumed the first and the last element will be zero'''

    armp = pm.createNode('millArrayRampSRT', name=name)

    insample_list = list(np.linspace(0.0, 1.0, num=len(ctrl_list) + 2))
    outsample_list = list(np.linspace(0.0, 1.0, num=len(srt_list)))

    tmp = pm.createNode('transform')

    # the arrayRampNode is still a bit dodgy... complicated way to set up
    in_list = [tmp, ] + [ctrl.ctrl for ctrl in ctrl_list] + [tmp, ]
    for i, ctrl in enumerate(in_list):
        ctrl.t >> armp.inData[i].inTranslate
        ctrl.r >> armp.inData[i].inRotate
        ctrl.s >> armp.inData[i].inScale

    for i, pos in enumerate(insample_list):
        armp.inSamples[i].set(pos)

    for i, pos in enumerate(outsample_list):
        armp.outSamples[i].set(pos)

    pm.delete(tmp)

    for i, srt in enumerate(srt_list):
        armp.outData[i].outTranslate >> srt.t
        armp.outData[i].outRotate >> srt.r
        armp.outData[i].outScale >> srt.s

    return armp


def _get_vectors_from_shape(shape):
    """
    Gets all the vectors from a shape as a list of MVectors
    :param shape:
    :return:
    """
    out = []
    for cv in shape.comp('cv'):
        out.append(om.MVector(cv.getPosition()))
    return out


def _set_vectors_in_shape(shape, vectors):
    for cv, v in zip(shape.comp('cv'), vectors):
        cv.setPosition([v.x, v.y, v.z], space="preTransform")
    shape.updateCurve()
