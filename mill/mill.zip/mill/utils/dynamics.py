'''
Created on 16 Feb 2017

@author: andreasg
'''
import pymel.core as pm
import millrigger.utils.attributes as mattr
import millrigger.utils.name as mname
from millrigger.globals.rig import GLOBAL_CTRL

pm.loadPlugin('millMatrixRamp', qt=True)


def add_millspring(ctrl, child, zero, attr_holder=None, transform=None):
    '''
    - add a millspring-driven transform as a parent of the control
    - all additional attributes will be added and connected to the attr_holder

    :param ctrl: The control that will get dynamic-rotations
    :param child: a child-node of the control that defines the "length" of the control-element
    :param zero: the zero-node of the control
    :param attr_holder: where the dynamics-attributes shall live...
    :param transform: if given, adds the dynamic-rotation to this tranform
    :return:
    '''
    namer = mname.Name(ctrl)
    attr_data = mattr.add_millspring_attr(attr_holder)
    mspg = pm.createNode('millSpring', name=namer.replace(suffix='millSpring'))

    # connect attr_holder with millSpring
    attr_data.enable >> mspg.disableSimulation
    attr_data.cache >> mspg.enableCache
    attr_data.startFrame >> mspg.startFrame
    attr_data.mass >> mspg.mass
    attr_data.angularStiffness >> mspg.angularStiffness
    attr_data.angularDamping >> mspg.angularDamping
    attr_data.maxAngleBounce >> mspg.maxAngleBounce
    attr_data.noiseMagnitude >> mspg.noiseMagnitude
    attr_data.noiseFrequency >> mspg.noiseFrequency
    attr_data.gravityVector >> mspg.gravityVector
    attr_data.windVector >> mspg.windVector
    ctrl.ro >> mspg.rotateOrder

    if pm.objExists(GLOBAL_CTRL):
        pm.Attribute("%s.startFrame" % GLOBAL_CTRL) >> attr_data.startFrame

    transform = transform or pm.createNode('transform',
                                           name=namer.replace(suffix='CTRL_ROT'),
                                           p=zero)
    ctrl.ro >> transform.ro
#     ofs = ctrl.getParent()
#     if ofs == zero:
#         ctrl.setParent(transform)
#     else:
#         ofs.setParent(transform)

    child.matrix >> mspg.baseOffset
    zero.worldMatrix >> mspg.inMatrix
    mspg.outRotate >> transform.rotate

    # time
    out_time = pm.ls(type='time')[0].outTime
    out_time >> mspg.time





