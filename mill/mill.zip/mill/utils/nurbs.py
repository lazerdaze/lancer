"""
.. module:: util.nurbs
   :synopsis: Functions for nurbsCurves and nurbsSurfaces

.. moduleauthor:: andreasg
"""

import maya.api.OpenMaya as om
import maya.OpenMaya as oldOM
import millrigger.utils.api as mapi


def percentage_to_param(curve_shape, perc=0.5):
    """ Get the real percentage-parameter of a curve

    :param curve_shape: Curve to initialize the MFnNurbsCurve function class
    :type curve_shape: NurbsCurveShape

    :param perc: Percentage-value of position along the curve
    :type perc: Float

    :rType: Float
    """
    curveFn = mapi.get_mfn_nurbscurve(curve_shape)
    dist = curveFn.length()
    param = curveFn.findParamFromLength(dist*perc)
    return param


def point_on_curve_position(curve_shape, param, use_percentage=True):
    """ Get the position of a point on a curve by parameter/percentage

    :param curve_shape: Curve to initialize the MFnNurbsCurve function class
    :type curve_shape: NurbsCurveShape

    :param param: Parameter/percentage-value
    :type param: Float

    :param use_percentage: Treat param as percentage-value
    :type use_percentage: Float

    :rType: MVector

    .. note::
        percentage is calculated by arclength and therefore more precise)
    """
    curveFn = mapi.get_mfn_nurbscurve(curve_shape)
    if not curveFn:
        return

    pos = om.MPoint()
    if use_percentage is True:
        param = percentage_to_param(curve_shape, perc=param)
    pos = curveFn.getPointAtParam(param)
    return om.MVector(pos.x, pos.y, pos.z)


def find_length_from_param(crv_shape, param, max_iter=10, tol=0.00001):
    """
    Get the lengthValue of a curve based on the given Parameter.
    Fun Fact:
    "This is a function that Autodesk simply forgot about as it is documented but not existing!"

	:param curve_shape: Curve to initialize the MFnNurbsCurve function class
	:type curve_shape: NurbsCurveShape

	:param param: curveParameter-value
	:type param: Float

	:param max_iter: max count of iterations to approximate the value
	:type max_iter: Float

	:param tol: tolerance
	:type tol: Float

	:rType: Float
	"""
    curveFn = mapi.get_mfn_nurbscurve(crv_shape)
    len = curveFn.length()
    min_val = crv_shape.minValue.get()
    max_val = crv_shape.maxValue.get()
    segment_length = 0
    last_length = 0
    for i in range(max_iter):
        perc = (max_val - min_val) * 0.5 + min_val
        segment_length = len * perc
        test_param = curveFn.findParamFromLength(segment_length)
        if test_param == param:
            return segment_length
        elif test_param > param:
            max_val = perc
        else:
            min_val = perc
        if abs(last_length - segment_length) <= tol:
            return segment_length
        last_length = segment_length
    return segment_length


def closest_param_on_curve(curve_shape, pos):
    """ Get the parametervalue of the closest point to a curve

	:param curve_shape: Curve to initialize the MFnNurbsCurve function class
	:type curve_shape: NurbsCurveShape

	:param pos: pointposition in worldspace
	:type pos: MVector

	:rType: Float
    """
    mPnt = om.MPoint(pos)
    curveFn = mapi.get_mfn_nurbscurve(curve_shape)
    param = curveFn.closestPoint(mPnt)[1]
    return param
