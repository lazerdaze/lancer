"""
.. module:: history
   :synopsis: Collection of helperfunctions to cleanup the construction-history

.. moduleauthor:: andreasg
"""

import pymel.core as pm
import millrigger.utils.name as mname


# DEFORMER
def cleanup_deformerhistory(node):
    history_list = [obj for obj in pm.listHistory(node) if pm.objectType(obj, isAType='geometryFilter')]
    for deformer in history_list:
        cleanup_deformer(deformer)


def cleanup_deformer(deformer):
    deformer_type = deformer.type()
    namer = cleanup_handle(deformer, deformer_type)
    cleanup_deformertools(deformer, namer=namer)
    return deformer


def cleanup_handle(deformer, deformer_type):
    func_dict = {'ffd': cleanup_latticehandle,
                 'softMod': cleanup_softmodhandle,
                 'cluster': cleanup_clusterhandle,
                 'nonLinear': cleanup_nonlinearhandle,
                 'sculpt': cleanup_sculpthandle,
                 'textureDeformer': cleanup_texturedeformerhandle
                 }
    # deal with the deformers exceptions softMod and Lattice
    # they have a special setup for their deformerhandles
    if deformer_type in func_dict:
        return func_dict[deformer_type](deformer)
    else:
        geo = pm.deformer(deformer, q=True, geometry=True)[0]
        namer = mname.Name(geo)
        namer.add_to_tags(namer.suffix.lower())
        return namer


def cleanup_latticehandle(deformer, namer=None):
    base = deformer.baseLatticeMatrix.inputs()[0]
    lattice = deformer.deformedLatticeMatrix.inputs()[0]
    namer = namer or mname.Name(lattice)
    lattice.rename(namer.replace(suffix='lattice'))
    base.rename(namer.replace(suffix='baseLattice'))
    return namer


def cleanup_softmodhandle(deformer, namer=None):
    handle = deformer.matrix.inputs()[0]
    namer = namer or mname.Name(handle)
    if not handle.name().endswith("_CTRL"):
        handle.rename(namer.replace(suffix='softModHandle'))
    return namer


def cleanup_clusterhandle(deformer, namer=None):
    handle = deformer.matrix.inputs()[0]
    namer = namer or mname.Name(handle)
    if not handle.name().endswith("_CTRL"):
        handle.rename(namer.replace(suffix='clusterHandle'))
    return namer


def cleanup_nonlinearhandle(deformer, namer=None):
    handle = deformer.outputs(type='transform')[0]
    namer = namer or mname.Name(handle)
    handle.rename(namer.replace(suffix=handle.getShape()))
    namer.suffix = namer.suffix[:-1]  # get rid of the "H"
    return namer


def cleanup_sculpthandle(deformer, namer=None):
    handle = deformer.sculptObjectGeometry.inputs()[0]
    namer = namer or mname.Name(handle)
    # sculpt-specific
    origin = deformer.startPosition.inputs(type='locator')[0]
    origin.rename(handle + '_LOC')
    return namer


def cleanup_texturedeformerhandle(deformer, namer=None):
    handle = deformer.handleMatrix.inputs()[0]
    namer = namer or mname.Name(handle, suffix='textureDeformer')
    handle.rename(namer.replace(suffix='textureDeformerHandle'))
    return namer


def cleanup_generichandle(deformer, namer=None):
    handle = deformer.outputs(type='transform')[0]
    namer = namer or mname.Name(handle)
    if not handle.name().endswith("_CTRL"):
        handle.rename(namer.replace(suffix=deformer))
    return namer


def cleanup_deformertools(deformer_node, namer=None):
    namer = namer or mname.Name(deformer_node)
    type_suffix = mname.get_typesuffix(deformer_node)
    deformer_tools = pm.deformer(deformer_node, q=True, deformerTools=True)
    shapes = pm.deformer(deformer_node, q=True, geometry=True)

    if type_suffix == 'VTXC':
        deformer_node.rename(_create_vertexconstraint_name(deformer_node, namer=namer))
    else:
        deformer_node.rename(namer.replace(suffix=type_suffix))

    deformer_set = deformer_node.message.outputs(type='objectSet')[0]
    deformer_set.rename(namer.replace(suffix=type_suffix + '_SET'))
    gpts_list = [item for item in deformer_tools if item.type() == 'groupParts']
    gid_list = [item for item in deformer_tools if item.type() == 'groupId']
    for shp, gpts, gid in zip(shapes, gpts_list, gid_list):
        if len(shapes) > 1:
            add_to_tags = mname.Name(shp).part
        else:
            add_to_tags = None
        gpts.rename(namer.replace(add_to_tags=add_to_tags, suffix=type_suffix + '_GPTS'))
        gid.rename(namer.replace(add_to_tags=add_to_tags, suffix=type_suffix + '_GID'))


# DEFORMER
def cleanup_unitconversions(node):
    if pm.objectType(node) == 'unitConversion':
        con = node.inputs(p=True)[0]
        con_name = con.name()
        namer = mname.Name(con_name)
        unitList = con.outputs(type='unitConversion')
        unitList.remove(node)
        val = node.conversionFactor.get()
        # the conversionFactor shouldn't be changed as it can lead to undesirable results, but just in case...
        for unit in unitList:
            if unit.conversionFactor.get() == val:
                outList = unit.output.outputs(p=1)
                for out in outList:
                    node.output >> out
                pm.delete(unit)
                print ('--deleted node %s. New connection with %s\n' % (unit, node))
        attr = pm.attributeName(con_name, s=1)  # get shortname of attribute
        add_to_tags = [attr.lower().split('[', 1)[0]]
        if (val < 0):
            add_to_tags.append['neg']  # if the scaling is negative (which it shouldn't !)
        if '[' in con_name:
            index = con_name.split('[')[1]
            index = index.split(']')[0]
            add_to_tags.append(index)
        name = namer.replace(add_to_tags=add_to_tags, suffix='UNIT')
        pm.rename(node, name)
        return name


# RIVETS
def cleanup_rivets(rivets):
    rivets = pm.ls(rivets)
    for rvt in rivets:
        x = [x for x in rvt.inputs(p=1) if "worldMatrix" in x.name() or "worldSpace" in x.name()][0]
        name = x.node().getParent().name().rsplit("_", 1)[0]
        if "nurbs" in rvt.nodeType():
            name += "_NRVT"
        elif "poly" in rvt.nodeType():
            name += "_PRVT"
        rvt.setName(name)


# CONSTRUCTION HISTORY
def delete_history(mode='all'):
    # converts selection into transform-nodes that can be 'killed'
    # this avoids the problem of mixed component and nodeselections.
    orig_list = pm.selected()
    node_list = list(set([obj.node() for obj in orig_list]))
    if mode == 'all':
        # deletes the complete constructionhistory
        pm.delete(node_list, ch=True)
    elif mode == 'pre':
        # removes only modelling-nodes before any deformer
        pm.bakePartialHistory(node_list, pre=True)
    else:
        # removes all nonDeformer-nodes form history
        pm.bakePartialHistory(node_list, ppt=True)


def _create_vertexconstraint_name(deformer, namer=None):
    src = deformer.targetMesh.inputs(type='mesh')[0]
    add_to_tags = mname.camelcase(mname.Name(src).basename)
    name = namer.replace(add_to_tags=add_to_tags, suffix='VTXC')
    return name
