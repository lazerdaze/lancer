"""
Functions for creation of transforms

.. module:: util.nodes.transforms
   :synopsis: Functions for creation of transforms

.. moduleauthor:: andreasg

"""

# maya modules
import pymel.core as pm

# package modules
from millrigger.utils import name as mname
from millrigger.utils import transform as mtrans
from millrigger.utils import attributes as mattr


def dummycube(name, skip=False, parent=None):
    ''' Create a simple rgb coloured polycube for visual feedback

    :param name: Name of node
    :type name: String

    :param skip: If node already exists in scene, skip creation and return existing node
    :type skip: Boolean

    :rType: PyNode
    '''

    if skip and pm.objExists(name):
        cube = pm.PyNode(name)
    else:
        cube = pm.polyCube(name=name, w=1, h=1, d=1, ch=False)[0]
        cube_color_dict = {'[*][0]': (0.35, 0.35, 0.65),
                           '[*][1]': (0.35, 0.65, 0.35),
                           '[*][2]': (0.45, 0.45, 0.55),
                           '[*][3]': (0.45, 0.55, 0.45),
                           '[*][4]': (0.65, 0.35, 0.35),
                           '[*][5]': (0.55, 0.45, 0.45)
                           }

        for k in cube_color_dict:
            vfList = pm.ls('{0}.vtxFace{1}'.format(cube, k))
            pm.polyColorPerVertex(vfList, rgb=cube_color_dict[k])
        cube.getShape().displayColors.set(True)

    if parent:
        cube.setParent(parent)
        cube.t.set(0, 0, 0)
        cube.r.set(0, 0, 0)
        cube.s.set(1, 1, 1)
    return cube


def offset(node, name=None, node_type='transform', suffix='OFS',
           skip_index=False, match='srtjp', connect=None):
    '''Create a transform-node with as offset and return a Rigdata-class

    :param node: node that gets new parent-transform
    :type node: Transform

    :param name: Name of node
    :type name: String

    :param node_type: valid values: "transform", "joint"
    :type node_type: String

    :param suffix: new suffix will replace original suffix
    :type suffix: String

    :param skip_index: removes index from name
    :type skip_index: Boolean

    :param match: match SRT of given node
    :type match: Transform

    :param connect: Give a list of the plugs that should be transferred
    :type connect: List of Attributes

    :rType: PyNode

    '''

    if node_type not in ['transform', 'joint']:
        raise ValueError('NodeType invalid : %s' % node_type)

    # name >------------------------------------------------
    if not name:
        if skip_index:
            name = mname.replace(node.name(), index=None, suffix=suffix)
        else:
            name = mname.replace(node.name(), suffix=suffix)
    # name <------------------------------------------------

    if pm.objExists(name):
        raise RuntimeError('Node already exists in scene : %s' % name)

    ofs = pm.createNode(node_type, name=name, parent=node.getParent())
    ofs.ro.set(node.ro.get())

    if match:
        mtrans.match(node, [ofs])
    else:
        ofs.t.set(0, 0, 0)
        ofs.r.set(0, 0, 0)
        ofs.s.set(1, 1, 1)
        if node_type == 'joint':
            ofs.jo.set(0, 0, 0)

    if connect:
        mattr.transfer_connections(node, ofs, plugs=connect, keep=False)

    pm.parent(node, ofs)
    return ofs

