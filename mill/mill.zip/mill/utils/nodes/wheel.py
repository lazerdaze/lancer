'''
Created on 5 Jul 2017

@author: andreasg
'''
import pymel.core as pm
import millrigger.utils.name as mname
import millrigger.utils.nodes.create as mcre
import millrigger.utils.matrix as mmtrx
from millrigger.globals.rig import GLOBAL_CTRL
from millrigger.utils.attributes import add_vector_attr

WHEEL_ROTATION = """
if (frame <= {startframe}){{

    float $start = {floor}.startRot;
    {mdl}.input1 = $start;
    float $cx = {pos}.outputX;
    float $cy = {pos}.outputY;
    float $cz = {pos}.outputZ;

    {floor}.posX = $cx;
    {floor}.posY = $cy;
    {floor}.posZ = $cz;

}} else {{

    float $rotX = {mdl}.input1;
    float $cx = {pos}.outputX;
    float $cy = {pos}.outputY;
    float $cz = {pos}.outputZ;
    float $ax = {aim}.outputX;
    float $ay = {aim}.outputY;
    float $az = {aim}.outputZ;
    float $lx = {floor}.posX;
    float $ly = {floor}.posY;
    float $lz = {floor}.posZ;

    vector $move = << $cx, $cy, $cz >> - << $lx, $ly, $lz >>;
    vector $aim = << $ax, $ay, $az >> - << $cx, $cy, $cz >>;

    float $dist = mag($move);
    float $angle = angle($aim, $move);

    float $rotVal = 57.295828 * $dist / {radius} / {scale};
    if ($angle < 1.570795)
    {{
        {mdl}.input1 = $rotX + $rotVal;
    }} else {{
        {mdl}.input1 = $rotX - $rotVal;
    }}

    {floor}.posX = $cx;
    {floor}.posY = $cy;
    {floor}.posZ = $cz;
}}
"""


class Wheel(object):
    """
    class to create an expression-driven wheel-construct
    """

    def __init__(self, center, floor, name=None, parent=None, aim_axis='+z', startframe=0):

        self.namer = mname.Name(name or center.name())
        self.center = center
        self.floor = floor
        self.parent = parent
        self.aim_axis = aim_axis
        self.startframe = startframe
        self.out = self.build()

    def build(self):
        # Create nodes for expression

        center_matrix = mmtrx.get_matrix(self.center)
        floor_matrix = mmtrx.get_matrix(self.floor)
        aim_vec = mmtrx.get_as_mvector(self.aim_axis)

        add_vector_attr(self.floor, 'pos', k=False, cb=False)
        self.floor.addAttr("startframe", dv=self.startframe, at='long')

        rot = mcre.node('transform',
                        name=self.namer.replace(suffix="ROT"),
                        parent=self.center,
                        matrix=center_matrix).transform

        rot.rotateX >> self.floor.wheelRotValue

        # get aim-position
        aim_mpmm = pm.createNode('pointMatrixMult',
                                 name=self.namer.replace(add_to_tags='aim',
                                                         suffix='pointMatrixMult'))
        aim_mpmm.inPoint.set(aim_vec)
        self.floor.worldMatrix >> aim_mpmm.inMatrix

        # using a pointMatrixMult to extract the worldposition
        pos_mpmm = pm.createNode('pointMatrixMult',
                                 name=self.namer.replace(add_to_tags='pos',
                                                         suffix='pointMatrixMult'))
        pos_mpmm.inPoint.set(0, 0, 0)
        self.floor.worldMatrix >> pos_mpmm.inMatrix

        # create utility nodes
        mdl = pm.createNode('multDoubleLinear',
                            name=self.namer.replace(suffix='MDL'))
        adl = pm.createNode('addDoubleLinear',
                            name=self.namer.replace(suffix='ADL'))

        self.floor.blendRot >> mdl.input2
        self.floor.animRot >> adl.input2
        mdl.output >> adl.input1
        adl.output >> rot.rx

        # Get Radius
        try:
            radius_attr = self.center.radius
        except:
            radius_attr = mmtrx.matrix_distance(floor_matrix, center_matrix)

        # Get Scale
        try:
            scale_node = pm.PyNode(GLOBAL_CTRL)
            scale_attr = scale_node.globalScale
        except:
            scale_attr = 1

        # create Expression
        format_expr = WHEEL_ROTATION.format(floor=self.floor,
                                            mdl=mdl,
                                            pos=pos_mpmm,
                                            aim=aim_mpmm,
                                            radius=radius_attr,
                                            scale=scale_attr,
                                            startframe=self.floor.startframe)

        pm.expression(s=format_expr, name=self.namer.replace(suffix='EXP'))

        return rot
