"""
.. module:: utils.nodes.bezier
   :synopsis: Class for creation of bezier-style-nurbscurves

.. moduleauthor:: andreasg
"""

# maya imports
import pymel.core as pm

# package imports
from millrigger.globals import rig as RIG

from millrigger.utils import name as mname
from millrigger.utils.nodes import create as mcrt
from millrigger.utils.maths import linspace_float


class BezierChain(object):

    ''' Create a chain of 4-CVs-curves and add bezier-style behaviour to it

    :param name: Name of node.
    :type name: String

    :param axis: Orientation of the curve
    :type axis:  +x/+y/+z/-x/-y/-z

    :param num_segments: Number of curvesegments (== number of handles-1)
    :type num_segments:  Integer

    :param namer: an existing Nameclass can be used
    :type namer: NameClass

    :rType: PyNode

    '''

    def __init__(self, name='C_bezier_CRV', axis='+y', num_segments=2, namer=None,
                 start_value=0.0, end_value=1.0):

        self._namer = namer or mname.Name(name)
        self._name = self._namer.replace(suffix='CRV')
        self._axis = axis
        self._axis_vec = RIG.STR_TO_VEC_SWITCH[axis]
        self._start_value = start_value
        self._end_value = end_value
        self._loc_objs = self._create_locs(num_segments)
        self._weights = [1.0, 0.5, 0.5, 1.0]

        # results
        self.transforms = [obj.transform for obj in self._loc_objs]
        self.crv_transform = self._create_transform()
        self.crv_shapes = []
        self.aim_attrs = None
        self.build()

    def build(self):
        self.aim_attrs = []
        for loc in self._loc_objs:
            loc.transform.addAttr('aim', min=0.0, dv=0.0, k=True)
            self.aim_attrs.append(loc.transform.aim)
        i = 1
        for start_loc_obj, end_loc_obj in zip(self._loc_objs[:-1], self._loc_objs[1:]):
            self._create_segment(start_loc_obj, end_loc_obj, i)
            i += 1

    def _create_locs(self, num_segments):
        loc_objs = []
        placement = linspace_float(self._start_value, self._end_value, num=num_segments + 1)

        for i, val in enumerate(placement):
            zero = pm.createNode('transform',
                                 name=self._namer.replace(index=i + 1, suffix='LOC_ZERO'))
            pos = pm.createNode('transform',
                                name=self._namer.replace(index=i + 1, suffix='LOC_POS'),
                                parent=zero)
            loc = mcrt.locator(self._namer.replace(index=i + 1, suffix='LOC'), parent=zero)
            loc.zero = zero
            loc.pos = pos
            loc.transform.t >> pos.t
            loc_objs.append(loc)
            zero.t.set(val * self._axis_vec)
        return loc_objs

    def _create_transform(self):
        '''
        Create transform-node as parent for all nurbsCurve-shape-nodes.
        Connect with globalScale-attribute if given.
        '''
        transform = pm.createNode('transform', name=self._namer.create_name())
        transform.addAttr('bezier', dt='string')
        return transform

    def _create_segment(self, start_loc_obj, end_loc_obj, index=None):
        '''
        create a single segment of the curveshape
        '''
        start_loc = start_loc_obj.transform
        start_pos = start_loc_obj.pos

        end_loc = end_loc_obj.transform
        end_pos = end_loc_obj.pos

        out_tangent_loc = self._create_tangent_loc(start_loc, end_loc, start_pos,
                                                   tag='out', index=index)
        in_tangent_loc = self._create_tangent_loc(end_loc, start_loc, end_pos,
                                                  tag='in', index=index)

        locs = [start_loc, out_tangent_loc, in_tangent_loc, end_loc]

        pointweights = [(0, 0, 0, w) for w in self._weights]
        crv = pm.curve(d=3, pw=pointweights,
                       name=self._namer.replace(index=index, suffix='CRV'))
        for i, loc in enumerate(locs):
            loc.getShape().worldPosition >> crv.cv[i]

        self.crv_shapes.append(crv.getShape())

        pm.parent(self.crv_shapes[-1], self.crv_transform, add=True, s=True)
        pm.delete(crv)

    def _create_tangent_loc(self, loc, aim_loc, pos, tag='out', index=None):
        # create_locator with local offset
        namer = mname.Name(self._name, add_to_tags=tag, index=index)
        scale_attr = 'scale' + tag.capitalize()
        loc.addAttr(scale_attr, min=0.0, max=1.0, dv=0.25, k=True)
        tangent_loc = mcrt.locator(namer.replace(suffix='LOC'), parent=loc)
        tangent_loc.transform.v.set(False)
        multiplier = -1.0 if tag == 'in' else 1.0
        if self._axis[0] == '-':
            multiplier *= -1

        # create aim and distance
        mpmm = pm.createNode('pointMatrixMult',
                             name=namer.replace(suffix='pointMatrixMult'))
        aim_loc.getShape().worldPosition >> mpmm.inPoint
        pos.worldInverseMatrix >> mpmm.inMatrix
        dist = pm.createNode('distanceBetween',
                             name=namer.replace(suffix='distanceBetween'))
        mpmm.o >> dist.point2

        #  scale of the tangent-locator
        mdl = pm.createNode('multDoubleLinear',
                            name=namer.replace(suffix='multDoubleLinear'))
        dist.distance >> mdl.i1
        mdl.i2.set(multiplier)
        mdl.o >> tangent_loc.shape.attr('lp' + self._axis[-1])
        loc.attr(scale_attr) >> tangent_loc.transform.attr('s' + self._axis[-1])

        # orientation of the tangent-locator (aim)
        angle = pm.createNode('angleBetween',
                              name=namer.replace(suffix='angleBetween'))
        angle.vector1.set(multiplier * self._axis_vec)
        mpmm.o >> angle.vector2
        pblnd = pm.createNode('pairBlend',
                              name=namer.replace(suffix='pairBlend'))
        angle.euler >> pblnd.ir2
        pblnd.outRotate >> tangent_loc.transform.r
        loc.aim >> pblnd.weight
        return tangent_loc.transform


