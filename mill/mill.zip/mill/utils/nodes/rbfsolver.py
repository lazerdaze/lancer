'''
Created on 12 Oct 2015

@author: andreasg
'''

# maya modules
import pymel.core as pm

# package modules
from millrigger.utils import name as mname


pm.loadPlugin('rbfSolver', quiet=True)


class RBFSolver(object):
    '''
    Wrapperclass for RBF-Solver
    '''

    def __init__(self, matrix=None, inv_matrix=None,
                 node=None, name='C_generic_RBF',
                 aim=(0, 1, 0), n=3, m=4, mode='blendshape'):
        '''
        Constructor
        '''
        if node is not None:
            self.namer = mname.Name(node.name())
        else:
            self.namer = mname.Name(name)
        self.matrix = matrix
        self.inv_matrix = inv_matrix
        self.n_dimension = n
        self.m_dimension = m
        self.aim = aim

        self.node = node
        self.build(mode)

    @property
    def mode(self):
        return self.node.blendShapeMode.get()

    @mode.setter
    def mode(self, value):
        '''Set part-property '''
        self.node.blendShapeMode.set(value)

    def build(self, mode):
        ''' create rbf solver if it doesn't already exits '''
        rbf_name = self.namer.replace(suffix='rbfSolver')
        if self.node is not None or pm.objExists(rbf_name):
            self.use_rbf_solver(rbf_name)
        else:
            if self.matrix is None or self.inv_matrix is None:
                raise ValueError('"matrix" and "inv_matrix" is needed !')
            self.create_rbf_solver(rbf_name, mode)
            self.create_driver()

    def create_rbf_solver(self, rbf_name, mode='blendshape'):
        ''' create rbf solver if it doesn't already exits '''

        self.node = pm.createNode('rbfSolver', name=rbf_name)
        if mode == 'blendshape':
            self.mode = 1
        else:
            self.mode = 0

        self.node.MDimension.set(self.m_dimension + self.mode)
        self.node.NDimension.set(self.n_dimension)
        self.node.distanceMode.set(1)
        self.node.rbfMode.set(2)
        self.node.normalize.set(0)
        for i in range(self.m_dimension):
            print self.node.mOutput[i].get()

    def use_rbf_solver(self, rbf_name):
        ''' create rbf solver if it doesn't already exits '''
        if self.node is None:
            self.node = pm.PyNode(rbf_name)
        self.n_dimension = self.node.NDimension.get()
        self.m_dimension = self.node.MDimension.get()
        print ('N Dimension : %d') % self.n_dimension
        print ('M Dimension : %d') % (self.m_dimension - self.mode)

    def create_driver(self):
        ''' create the control-trigger that provides the n-keys '''

        mmlt = pm.createNode('multMatrix', name=self.namer.replace(suffix='multMatrix'))
        mvmp = pm.createNode('vectorProduct', name=self.namer.replace(suffix='vectorProduct'))
        mvmp.operation.set(3)
        mvmp.input1.set(self.aim)
        mvmp.normalizeOutput.set(1)

        self.matrix >> mmlt.matrixIn[0]
        self.inv_matrix >> mmlt.matrixIn[1]
        mmlt.matrixSum >> mvmp.matrix
        for i, axis in zip(range(self.n_dimension), 'xyz'):
            mvmp.attr('o' + axis) >> self.node.nInput[i]

    def set_pose(self, *args):
        ''' set get values for given pose '''
        pose_index = args[0]
        n_input = self.node.nInput.get()
        for index, val in enumerate(args[1:]):
            self.node.poses[pose_index].mValue[index].set(val)
        if self.mode is True:
            self.node.poses[pose_index].mValue[self.m_dimension + 1].set(1)

        for i, n in enumerate(n_input):
            self.node.poses[args[0]].nKey[i].set(n)

    def init_pose(self):
        ''' set get values for given pose '''
        n_input = self.node.nInput.get()

        for index in range(self.m_dimension):
            self.node.poses[0].mValue[index].set(0)
        if self.mode is True:
            self.node.poses[0].mValue[self.m_dimension + 1].set(1)

        for i, n in enumerate(n_input):
            self.node.poses[0].nKey[i].set(n)

    def get_nkey(self, *args):
        pose_index = args[0]
        if args is not None:
            nkey = self.node.poses[pose_index].nKey.get()
        else:
            nkey = None
            pm.warning('need pose-index!')
        return nkey

    def set_nkey(self, *args):
        pose_index = args[0]
        values = args[1:]
        if args is not None:
            for i, val in enumerate(values):
                self.node.poses[pose_index].nKey[i].set(val)
        else:
            pm.warning('need values!')

    def get_mvalue(self, *args):
        pose_index = args[0]
        if args is not None:
            mvalue = self.node.poses[pose_index].mValue.get()
        else:
            mvalue = None
            pm.warning('need pose-index!')
        return mvalue

    def list_poses(self):
        n_input = self.node.nInput.get()
        print "active key : ", n_input
        for i, pose in enumerate(self.node.poses):
            nkey = pose.nKey.get()
            m_output = pose.mOutput.get()
            print ("pose %d: " % i),
            print nkey,
            print " >> ",
            print m_output


