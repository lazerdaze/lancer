"""
.. module:: utils.nodes.bezier
   :synopsis: Class for creation of bezier-style-nurbscurves

.. moduleauthor:: andreasg
"""

# maya imports
import pymel.core as pm

# package imports
from millrigger.globals import rig as RIG

from millrigger.utils import name as mname
from millrigger.utils.nodes import create as mcrt
from millrigger.utils import vector as mvec
from millrigger.utils.nodes.pairblend import PairBlend
from millrigger.utils.attributes import add_generic_blend


class Bezier(object):

    ''' Create a curve with 5/7 CVs and add bezier-style behaviour to it

    :param name: Name of node.
    :type name: String

    :param axis: Orientation of the curve
    :type axis:  +x/+y/+z/-x/-y/-z

    :param tangents: What parts to create tangents on
    :type tangents: String - all/mid/ends

    :param globalScale: globalScale-attribute
    :type globalScale: PyAttribute

    :rType: PyNode

    '''

    def __init__(self, name='C_bezier_CRV', axis='+y', tangents='all', aim=True,
                 globalScale=None, namer=None, crv=None):

        self._namer = namer or mname.Name(crv or name)
        self._axis = axis
        self._axis_vec = RIG.STR_TO_VEC_SWITCH[axis]
        self._tangents = tangents
        self._locs = None
        self._values = None
        self._weights = None
        self._index_dict = None
        self._positions = None
        self._aim = None
        self._global_scale = globalScale

        # results
        self.transforms = None
        self.crv = crv
        self.aim_attrs = None

        self.build(tangents=tangents, aim=aim)

    def _init_values(self, tangents, aim):
        if tangents == 'all':
            self._values = [-1.0, -0.75, -0.25, 0.0, 0.25, 0.75, 1.0]
            self._weights = [1.0, 0.5, 0.5, 1.0, 0.5, 0.5, 1.0]
            self._index_dict = {1: 0, 2: 3, 4: 3, 5: 6}
            self._aim = aim
        elif tangents == 'mid':
            self._values = [-1.0, -0.33, 0.0, 0.33, 1.0]
            self._weights = [1.0, 0.5, 1.0, 0.5, 1.0]
            self._index_dict = {1: 2, 3: 2}
            self._aim = False
        elif tangents == 'ends':
            self._values = [-1.0, -0.67, 0.0, 0.67, 1.0]
            self._weights = [1.0, 0.5, 1.0, 0.5, 1.0]
            self._index_dict = {1: 0, 3: 4}
            self._aim = False
        else:
            raise ValueError('Invalid value for "tangents" : %s' % self._tangents)

    def _create_curve(self):
        if self.crv is None:
            self._positions = [i * self._axis_vec for i in self._values]
            self._pointweights = [(p.x, p.y, p.z, w) for p, w in zip(self._positions, self._weights)]
            self.crv = pm.curve(pw=self._pointweights, name=self._namer.replace(suffix='CRV'))
            pm.rebuildCurve(self.crv, rt=0, kcp=True, kr=0, ch=False, rpo=True)

    def _create_locators(self):
        self._locs = []
        pos_list = mvec.get_cv_vectorlist(self.crv)
        for i, pos in enumerate(pos_list):
            loc = mcrt.simple_node('locator', self._namer.replace(index=i + 1, suffix='LOC'))
            loc.transform.t.set(pos)
            loc.shape.wp >> self.crv.cv[i]
            loc.shape.localScale.set(.1, .1, .1)
            self._locs.append(loc)

    def _create_hierarchy(self):
        # organising the locators
        for index in self._index_dict:
            loc = self._locs[index]
            loc.transform.setParent(self._locs[self._index_dict[index]].transform)
            loc.shape.localPosition.set(loc.transform.t.get())
            loc.transform.t.set(0, 0, 0)
            loc.transform.v.set(False)

    def _create_aim(self, aimer=None, aim=None, index=1):
        # create aim for the end-tangents
        if aimer and aim:
            # get node for creating the vector
            sub = pm.createNode('plusMinusAverage', name=self._namer.replace(index=index,
                                                                             add_to_tags='bezier',
                                                                             suffix='SUB'))
            sub.operation.set(2)

            # create the angle node with the right aim-vector
            angle = pm.createNode('angleBetween', name=self._namer.replace(index=index,
                                                                           add_to_tags='bezier',
                                                                           suffix='angleBetween'))
            aim_vec = self._axis_vec if index == 1 else -1.0 * self._axis_vec
            angle.v1.set(aim_vec)

            # half the value
            mdl = pm.createNode('multDoubleLinear', name=self._namer.replace(index=index,
                                                                             add_to_tags='bezier',
                                                                             suffix='multDoubleLinear'))
            mdl.i2.set(0.5)

            # get parent of the aimer node
            parent = aimer.getParent()

            # connect attributes
            aim.t >> sub.i3[0]
            parent.t >> sub.i3[1]
            for axis in 'xyz':
                # half the value to get a nicer angle
                if self._axis[-1] == axis:
                    sub.attr('o3' + axis) >> mdl.i1
                    mdl.o >> angle.attr('v2' + axis)
                else:
                    sub.attr('o3' + axis) >> angle.attr('v2' + axis)

            # create pairblend for blending the aim
            blend = add_generic_blend(parent, 'aim', default=1.0, keyable=True)
            PairBlend(source2=angle.euler, target=aimer.r, connect='r', weight=blend)

            return blend

    def build(self, tangents='all', aim=True):
        self._init_values(tangents, aim)
        self._create_curve()
        self._create_locators()
        self._create_hierarchy()
        locs = self._locs

        # distances
        dist_01 = pm.createNode('distanceBetween', name=self._namer.replace(index=1,
                                                                            add_to_tags='bezier',
                                                                            suffix='DIST'))
        dist_02 = pm.createNode('distanceBetween', name=self._namer.replace(index=2,
                                                                            add_to_tags='bezier',
                                                                            suffix='DIST'))
        global_div = pm.createNode('multiplyDivide', name=self._namer.replace(index=2,
                                                                              add_to_tags=['bezier', 'scale'],
                                                                              suffix='DIV'))
        global_div.operation.set(2)
        dist_01.distance >> global_div.i1x
        dist_02.distance >> global_div.i1y
        if self._global_scale:
            self._global_scale >> global_div.i2x
            self._global_scale >> global_div.i2y

        len_val = len(self._values)
        div = mcrt.node('div', name=self._namer.replace(add_to_tags='bezier',
                                                        suffix='DIV')).node

        locs[0].transform.wm >> dist_01.inMatrix1
        locs[(len_val - 1) / 2].transform.wm >> dist_01.inMatrix2
        locs[(len_val - 1) / 2].transform.wm >> dist_02.inMatrix2
        locs[len_val - 1].transform.wm >> dist_02.inMatrix1

        div.i2x.set(dist_01.distance.get())
        div.i2y.set(dist_02.distance.get())
        global_div.ox >> div.i1x
        global_div.oy >> div.i1y

        if self._tangents == 'all':
            div.ox >> locs[1].transform.sx
            div.ox >> locs[1].transform.sy
            div.ox >> locs[1].transform.sz
            div.ox >> locs[2].transform.sx
            div.ox >> locs[2].transform.sy
            div.ox >> locs[2].transform.sz
            div.oy >> locs[4].transform.sx
            div.oy >> locs[4].transform.sy
            div.oy >> locs[4].transform.sz
            div.oy >> locs[5].transform.sx
            div.oy >> locs[5].transform.sy
            div.oy >> locs[5].transform.sz

        else:
            div.ox >> locs[1].transform.sx
            div.ox >> locs[1].transform.sy
            div.ox >> locs[1].transform.sz
            div.oy >> locs[3].transform.sx
            div.oy >> locs[3].transform.sy
            div.oy >> locs[3].transform.sz

        if self._tangents == 'all':
            self.transforms = [loc.transform for loc in self._locs[::3]]
        else:
            self.transforms = [loc.transform for loc in self._locs[::2]]

        if self._aim is True:
            self.aim_attrs = []
            self.aim_attrs.append(self._create_aim(aimer=self._locs[1].transform,
                                                   aim=self._locs[3].transform,
                                                   index=1))
            self.aim_attrs.append(self._create_aim(aimer=self._locs[-2].transform,
                                                   aim=self._locs[3].transform,
                                                   index=2))


class SimpleBezier(object):

    ''' Create a simplified version curve with 5/7 CVs and add bezier-style behaviour to it

    :param name: Name of node.
    :type name: String

    :param axis: Orientation of the curve
    :type axis:  +x/+y/+z/-x/-y/-z

    :param tangents: What parts to create tangents on
    :type tangents: String - all/mid/ends

    :rType: PyNode

    '''

    def __init__(self, name='C_bezier_CRV', axis='+y', tangents='all', namer=None):

        self._namer = namer or mname.Name(name)
        self._scale_attr = 's' + axis[-1]
        self._axis_vec = RIG.STR_TO_VEC_SWITCH[axis]
        self._tangents = tangents
        self._locs = None
        self._values = None
        self._positions = None

        # results
        self.transforms = None
        self.crv = None

        self.build()

    def _init_values(self):
        if self._tangents == 'all':
            self._values = [-1.0, -0.75, -0.25, 0.0, 0.25, 0.75, 1.0]
            self.index_dict = {1: 0, 2: 3, 4: 3, 5: 6}
        elif self._tangents == 'mid':
            self._values = [-1.0, -0.33, 0.0, 0.33, 1.0]
            self.index_dict = {1: 2, 3: 2}
        elif self._tangents == 'ends':
            self._values = [-1.0, -0.67, 0.0, 0.67, 1.0]
            self.index_dict = {1: 0, 3: 4}
        else:
            raise ValueError('Invalid value for "tangents" : %s' % self._tangents)

    def _create_curve(self):
        self._positions = [i * self._axis_vec for i in self._values]
        self.crv = pm.curve(p=self._positions, name=self._namer.replace(suffix='CRV'))

    def _create_locators(self):
        self._locs = []
        for i, pos in enumerate(self._positions):
            loc = mcrt.simple_node('locator', self._namer.replace(index=i + 1, suffix='LOC'))
            loc.transform.t.set(pos)
            loc.shape.wp >> self.crv.cv[i]
            loc.shape.localScale.set(.1, .1, .1)
            self._locs.append(loc)

    def _create_hierarchy(self):
        # organising the locators
        for index in self.index_dict:
            loc = self._locs[index]
            loc.transform.setParent(self._locs[self.index_dict[index]].transform)
            loc.shape.localPosition.set(loc.transform.t.get())
            loc.transform.t.set(0, 0, 0)
            loc.transform.v.set(False)

    def build(self):
        self._init_values()
        self._create_curve()
        self._create_locators()
        self._create_hierarchy()

        locs = self._locs
        at = self._scale_attr

        # distances
        dist_01 = pm.createNode('distanceBetween', name=self._namer.replace(index=1, suffix='DIST'))
        dist_02 = pm.createNode('distanceBetween', name=self._namer.replace(index=2, suffix='DIST'))
        len_val = len(self._values)

        locs[0].transform.wm >> dist_01.inMatrix1
        locs[(len_val - 1) / 2].transform.wm >> dist_01.inMatrix2
        locs[(len_val - 1) / 2].transform.wm >> dist_02.inMatrix2
        locs[len_val - 1].transform.wm >> dist_02.inMatrix1

        if self._tangents == 'all':
            dist_01.distance >> locs[1].transform.attr(at)
            dist_01.distance >> locs[2].transform.attr(at)
            dist_02.distance >> locs[4].transform.attr(at)
            dist_02.distance >> locs[5].transform.attr(at)
        else:
            dist_01.distance >> locs[1].transform.attr(at)
            dist_02.distance >> locs[3].transform.attr(at)

        if self._tangents != 'ends':
            # orientation
            sub = mcrt.node('sub', name=self._namer.replace(suffix='SUB')).node
            angl = mcrt.node('angleBetween', name=self._namer.replace(suffix='ANGL')).node
            angl.vector1.set(self._axis_vec)
            sub.o3 >> angl.vector2

            if self._tangents == 'mid':
                locs[4].shape.wp >> sub.i3[0]
                locs[0].shape.wp >> sub.i3[1]
                angl.euler >> locs[1].transform.r
                angl.euler >> locs[3].transform.r
            else:
                locs[6].shape.wp >> sub.i3[0]
                locs[1].shape.wp >> sub.i3[1]
                angl.euler >> locs[2].transform.r
                angl.euler >> locs[4].transform.r

        if self._tangents == 'all':
            self.transforms = [loc.transform for loc in self._locs[::3]]
        else:
            self.transforms = [loc.transform for loc in self._locs[::2]]
