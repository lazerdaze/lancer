"""
Functions for creation of "abused" utility Maya nodes

.. module:: util.nodes.utility
   :synopsis: Functions for creation of "abused" utility Maya nodes

.. moduleauthor:: andreasg

"""

# maya modules
import pymel.core as pm

from millrigger.globals.color import CTRL_COLORS
from millrigger.utils import attributes as mattr
from millrigger.utils import name as mname
from millrigger.utils import shape as mshape
from millrigger.utils.data import RigData
from millrigger.utils.nodes.pairblend import PairBlend


def index_to_vector(name='C_name_VECTOR_RMC', invert=False, source=None,
                    target=None):
    ''' Uses a remap colour node to switch between vectors

    :param name: Name of node
    :type name: String

    :param invert: Invert the vectors
    :type invert: Boolean

    :rType: PyNode

    '''
    name = mname.Name(name).replace(suffix="VECTOR_RMC")

    rmc = pm.createNode('remapColor', name=name)
    val_list = [(1, 0.5, 0.5), (0, 0.5, 0.5), (0.5, 1, 0.5),
                (0.5, 0, 0.5), (0.5, 0.5, 1), (0.5, 0.5, 0)]

    if invert is True:
        val_list[0], val_list[1] = val_list[1], val_list[0]
        val_list[2], val_list[3] = val_list[3], val_list[2]
        val_list[4], val_list[5] = val_list[5], val_list[4]

    for i, (r, g, b) in enumerate(val_list):
        rmc.red[i].red_Position.set(i/5.0)
        rmc.red[i].red_FloatValue.set(r)
        rmc.red[i].red_Interp.set(1)
        rmc.green[i].green_Position.set(i/5.0)
        rmc.green[i].green_FloatValue.set(g)
        rmc.green[i].green_Interp.set(1)
        rmc.blue[i].blue_Position.set(i/5.0)
        rmc.blue[i].blue_FloatValue.set(b)
        rmc.blue[i].blue_Interp.set(1)
        rmc.inputMin.set(0)
        rmc.inputMax.set(5)
        rmc.outputMin.set(-1)
        rmc.outputMax.set(1)

    # connect
    _connect_rmc(rmc, source, target)
    return rmc


def trigger_rmc(name='C_name_TRIGGER_RMC', default=0, custom_dict=None,
                start_index=0, source=None, target=None):
    '''
    creates a remapColor-node for usage as a trigger. The input range is
    between 0 and 2, switching on/off 3 output-attributes

    :param name: Name of node
    :type name: String

    :param default: Integer value within the range 0-2
    :type default: Integer

    :param custom_dict: A custom dictionary for different data.
    If None then the default will be:

    'red': [1, 0, 0],
    'green': [0, 1, 0],
    'blue': [0, 0, 1]
    :type custom_dict: Dictionary

    :param start_index: Integer value within the range 0-2
    :type start_index: Integer

    :rType: PyNode
    '''
    name = mname.Name(name).replace(suffix="TRIGGER_RMC")
    rmc = pm.createNode('remapColor', name=name)
    rmc_dict = custom_dict or {'red': [1, 0, 0],
                               'green': [0, 1, 0],
                               'blue': [0, 0, 1]
                               }

    dict_count = len(rmc_dict['red'])

    for col in rmc_dict:
        for i, val in enumerate(rmc_dict[col]):
            pm.setAttr('{0}.{1}[{2}].{1}_Position'.format(name, col, i), i*1.0/(dict_count-1))
            pm.setAttr('{0}.{1}[{2}].{1}_FloatValue'.format(name, col, i), val)
            pm.setAttr('{0}.{1}[{2}].{1}_Interp'.format(name, col, i), 1)

    rmc.inputMin.set(start_index)
    rmc.inputMax.set(start_index + dict_count - 1)
    rmc.renderPassMode.set(2)
    rmc.color.set(default, default, default)

    # connect
    _connect_rmc(rmc, source, target)
    return rmc


def blend_rmc(attr, outR=None, outG=None, outB=None, name='C_name_BLEND_RMC',
              custom_dict=None, source=None, target=None):
    '''
    creates a remapColor-Node and sets the curve-values for linear blend

    :param attr: Attribute that drives the blend
    :type attr: String

    :param outR: Attribute to connect the Red channel too
    :type outR: String

    :param outG: Attribute to connect the Green channel too
    :type outG: PyNode

    :param outB: Attribute to connect the Blue channel too
    :type outB: PyNode

    :param name: Name of node
    :type name: String

    :param custom_dict: a new dictionary to use, the default is:
    'red': [1, 1, 0],
    'green': [0, 1, 1],
    'blue': [0, 0, 1]
    :type custom_dict: Dictionary

    :rType: PyNode

    '''
    name = mname.Name(name).replace(suffix="BLEND_RMC")

    rmc = pm.createNode('remapColor', name=name)
    if custom_dict is not None:
        rmc_dict = custom_dict
    else:
        rmc_dict = {'red': [1, 1, 0],
                    'green': [0, 1, 1],
                    'blue': [0, 0, 1]
                    }

    for col in rmc_dict:
        for i, val in enumerate(rmc_dict[col]):
            pm.setAttr('{0}.{1}[{2}].{1}_Position'.format(name, col, i), 0.5*i)
            pm.setAttr('{0}.{1}[{2}].{1}_FloatValue'.format(name, col, i), val)
    rmc.setAttr('inputMax', 1)
    rmc.setAttr('renderPassMode', 2)
    attr >> rmc.colorR
    attr >> rmc.colorG

    if outR is not None:
        rmc.outColorR >> outR
    if outG is not None:
        rmc.outColorG >> outG
    if outB is not None:
        rmc.outColorB >> outB

    # connect
    _connect_rmc(rmc, source, target)
    return rmc


def footroll_rmc(footroll_in=None,
                 bend_in=None,
                 straight_in=None,
                 toes_out=None,
                 ball_out=None,
                 heel_out=None,
                 name='C_name_FOOTROLL_RMC',
                 ):
    '''
    creates a remapColor-Node and sets the curve-values for linear blend

    :param footroll_in: Driver Attribute for footroll
    :type footroll_in: Pymel Attribute

    :param bend_in: Driver Attribute to define the angle when the footroll bends
    :type bend_in: Pymel Attribute

    :param straight_in: Driver Attribute to define the angle when the footroll is back straight
    :type straight_in: Pymel Attribute

    :param toes_out: Attribute (rotation) to be connected
    :type toes_out: Pymel Attribute

    :param baball_outll: Attribute (rotation) to be connected
    :type ball_out: Pymel Attribute

    :param heel_out: Attribute (rotation) to be connected
    :type heel_out: Pymel Attribute

    :param name: Name of node
    :type name: String

    :rType: PyNode
    '''
    name = mname.Name(name).replace(suffix="FOOTROLL_RMC")

    rmc = pm.createNode('remapColor', name=name)
    rmc.renderPassMode.set(2)  # no contribution to render

    rmc.red[0].red_Position.set(0)
    rmc.red[0].red_FloatValue.set(0)
    rmc.red[0].red_Interp.set(1)
    bend_in >> rmc.red[1].red_Position
    bend_in >> rmc.red[1].red_FloatValue
    rmc.red[1].red_Interp.set(1)
    straight_in >> rmc.red[2].red_Position
    rmc.red[2].red_FloatValue.set(0)
    rmc.red[2].red_Interp.set(1)
    rmc.red[3].red_Position.set(360)
    rmc.red[3].red_FloatValue.set(0)
    rmc.red[3].red_Interp.set(1)

    rmc.green[0].green_Position.set(0)
    rmc.green[0].green_FloatValue.set(0)
    rmc.green[0].green_Interp.set(1)
    bend_in >> rmc.green[1].green_Position
    rmc.green[1].green_FloatValue.set(0)
    rmc.green[1].green_Interp.set(1)
    straight_in >> rmc.green[2].green_Position
    straight_in >> rmc.green[2].green_FloatValue
    rmc.green[2].green_Interp.set(1)
    rmc.green[3].green_Position.set(360)
    rmc.green[3].green_FloatValue.set(360)
    rmc.green[3].green_Interp.set(1)

    rmc.blue[0].blue_Position.set(-360)
    rmc.blue[0].blue_FloatValue.set(-360)
    rmc.blue[0].blue_Interp.set(1)
    rmc.blue[1].blue_Position.set(0)
    rmc.blue[1].blue_FloatValue.set(0)
    rmc.blue[1].blue_Interp.set(1)

    footroll_in >> rmc.colorR
    footroll_in >> rmc.colorG
    footroll_in >> rmc.colorB

    rmc.outColorR >> ball_out
    rmc.outColorG >> toes_out
    rmc.outColorB >> heel_out
    return rmc


def fkik_color(attr, fk_list=None, ik_list=None, colors=None,
               name=None, fk_tag='fk', ik_tag='ik'):
    '''
    creates 2 condition-Nodes and set the values

    :param attr: fkik_blend-attribute
    :type attr: Attribute

    :param fk_list: List of items to colour as FK
    :type fk_list: List

    :param ik_list: List of items to colour as IK
    :type ik_list: List

    :param colors: the main and secondary color-index of the controls
    :type colors: List of color-indices

    :param name: Basename for creation of new nodes
    :type name: String

    :param fk_tag: tag used for fk
    :type fk_tag: String

    :param ik_tag: tag used for ik
    :type ik_tag: String

    :rType: list of PyNodes

    '''
    if name is None:
        namer = mname.Name(attr.node().name())
    else:
        namer = mname.Name(name)
    fk_name = namer.replace(add_to_tags=fk_tag, suffix='COND')
    ik_name = namer.replace(add_to_tags=ik_tag, suffix='COND')

    # check the inputs
    fk_list = _get_shapes(fk_list)
    ik_list = _get_shapes(ik_list)

    if colors is None:
        colors = CTRL_COLORS[namer.side[0]]

    # hook up to the fk condition
    if pm.objExists(fk_name) is False:
        fk = pm.createNode('condition', name=fk_name)
        fk.colorIfTrueR.set(colors[0])
        fk.colorIfFalseR.set(colors[1])
        fk.colorIfTrueG.set(0)
        fk.colorIfFalseG.set(1)

        fk.operation.set(0)
        fk.secondTerm.set(0)
        attr >> fk.firstTerm
    else:
        fk = pm.PyNode(fk_name)

    if pm.objExists(ik_name) is False:
        ik = fk.duplicate(name=ik_name)[0]
        ik.secondTerm.set(1)
        attr >> ik.firstTerm
    else:
        ik = pm.PyNode(ik_name)

    for item in fk_list:
        if item is not None:
            fk.outColorR >> item.overrideColor
            mshape.drive_visibility(shapes=item, driver=ik.outColorG)

    for item in ik_list:
        if item is not None:
            ik.outColorR >> item.overrideColor
            mshape.drive_visibility(shapes=item, driver=fk.outColorG)

    return fk.outColorR, ik.outColorR


def add_length_offset(controls, parent_roots, tags=None):
    """
    Adds a length offset to the given control than drives the length of the given parent roots with it.

    All arguments must eb the same length.
    :param controls: A list of controls to drive the roots
    :param parent_roots: the roots to have their position driven
    :param tags: An optional list of tags to give the attribute
    :return: list of output-plugs to provide the len-values
    """
    i = 0

    headline = True
    plugs = []
    # add an offset to the roots, if needed
    for ctrl, root in zip(controls, parent_roots):
        namer = mname.Name(root.name())

        # get the longest pos value as the length
        attrs = [root.tx, root.ty, root.tz]
        values = [abs(root.tx.get()), abs(root.ty.get()), abs(root.tz.get())]
        length_attr = attrs[values.index(max(values))]
        length = length_attr.get()

        # create the attrs with the args on the control
        args = {"min": length,
                "headline": headline}
        if tags is not None:
            args["tag"] = tags[i]
        attr = mattr.add_length_offset_attr(ctrl, **args)

        # make a plus node to add onto the current if the length is positive
        if length > 0.0:
            add = pm.createNode("addDoubleLinear")
            add.rename(namer.replace(add_to_tags="length", suffix="ADL"))
            add.input1.set(length)
            attr >> add.input2

            # drive the root with it
            add.output >> length_attr
            plugs.append(add.output)

        # otherwise use a minus
        else:
            minus = pm.createNode("plusMinusAverage")
            minus.rename(namer.replace(add_to_tags="length", suffix="SUB"))
            minus.operation.set(2)
            minus.input1D[0].set(length)
            attr >> minus.input1D[1]

            # drive the root with it
            minus.output1D >> length_attr
            plugs.append(minus.output1D)

        i += 1
        headline = False
    return plugs


def create_aimer(inversematrix, position, aim_vec=(0, 0, 1), data=None,
                 name=None, namer=None, add_to_tags=None):
    '''
    Creates or adds to a RigData-class.

    :param inversematrix: inverseMatrix-attribute
    :type inversematrix: Pymel-Attribute

    :param position: translation-attribute in worldspace
    :type position: Pymel-Attribute

    :param aim_vec: Aimvector
    :type aim_vec: Vector

    :param data: If exists then add to this RigData-class
    :type data: RigData-object

    :param namer: NameClass
    :type namer: NameClass-object

    :param name: Basename for creation of new nodes
    :type name: String

    :param add_to_tags: Additional tag for new nodes
    :type add_to_tags: String

    :rType: RigData-Object

    '''
    data = data or RigData()
    if namer is None and name is None:
        raise ValueError("Need valid name or namer-obj for creation of aimer-object!")
    namer = namer or mname.Name(name)

    mpmm = pm.createNode('pointMatrixMult',
                         name=namer.replace(add_to_tags=add_to_tags, suffix='pointMatrixMult'))
    angl = pm.createNode('angleBetween',
                         name=namer.replace(add_to_tags=add_to_tags, suffix='angleBetween'))
    inversematrix >> mpmm.inMatrix
    position >> mpmm.inPoint
    mpmm.o >> angl.v2
    angl.v1.set(aim_vec)
    data.vector = mpmm.o
    data.euler = angl.euler
    return data


def create_orient(node, position, blend_attr=None,
                  aim_vec=(0, 1, 0), parent=None, zero=None,
                  namer=None, data=None):
    '''
    Creates a orient-transforms as offsets for controls

    :param node: Transform to be the child of the new nodes
    :type node: Pymel-Transform

    :param parent: parent for new nodes
    :type parent: Transform-Node

    :param position: translation-attribute in worldspace
    :type position: Pymel-Attribute

    :param aim_vec: Aimvector
    :type aim_vec: Vector

    :param blend_attr: Blendattribute between 0.0 and 1.0
    :type blend_attr: Pymel-Attribute

    :param zero: if it already exists...
    :type zero: Transform-Node

    :rType: RigData-Object

    '''
    data = data or RigData()
    namer = namer or mname.Name(node)
    # create auto orient setup
    data.ori_zero = zero or pm.createNode('transform',
                                          name=namer.replace(suffix='ORI_ZERO'),
                                          parent=parent)
    data.ori = pm.createNode('transform',
                             name=namer.replace(suffix='ORI'),
                             parent=data.ori_zero)
    # create aimer
    data = create_aimer(data.ori.parentInverseMatrix, position, aim_vec, data=data, namer=namer)

    if blend_attr is not None:
        PairBlend(name=namer.replace(suffix='pairBlend'),
                  source1=data.euler.get(),
                  source2=data.euler,
                  target=data.ori,
                  weight=blend_attr,
                  connect="r")
    else:
        data.euler >> data.ori.r
    node.setParent(data.ori)
    return data


def _connect_rmc(rmc, source=None, target=None):
    """
    Connects up a source and target to the
    """
    if source:
        # if we can connect to the full color, do
        try:
            source >> rmc.color

        # otherwise just connect to each input
        except:
            source >> rmc.colorR
            source >> rmc.colorG
            source >> rmc.colorB

    if target:
        # connect to a list of targets
        if isinstance(target, list) or isinstance(target, tuple):
            # if a list of floats, connect the whole colour
            types = list(set([item.type() for item in target]))
            if types[0].endswith("3"):
                for item in target:
                    rmc.outColor >> item

            # otherwise connect to individual r/g/b
            else:
                if len(target) > 3:
                    raise ValueError("target can't be more than 3 items")
                col = ["R", "G", "B"]
                for item in target:
                    attr = pm.PyNode("%s.outColor%s" % (rmc.name(), col.pop(0)))
                    if item is not None:
                        attr >> item

        # connect to a single target
        else:
            rmc.outColor >> target
    return rmc


def _get_shapes(items):
    """
    checks for the shape item
    """
    out = []

    # check for None
    if items is None:
        return []

    # if items isn't a list, make it one
    if not isinstance(items, list):
        items = [items]

    for item in items:
        # look for a rig object
        try:
            out.extend(item.get_shapes())
            continue
        except AttributeError:
            pass

        # check for nested lists
        if isinstance(item, list):
            out.extend(_get_shapes(item))

        # if it's a shape, use it
        elif isinstance(item, pm.nodetypes.Shape):
            out.append(item)

        # get the shape from regular types
        elif item.type() in ["transform", "joint"]:
            out.append(item.getShape())
    return out
