"""
Class to deal with Mill's "Curveinterp"-plugin

.. module:: util.curveinterp
   :synopsis: Class to deal with Mill's "Curveinterp"-plugin

.. moduleauthor:: andreasg

"""
# libraries
from numpy import linspace

# maya modules
import pymel.core as pm
import maya.api.OpenMaya as om

# package modules
from millrigger.globals.rig import STR_TO_VEC_SWITCH, VEC_TO_STR_SWITCH
from millrigger.utils import name as mname
from millrigger.utils.nodes import matrixblend as mblnd
from millrigger.utils.nodes import arrayrampnode as armp
from millrigger.objects.rigobject import RigObject, RigObjectChainByRoot

pm.loadPlugin("matrixNodes", quiet=True)


class CurveInterp(object):
    ''' Class to deal with Mill's "Curveinterp"-plugin

    :param curve: curve or curveInterp
    :type curve: PyNode

    :param name: Name of node.
    :type name: String

    :param matrix_objs: Input Matrices
    :type matrix_objs: List of MMatrix objects

    :param add_to_tags: Value(s) to add the tags of a name
    :type add_to_tags: String or List of strings

    :param num_samples: Amount of samples
    :type num_samples: Integer

    :rType: CurveInterp-object
    '''

    def __init__(self, curve, name=None, matrix_objs=None, add_to_tags=None,
                 suffix=None, num_samples=None, existing_only=False):
        '''
        :param curve: curve
        :type curve: String

        :param name: Name of node.
        :type name: String

        :param matrix_objs: Input Matrices
        :type matrix_objs: List of MMatrix objects

        :param add_to_tags: Value(s) to add the tags of a name
        :type add_to_tags: String or List of strings

        :param num_samples: Amount of samples
        :type num_samples: Integer

        :param existing_only: If "False" node will be created if not existing in the scene
        :type existing_only: Boolean
        '''
        self.cint_type = 'standard'
        self.curve = None
        self.curveshp = None
        self.node = None
        self._get_selection(curve)

        self.matrix_objs = matrix_objs
        self._numsamples = num_samples
        self.sample_objs = None
        self.samples = None
        self.samples_grp = None
        self.samples_srt_grp = None
        self.sample_offsets = None
        self.global_scale = None

        if self.node:
            self.namer = mname.Name(self.node.name())
        else:
            if name:
                self.namer = mname.Name(name, add_to_tags=add_to_tags, suffix=suffix or "curveInterp")
            else:
                self.namer = mname.Name(self.curve.name(), add_to_tags=add_to_tags, suffix=suffix or "curveInterp")

        self.name = self.namer.replace()
        self.build(existing_only)

    def build(self, existing_only):
        ''' Create the curveInterp-Node

        :param name: Name of node.
        :type name: String

        :param num_samples: Amount of samples
        :type num_samples: Integer

        :rType: PyNode
        '''

        # if node is not given, look for exiting or create new
        if self.node is None:
            if not self._node_check(self.name):
                if existing_only:
                    return
                self.node = pm.createNode('curveInterp', name=self.name, parent=self.curve)
                self.curveshp.ws >> self.node.inCurve

            else:
                self.node = pm.PyNode(self.name)

            if self._numsamples:
                self.node.numSamples.set(self._numsamples)  # just the minimum amount

        self._numsamples = self.node.numSamples.get()

        if self.matrix_objs is not None:
            self.connect_matrix_objs(*self.matrix_objs)

    def connect_matrix_objs(self, *args):
        ''' Connects a number of transforms to the curve interp as twist
        controls

        :param *args: A number of transforms that will be connected as linked
        matrices or intermediates in the curve interp
        :type *args: Transforms

        '''
        if not args:
            return
        num_objs = len(args)

        # if we're just given a list, us that for args
        if num_objs == 1 and isinstance(args[0], list):
            args = args[0]

        # always attach the first matrix
        args[0].worldMatrix >> self.node.matrix0

        # what we do now depends on how many more we have
        # last object is always the second matrix
        if num_objs > 1:
            args[-1].worldMatrix >> self.node.matrix1

        # the others are entered as intermediates
        if num_objs > 2:
            self.intermediate = True
            max_val = self.curveshp.maxValue.get()
            u_param_list = linspace(0, max_val, num_objs)
            for u_param, wm in zip(u_param_list[1:-1], args[1:]):
                self.add_intermediate(wm, u_param)

    @property
    def num_samples(self):
        ''' get amount of samples '''
        return self._numsamples

    @num_samples.setter
    def num_samples(self, value):
        ''' set amount of samples along the curve '''
        self._numsamples = value
        self.node.numSamples.set(value)

    @property
    def arclen(self):
        ''' set distribution of samples to percentage or parametric '''
        mode_dict = {0: 'maya', 1: 'romberg'}
        active = self.node.arcLen.get()
        if active:
            return mode_dict[self.node.arcLenMethod.get()]
        else:
            return 'deactivate'

    @arclen.setter
    def arclen(self, method):
        ''' Set the method the arclen is calculated

        :param method: Valid values: None, "Maya", "Romberg" )
        :type method: String
        '''
        if isinstance(method, basestring):
            method = method.lower()
            mode_dict = {'maya': 0, 'romberg': 1}
            val = mode_dict.get(method, -1)
            if val >= 0:
                self.node.arcLenMethod.set(val)
            self.node.arcLen.set(val >= 0)
        else:
            if method is None:
                method = 0
            self.node.arcLen.set(method)

    @property
    def in_samples(self):
        val = self.node.inSamples.get()
        if val:
            return val
        else:
            val = list(linspace(0.0, 1.0, self.num_samples))  # to avoid numpy-array
            return val

    @in_samples.setter
    def in_samples(self, val_list):
        self.samplemode = 1
        self.num_samples = len(val_list)
        self.node.inSamples.set(val_list, typ='doubleArray')

    @property
    def out_samples(self):
        ''' set amount of samples along the curve '''
        out_sample_list = []
        for i in range(len(self.node.inSamples.get())):
            out_sample_list.append(self.node.outSample[i])
        return out_sample_list

    @property
    def intermediate(self):
        self.node.useInter.get()

    @intermediate.setter
    def intermediate(self, value):
        self.node.useInter.set(value)

    @property
    def sample_mode(self):
        return self.node.sampleMode.get()

    @sample_mode.setter
    def sample_mode(self, value):
        self.node.sampleMode.set(value)

    @property
    def aim(self):
        a0 = self.node.aimLocalAxis0.get()
        a1 = self.node.aimLocalAxis1.get()
        a2 = self.node.aimLocalAxis2.get()
        return VEC_TO_STR_SWITCH.get((a0, a1, a2))

    @property
    def sec_axis(self):
        up_dict = {0: 'x', 1: 'y', 2: 'z'}
        return up_dict.get(self.node.secAimLocalAxis.get())

    @property
    def orientation(self):
        return self.node.alignToCurve.get()

    def set_orientation(self, mode, aim='+x', up=None):
        ''' Define the aim and up-vector

        :param mode: Type of aim-behaviour ("off", "flow", "aim_ahead", "aim_ahead_no_flip")
        :type mode: String

        :param aim: Aim Axis
        :type aim: String = +x/+y/+z/-x/-y/-z

        :param up: Up Axis
        :type up: String = x/y/z
        '''
        mode_dict = {'off': 0, 'flow': 1, 'aim_ahead': 2, 'aim_ahead_no_flip': 3}
        aim = STR_TO_VEC_SWITCH[aim.lower()]
        self.node.alignToCurve.set(mode_dict.get(mode, 0))
        self.node.aimLocalAxis0.set(aim[0])
        self.node.aimLocalAxis1.set(aim[1])
        self.node.aimLocalAxis2.set(aim[2])

        up_dict = {'x': 0, 'y': 1, 'z': 2}
        if up:
            up = up[-1].lower()
        up = up_dict.get(up, 3)  # 3 as value if no axis is given
        self.node.secAimLocalAxis.set(up)

    def add_intermediate(self, matrix_obj, u_param):
        """ Adds an intermediate world matrix controller to the curve interp

        :param matrix_obj: PyNode used to provide a matrix
        :type matrix_obj: PyNode

        :param u_param: Position along the U of the curve
        :type u_param: Float
        """
        max_index = self.node.inter.numElements()
        matrix_obj.wm[0] >> self.node.inter[max_index].interMatrix
        self.node.inter[max_index].interParm.set(u_param)
        return self.node.inter[max_index]

    def create_sample_objs(self,
                           node_type='joint',
                           no_tags=False,
                           suffix='SRT',
                           last=False,
                           parent=None,
                           hierarchy=False,
                           create_offsets=False,
                           stretch_attr=None,
                           squash_attr=None,
                           lock_length_attr=None,
                           global_scale_attr=None):
        """ Creates the samples objects driven by the curve interp

        :param node_type: NodeType of the object.
        :type node_type: String

        :param suffix: Override for the object's name suffix
        :type suffix: String

        :param add_to_tags: Add tag to any existing tags
        :type add_to_tags: String

        :param last: Whether the last element needs to be END
        :type last: Boolean

        :param parent: Object to parent under
        :type parent: PyNode

        :param hierarchy: Whether the objects should be created in a hierarchy
        :type hierarchy: Boolean

        :param create_offsets: Whether the objects should be given ofs groups
        :type create_offsets: Boolean

        :param stretch_attr: attribute that drives the stretch of the sample-offsets
        :type stretch_attr: Pymel-Attribute

        :param squash_attr: attribute that drives the amount of squash of the sample-offsets
        :type squash_attr: Pymel-Attribute or float within range (-1.0, 0.0)

        :param lock_length_attr: attribute that blends fixed length and variable-length
        :type lock_length_attr: Pymel-Attribute

        """

        # sort out conflicting options
        create_offsets = (stretch_attr is not None) or create_offsets
        hierarchy = (lock_length_attr is not None) or hierarchy

        if no_tags is True:
            tags = None
        else:
            tags = self.namer.tags

        if parent is None:
            name = self.namer.replace(tags=tags, add_to_suffix='GRP')
            parent = pm.createNode('transform', name=name)

        # create rigobject_chain
        self.sample_objs = RigObjectChainByRoot(rig_object=RigObject,
                                                name=self.name,
                                                node_type=node_type,
                                                matrices=[om.MMatrix()] * self.num_samples,
                                                parent=parent,
                                                tags=None,
                                                last=last,
                                                offset_matrix=None,
                                                startindex=1,
                                                flat=not hierarchy,
                                                suffix=suffix,
                                                create_ofs=False,
                                                create_zero=create_offsets)

        self.samples = self.sample_objs.tops
        self.sample_offsets = self.sample_objs.roots

        if not parent.hasAttr('globalScale'):
            parent.addAttr('globalScale', dv=1.0)
        self.global_scale = parent.globalScale  # attribute to connect the global scale to
        self.samples_grp = parent

        if hierarchy is False:
            # most common usage
            self._create_basic_samples()

        else:
            # create a hierarchy of sample-transforms
            self._create_hierarchy_samples(lock_length_attr=lock_length_attr)

        if stretch_attr and squash_attr:
            self._make_squashy(stretch_attr, squash_attr,
                               lock_length_attr=lock_length_attr)

        if global_scale_attr is not None:
            global_scale_attr >> self.global_scale

        return self.samples

    def create_hierarchy_matrices(self):
        # create sample-matrices for use in a hierarchy

        self.samples = []
        # first element doesn't need inversematrix
        self.samples.append(self.node.outSample[0].outMatrix)

        # create inverseMatrix and multMatrix to provide
        # local matrix for each element in the hierarchy
        for i in range(self.num_samples - 1):
            mmlt = pm.createNode('multMatrix',
                                 name=self.namer.replace(index=i + 1,
                                                         suffix='multMatrix'))
            minv = pm.createNode('inverseMatrix',
                                 name=self.namer.replace(index=i + 1,
                                                         suffix='inverseMatrix'))
            self.node.outSample[i].outMatrix >> minv.inputMatrix
            self.node.outSample[i + 1].outMatrix >> mmlt.matrixIn[0]
            minv.outputMatrix >> mmlt.matrixIn[1]
            self.samples.append(mmlt.matrixSum)
        return self.samples

    # =========================================================================
    # Non-Public Functions ----------------------------------------------------
    # =========================================================================

    def _get_selection(self, curve):
        '''
        sorting out valid selection in transform and shape or curveinterp-node
        '''
        # if a node is given:
        if curve.type() == 'curveInterp':
            self.node = curve
            self.curve = curve.inCurve.inputs()[0]
            self.curveshp = self.curve.getShape(type='nurbsCurve')
            return

        # if curve is given
        if curve.type() == 'nurbsCurve':
            self.curve = curve.getParent()
            self.curveshp = curve
        elif curve.type() in ['transform', 'joint']:
            self.curve = curve
            self.curveshp = curve.getShape(type='nurbsCurve')
        else:
            pm.warning('Not a nurbscurve : %s' % curve.name())
            self.curve = None
            self.curveshp = None

    def _create_basic_samples(self):

        for i, obj in enumerate(self.sample_objs):
            sample = obj.root
            self.node.outSample[i].outTranslate >> sample.t
            self.node.outSample[i].outRotate >> sample.r
            self.global_scale >> sample.sx
            self.global_scale >> sample.sy
            self.global_scale >> sample.sz

    def _create_hierarchy_samples(self, lock_length_attr=None):
        # create a hierarchy of sample-transforms
        for i, obj in enumerate(self.sample_objs):
            sample = obj.root
            mdcp = pm.createNode('decomposeMatrix',
                                 name=obj.namer.replace(suffix='decomposeMatrix'))
            mmlt = pm.createNode('multMatrix',
                                 name=obj.namer.replace(suffix='multMatrix'))
            mcmp = pm.createNode('composeMatrix',
                                 name=obj.namer.replace(suffix='composeMatrix'))

            self.node.outSample[i].outTranslate >> mcmp.inputTranslate
            self.node.outSample[i].outRotate >> mcmp.inputRotate
            self.global_scale >> mcmp.inputScaleX
            self.global_scale >> mcmp.inputScaleY
            self.global_scale >> mcmp.inputScaleZ
            mcmp.outputMatrix >> mmlt.matrixIn[0]

            sample.parentInverseMatrix >> mmlt.matrixIn[1]

            mmlt.matrixSum >> mdcp.inputMatrix
            pos = mdcp.outputTranslate

            # create lock_length-setup if lock_length_attr is given
            if lock_length_attr and i > 0:
                pblnd = pm.createNode('pairBlend',
                                      name=obj.namer.replace(suffix='pairBlend'))
                pos >> pblnd.inTranslate1
                pblnd.inTranslate2.set(pos.get())
                pos = pblnd.outTranslate
                lock_length_attr >> pblnd.weight
            pos >> sample.t
            mdcp.outputRotate >> sample.r
            mdcp.outputScaleX >> sample.sx
            mdcp.outputScaleY >> sample.sy
            mdcp.outputScaleZ >> sample.sz

    def _node_check(self, name):
        if pm.objExists(name):
            return pm.PyNode(name)

    def _make_squashy(self, driver, squash_attr, lock_length_attr=None):
        if self.sample_offsets is not None:
            pm.loadPlugin('arrayRampNode', q=True)

            pow_node = pm.createNode('multiplyDivide',
                                     name=self.namer.replace(suffix='POW',
                                                             add_to_tags='stretch'))
            pow_node.operation.set(3)
            pow_node.i1.set(1, 1, 1)
            if isinstance(lock_length_attr, pm.Attribute):
                rvs = pm.createNode('reverse',
                                    name=self.namer.replace(suffix='RVS',
                                                            add_to_tags='stretch'))
                mdl = pm.createNode('multDoubleLinear',
                                    name=self.namer.replace(suffix='multDoubleLinear',
                                                            add_to_tags='stretch'))
                lock_length_attr >> rvs.ix
                rvs.ox >> mdl.i2
                if isinstance(squash_attr, pm.Attribute):
                    squash_attr >> mdl.i1
                else:
                    mdl.i1.set(squash_attr)
                mdl.output >> pow_node.i2x
            else:
                if isinstance(squash_attr, pm.Attribute):
                    squash_attr >> pow_node.i2x
                else:
                    pow_node.i2x.set(squash_attr)

            driver >> pow_node.i1x
            target_attrs = ['s' + val for val in 'xyz'.translate(None, self.aim)]
            sources = [1, pow_node, 1]
            armp.ArrayRampNode(name=self.namer.replace(suffix='millArrayRampNode',
                                                       add_to_tags='stretch'),
                               sources=sources, targets=self.samples,
                               source_attr='ox', target_attr=target_attrs)


def create_blend_objs(cintA, cintB, node_type='joint',
                      num_samples=7, blend_attr=None, parent=None,
                      name=None, namer=None, suffix='BONE', add_to_tags=None):
    ''' Function to blend the outsamples of 2 curveInterps

    :param cintA: Curveinterp or NurbsCurve
    :type cintA: PyNode

    :param cintB: Curveinterp or NurbsCurve
    :type cintB: PyNode

    :param num_samples: Amount of samples
    :type num_samples: Integer

    :param blend_attr: value between 0.0 and 1.0/attribute to drive the blend
    :type blend_attr: float/PyNode-Attribute

    :param parent: parent for new hierarchy
    :type parent: PyNode

    :param name: Name of node.
    :type name: String

    :param namer: name-class for convenience
    :type namer: NameClass

    :rType: List of Transforms
    '''
    if namer is None:
        namer = mname.Name(name or 'C_generic_TMP',
                           suffix=suffix,
                           add_to_tags=add_to_tags)
    cintA = CurveInterp(cintA, num_samples=num_samples)
    cintB = CurveInterp(cintB, num_samples=num_samples)

    samplesA = cintA.create_hierarchy_matrices()
    samplesB = cintB.create_hierarchy_matrices()

    if parent is None:
        name = namer.replace(add_to_suffix='GRP')
        parent = pm.createNode('transform', name=name)

    if not parent.hasAttr('globalScale'):
        parent.addAttr('globalScale', dv=1.0)
    scaler = parent.globalScale
    nodes = []
    i = 1
    for a, b in zip(samplesA, samplesB):
        ofs = pm.createNode('transform',
                            name=namer.replace(index=i, add_to_suffix='OFS'),
                            parent=parent)
        node = pm.createNode(node_type,
                             name=namer.replace(index=i),
                             parent=ofs)

        mblnd.MatrixBlend(source1=a, source2=b, target=ofs,
                          blend=blend_attr, connect='rt')
        scaler >> node.sx
        scaler >> node.sy
        scaler >> node.sz
        nodes.append(node)
        parent = ofs
        i += 1
    return nodes


def sample_curve(curve, matrix_objs, param_list, aim="+x", up="y", mode="aim_ahead"):
    cint = CurveInterp(curve=curve, matrix_objs=matrix_objs)
    cint.arclen = 1
    cint.in_samples = param_list
    cint.sample_mode = 1
    cint.set_orientation(aim=aim, up=up, mode=mode)
    matrices = [om.MMatrix(out.outMatrix.get()) for out in cint.out_samples]
    pm.delete(cint.node)
    return matrices
