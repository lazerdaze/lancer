"""
Class to deal with Mill's "arrayRampNode"-plugin

.. module:: util.curveinterp
   :synopsis: Class to deal with Mill's "arrayRampNode"-plugin

.. moduleauthor:: andreasg

"""
# libraries
from numpy import linspace

# maya modules
import pymel.core as pm

# package modules

# plugins
pm.loadPlugin("arrayRampNode", qt=True)


class ArrayRampNode(object):
    ''' Class to deal with Mill's "arrayRampNode"-plugin

    :param name: Name of node.
    :type name: String

    :param sources: Objects to drive the input
    :type sources: List of PyNodes

    :param targets: Objects to be driven
    :type targets: List of PyNodes

    :param in_samples: list of values between 0 and 1 where the node samples in_values
    :type in_samples: List of Floats

    :param out_samples: list of values between 0 and 1 where the node samples out_values
    :type out_samples: List of Floats

    :param connect: Define with transforms should be connected. Default="srt"
    :type connect: String

    :rType: ArrayRamNode-class
    '''

    def __init__(self, name=None, add_to_tags=None,
                 sources=None, targets=None,
                 source_attr=None, target_attr=None,
                 in_samples=None, out_samples=None,
                 mode='linear'):

        self.mode_dict = {'none': 0,
                          'linear': 1,
                          'smooth': 2,
                          'spline': 3}

        self.mode = self.mode_dict.get(mode.lower(), 1)

        self.name = name or 'millArrayRampNode'
        self.sources = sources
        self.targets = targets
        self.in_samples = in_samples
        self.out_samples = out_samples
        self.source_attr = source_attr
        self.target_attr = target_attr
        self.node = None

        self.build()

    def build(self):
        # create node
        if self.sources is None and self.targets is None:
            return

        self.node = pm.createNode('millArrayRampNode', name=self.name)

        in_len = len(self.sources)
        out_len = len(self.targets)
        target_attrs = self.target_attr
        if not isinstance(target_attrs, list):
            target_attrs = [self.target_attr]

        in_samples = self.in_samples or linspace(0, 1, len(self.sources))
        out_samples = self.out_samples or linspace(0, 1, len(self.targets))

        if len(in_samples) == in_len and len(out_samples) == out_len:
            for i, in_value in enumerate(self.sources):
                if isinstance(in_value, (int, float)):
                    self.node.curve[i].curve_FloatValue.set(in_value)
                else:
                    in_value.attr(self.source_attr) >> self.node.curve[i].curve_FloatValue

            for i, out_node in enumerate(self.targets):
                for attr in target_attrs:
                    self.node.outSamples[i] >> out_node.attr(attr)

            for i, val in enumerate(in_samples):
                self.node.curve[i].curve_Interp.set(self.mode)
                self.node.curve[i].curve_Position.set(val)

            for i, val in enumerate(out_samples):
                self.node.inSamples[i].set(val)

