'''
Created on 5 Jul 2017

@author: andreasg
'''
import pymel.core as pm
import millrigger.utils.name as mname
import millrigger.utils.nodes.create as mcre
from millrigger.utils.attributes import add_vector_attr, add_generic_blend


# expression used as a generator and trigger for the steps
STEPPER_EXP = """
vector $pos = << {locshape}.worldPosition[0].worldPositionX, {locshape}.worldPosition[0].worldPositionY, {locshape}.worldPosition[0].worldPositionZ >>;
float $stepOffset = {loc}.stepOffset * {loc}.stepIndex;

if (frame <= {startframe}){{
    {loc}.flow = 0;
    {loc}.lastX = $pos.x;
    {loc}.lastY = $pos.y;
    {loc}.lastZ = $pos.z;
    {pblnd}.inTranslateX1 = $pos.x;
    {pblnd}.inTranslateY1 = $pos.y;
    {pblnd}.inTranslateZ1 = $pos.z;
    {pblnd}.weight = 0;

}} else {{

    // read current values
    float $flow = {loc}.flow;
    vector $last = << {loc}.lastX, {loc}.lastY, {loc}.lastZ >>;
    float $old_sin = {loc}.sin;
    float $old_cos = {loc}.cos;

    // get step and increase flow
    float $step = mag($pos - $last);
    $flow += $step;
    float $val = ($flow + $stepOffset) * {loc}.stepMult;
    float $sin = sin($val) ;
    $sin = ($sin > 0) ? $sin : 0;
    float $cos = -cos($val);

    if ($sin == 0 && $old_sin> 0){{
        {pblnd}.inTranslateX1 = $pos.x;
        {pblnd}.inTranslateY1 = $pos.y;
        {pblnd}.inTranslateZ1 = $pos.z;
    }}

    float $blend = 0;
    if ($sin > 0){{
        $blend = $cos / 2 + .5;
    }}
    float $limited = ($step < 1) ? $step : 1;
    {goal}.inPointY = $sin * {loc}.stepHeight * $limited;
    {pblnd}.weight = $blend;

    // new init values
    {loc}.flow = $flow;
    {loc}.lastX = $pos.x;
    {loc}.lastY = $pos.y;
    {loc}.lastZ = $pos.z;
    {loc}.sin = $sin;
    {loc}.cos = $cos;
}}
"""


class Stepper(object):
    """
    Class to create an expression-driven stepper-construct
    It creates an additional locator that has attributes to drive
    and adjust the behaviour of the stepper-expression
    :param node: Transform-node to be driven by expression.
    :type node: PyNode

    :param startframe: defines the frame-number to reset the expression
    :type startframe: int

    :param height: maximum height for a step
    :type height: float

    :param index: index for the leg (useful for as centipede)
    :type index: int

    """

    def __init__(self, node, startframe=0, height=1, index=0):

        self.node = node
        self.namer = mname.Name(node, add_to_tags='stepper')
        self.startframe = startframe
        self.step_height = height
        self.step_index = index
        self.out = self.build()

    def build(self):
        # Create nodes for expression

        parent = self.node.getParent()

        # create step-locator and add needed attributes
        loc = mcre.locator(self.namer.replace(suffix='LOC'),
                           parent=parent)
        loc.shape.v.set(False)

        add_vector_attr(loc.transform, 'last', cb=False)
        loc.transform.addAttr('flow', dv=0)
        loc.transform.addAttr('sin', dv=0)
        loc.transform.addAttr('cos', dv=0)
        loc.transform.addAttr('stepOffset', dv=0, k=True)
        loc.transform.addAttr('stepMult', dv=1.0, k=True)
        loc.transform.addAttr('stepHeight', dv=self.step_height, k=True)
        loc.transform.addAttr('stepIndex', at='long', dv=self.step_index, k=True)
        loc.transform.addAttr('stepAdjust', dv=0, k=True)
        loc.transform.addAttr('startFrame', at='long', dv=self.startframe, k=True)
        blend_attr = add_generic_blend(loc.transform, 'animBlend')

        # get goal-position
        goal_mpmm = pm.createNode('pointMatrixMult',
                                  name=self.namer.replace(add_to_tags='goal',
                                                          suffix='pointMatrixMult'))
        goal_mpmm.inPoint.set(0, 0, 0)
        loc.transform.worldMatrix >> goal_mpmm.inMatrix

        # create pairblend
        pblnd = pm.createNode('pairBlend',
                              name=self.namer.replace(suffix='pairBlend'))
        goal_mpmm.output >> pblnd.inTranslate2

        # get local-position to convert translation to local-space
        local_mpmm = pm.createNode('pointMatrixMult',
                                   name=self.namer.replace(add_to_tags='local',
                                                           suffix='pointMatrixMult'))
        loc.transform.parentInverseMatrix >> local_mpmm.inMatrix
        pblnd.outTranslate >> local_mpmm.inPoint

        # create adjustable offset for the animation in z-axis
        local_adl = pm.createNode('addDoubleLinear',
                                  name=self.namer.replace(add_to_tags='local',
                                                          suffix='addDoubleLinear'))
        # create pairblend for animBlend
        anim_pblnd = pm.createNode('pairBlend',
                                   name=self.namer.replace(add_to_tags='anim',
                                                           suffix='pairBlend'))
        local_mpmm.outputX >> anim_pblnd.inTranslateX2
        local_mpmm.outputY >> anim_pblnd.inTranslateY2
        local_mpmm.outputZ >> local_adl.input1
        local_adl.output >> anim_pblnd.inTranslateZ2
        loc.transform.stepAdjust >> local_adl.input2
        anim_pblnd.outTranslate >> self.node.t
        blend_attr >> anim_pblnd.weight

        # create Expression
        format_expr = STEPPER_EXP.format(loc=loc.transform,
                                         locshape=loc.shape,
                                         goal=goal_mpmm,
                                         pblnd=pblnd,
                                         startframe=self.startframe,
                                         blend=blend_attr)

        pm.expression(s=format_expr, name=self.namer.replace(suffix='EXP'))

        return loc.transform
