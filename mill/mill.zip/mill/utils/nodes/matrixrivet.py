"""
Class to create a simple rivet construct using only native maya-nodes

.. module:: util.matrixrivet
   :synopsis: Class to create a simple nurbs-rivet construct using only native maya-nodes

.. moduleauthor:: andreasg

"""

# maya modules
import pymel.core as pm

# package modules
from millrigger.utils import name as mname
from millrigger.utils import matrix as mmtrx


class MatrixRivet(object):
    ''' Class to deal with Maya's pairblend-node

    :param name: Name of node.
    :type name: String

    :param nurbs: nurbsSurface for riveting the node
    :type nurbs: Transform/NurbsSurface

    :param target: Node to connect as the target
    :type target: Transform

    :param u: Set or connect u-parameter
    :type u: Attribute or Float

    :param v: Set or connect u-parameter
    :type v: Attribute or Float

    :param add_to_tags: Value(s) to add the tags of a name
    :type add_to_tags: String or List of strings

    :rType: PyNode
    '''

    def __init__(self,
                 name="C_matrixRivet",
                 target=None,
                 nurbs=None,
                 add_to_tags=None,
                 u=0.5,
                 v=0.5,
                 align="u",
                 u_axis="+x",
                 v_axis="+y",
                 connect_scale=False
                 ):

        self.nurbs = None
        self.nurbs_shape = None
        self._get_nurbs(nurbs)

        self.namer = mname.Name(target or name,
                                add_to_tags=add_to_tags,
                                suffix='RVT')

        self.poci = pm.createNode("pointOnSurfaceInfo",
                                  name=self.namer.replace(suffix="pointOnSurfaceInfo")
                                  )

        self.mfbf = pm.createNode("fourByFourMatrix",
                                  name=self.namer.replace(suffix="fourByFourMatrix")
                                  )


        self.nurbs_shape.worldSpace >> self.poci.inputSurface

        # connect/set uv values
        self._connect_attr("u", u)
        self._connect_attr("v", v)
        # connect position (default)
        self._connect_plug_with_row()

        plug_dict = {"xy": ["nu", "nv", "nn"],
                     "xz": ["nu", "nn", "nv"],
                     "yz": ["nn", "nu", "nv"],
                     "yx": ["nn", "nu", "nv"],
                     "zx": ["nv", "nn", "nu"],
                     "zy": ["nv", "nn", "nu"]
                     }
        plugs = plug_dict[u_axis[-1] + v_axis[-1]]

        order_checklist = ["uvn", "vnu", "nuv"]
        # create vectorproduct for x-axis
        mvcp = pm.createNode("vectorProduct",
                             name=self.namer.replace(suffix="vectorProduct")
                             )
        mvcp.operation.set(2)  # crossproduct
        mvcp.normalizeOutput.set(True)

        if align == "v":
            # connect vectorproduct
            for axis in "xyz":
                self.poci.attr("nv" + axis) >> mvcp.attr("i1" + axis)
                self.poci.attr("nn" + axis) >> mvcp.attr("i2" + axis)
            # connect x-axis
            self._connect_plug_with_row("o", 0, node=mvcp)
            # connect y-axis
            self._connect_plug_with_row("nv", 1)
            # connect z-axis
            self._connect_plug_with_row("nn", 2)
        else:
            # connect vectorproduct
            for axis in "xyz":
                self.poci.attr("nn" + axis) >> mvcp.attr("i1" + axis)
                self.poci.attr("nu" + axis) >> mvcp.attr("i2" + axis)
            # connect x-axis
            self._connect_plug_with_row("nu", 0)
            # connect y-axis
            self._connect_plug_with_row("o", 1, node=mvcp)
            # connect z-axis
            self._connect_plug_with_row("nn", 2)

        # return the resulting matrix attribute
        self.out_matrix = self.mfbf.output

        if target:
            mmlt = pm.createNode("multMatrix",
                                 name=self.namer.replace(suffix="multMatrix")
                                 )
            mdcp = pm.createNode("decomposeMatrix",
                                 name=self.namer.replace(suffix="decomposeMatrix")
                                 )
            self.mfbf.output >> mmlt.matrixIn[0]
            target.parentInverseMatrix >> mmlt.matrixIn[1]
            mmlt.matrixSum >> mdcp.inputMatrix
            mdcp.outputTranslate >> target.t
            mdcp.outputRotate >> target.r
            if connect_scale:
                mdcp.outputScale >> target.s

            # return the resulting matrix attribute
            self.out_matrix = mmlt.matrixSum

    def _connect_plug_with_row(self, plug="p", row=3, node=None):
        """

        :param plug: "p" for position-vector,
                     "u" for vector along the u-parameter
                     "v" for vector along the v-parameter
                     "n" for vector along the surface-normal
        :param row: index of row of matrix
        :return:
        """

        if node is None:
            node = self.poci

        for i, axis in enumerate("xyz"):
            node.attr(plug + axis) >> self.mfbf.attr("i%d%d" %(row, i))

    def _get_nurbs(self, nurbs):
        if not nurbs:
            raise RuntimeError("Need NurbsSurface for MatrixRivet, got: %s" % nurbs)
        if nurbs.type() == "nurbsSurface":
            self.nurbs_shape = nurbs
            self.nurbs = nurbs.getParent()
        elif nurbs.type() == "transform":
            shape = nurbs.getShape(type="nurbsSurface")
            if not shape:
                raise RuntimeError("Need NurbsSurface for MatrixRivet, got: %s" % shape)
            self.nurbs_shape = shape
            self.nurbs = nurbs

    def _connect_attr(self, at, val):
        if isinstance(val, (int, float)):
            self.poci.attr(at).set(val)
        elif isinstance(val, pm.Attribute):
            val >> self.poci.attr(at)


