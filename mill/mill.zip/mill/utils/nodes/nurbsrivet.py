"""
Class to deal with Mill's "nurbsRivet"-plugin

.. module:: util.nurbsrivet
   :synopsis: Class to deal with Mill's "nurbsRivet"-plugin

.. moduleauthor:: andreasg

"""

import copy

# maya modules
import pymel.core as pm

# package modules
from millrigger.utils import name as mname
from millrigger.utils import shape as mshape

pm.loadPlugin("nurbsRivet", quiet=True)


class NurbsRivet(object):
    ''' Class to deal with Mill's "nurbsRivet"-plugin

    :param nurbs: Nurbs surface
    :type nurbs: PyNode

    :param name: Name of node.
    :type name: String

    :rType: RigData
    '''

    def __init__(self, nurbs, name=None):
        """
        :param nurbs: Nurbs surface or nurbsRivet-node
        :type nurbs: PyNode

        :param name: Name of node.
        :type name: String
        """
        self.node = None
        self.nurbs = mshape.shape_select(nurbs, nodetype='nurbsSurface')
        self.namer = mname.Name(self.nurbs.transform.name())
        self.name = name or self.namer.replace(suffix='nurbsRivet')
        self.max_index = None

        self.node = self.build()

    def build(self):
        ''' Create the curveInterp-Node
        :rType: PyNode
        '''
        if not pm.objExists(self.name):
            node = pm.createNode('nurbsRivet', name=self.name)
            self.nurbs.shape.worldSpace >> node.inSurface
        else:
            node = pm.PyNode(self.name)

        self.max_index = node.inData.getNumElements()
        return node

    def add(self, rivets):
        '''
        :param rivets: Attaches a list of transforms to the rivet node
        :type rivets: List of transformes
        '''
        index_list = []
        # deal with non-list-entry for rivets
        if not isinstance(rivets, list):
            rivets = [rivets]

        for rivet in rivets:
            self.max_index += 1
            self.node.outData[self.max_index].outRotate >> rivet.r
            self.node.outData[self.max_index].outTranslate >> rivet.t
            rivet.parentInverseMatrix[0] >> self.node.inData[self.max_index].inParentInverseMatrix
            rivet.rotateOrder >> self.node.inData[self.max_index].rotateOrder
            index_list.append(copy.copy(self.max_index))
        return index_list

    def set_axis(self, value):
        self.node.inAxis.set(value)

