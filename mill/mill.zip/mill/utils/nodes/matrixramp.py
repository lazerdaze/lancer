"""
.. module:: utils.nodes.matrixramp
   :synopsis: Class for creation of bezier-style matrixsamples

.. moduleauthor:: andreasg
"""

# maya imports
import pymel.core as pm

# package imports
from millrigger.globals import rig as RIG
from millrigger.utils import name as mname
from millrigger.utils import attributes as mattr
from millrigger.utils.maths import linspace_float

# plugins
pm.loadPlugin("millMatrixRamp", qt=True)


class MatrixRamp(object):

    ''' wrapper-class for millMatrixRamp-node

    :param name: Name of node.
    :type name: String

    :param namer: an existing Nameclass can be used
    :type namer: NameClass

    :param suffix: overwrite the suffix
    :type suffix: String

    :param add_to_tags: additional tag for the name
    :type add_to_tags: String

    :param node: if the MatrixRamp-node already exists it can be used
    :type node: PyNode

    :param source_attr: matrix-attribute that drives the insamples
    :type source_attr: String

    :param target_attr: matrix-attribute that drives the outsamples
    :type target_attr: String

    :param start_value: for uniform value-generation
    :type start_value: Float

    :param end_value: for uniform value-generation
    :type end_value: Float

    :param connect: Define which attribute should be connected. Default="srt" or "m" for matrix
    :type connect: String

    :param create_attributes: if True bezier-attributes are created
    :type create_attributes: Boolean

    :param split_tangents: if True tangent-attributes are split into "in" and "out" part
    :type split_tangents: Boolean

    :param mirror_tangents: if True tangent-attribute-names are flipped half-way
    :type mirror_tangents: Boolean

    :param tangent_tags: tag to be added to the tangents (normally "in/out")
    :type tangent_tags: list of 2 Strings

    :param sources: Objects to drive the input
    :type sources: List of PyNodes

    :param targets: Objects to be driven
    :type targets: List of PyNodes

    :param attr_holders: Objects to add the attributes to (might not always be the sources...)
    :type attr_holders: List of PyNodes

    :param insamples: list of sample-values
    :type insamples: List of Floats

    :param outsamples: list of sample-values
    :type outsamples: List of Floats

    :param orientation: if True the outSamples are aligned to the curve
    :type orientation: Boolean

    :param aim_axis: Orientation of the curve
    :type aim_xis:  +x/+y/+z/-x/-y/-z

    :param up_axis: Orientation of the curve
    :type up_xis:  +x/+y/+z/-x/-y/-z

    :param mode: 'linear' or 'smooth'
    :type mode:  String

    :param twist: create and connect twist-Attribute
    :type twist:  Boolean

    :param scale_tangents: scaling of the handle will also affect the tangents
    :type scale_tangents: Boolean

    :param hierarchy: outputsamples are local to their previous samples
    :type hierarchy: Boolean

    :param default_aim: default blend-value for all aim-attributes
    :type default_aim: Float

    :param default_inbetween: default inbetween-state for all attributes
    :type default_inbetween: Boolean

    :param default_tangent: default tangent-state for all attributes
    :type default_aim: Float

    :rType: PyNode

    '''

    def __init__(self,
                 name='C_bezier_MMRP',
                 tangent_tags=['in', 'out'],
                 source_attr='worldMatrix',
                 target_attr='worldMatrix',
                 connect='srt',
                 namer=None,
                 add_to_tags=None,
                 suffix=None,
                 node=None,
                 sources=None,
                 targets=None,
                 attr_holders=None,
                 start_value=0.0,
                 end_value=1.0,
                 create_attributes=True,
                 split_tangents=True,
                 mirror_tangents=False,
                 default_aim=1.0,
                 default_inbetween=False,
                 default_tangent=0.33,
                 **kwargs):

        self._mode_dict = {'linear': 1, 'smooth': 2, 1: 'linear', 2: 'smooth'}
        self._namer = namer or mname.Name(node or name)
        self._name = self._namer.replace(add_to_tags=add_to_tags,
                                         suffix=suffix or 'millMatrixRamp')
        self.tangent_tags = [tag.capitalize() for tag in tangent_tags]

        # user parameters
        self._connect = connect
        self._start_value = start_value
        self._end_value = end_value
        self._create_attributes = create_attributes
        self._source_attr = source_attr
        self._target_attr = target_attr
        self._default_aim = default_aim
        self._default_inbetween = default_inbetween
        self._default_tangent = default_tangent
        self._split_tangents = split_tangents
        self._mirror_tangents = mirror_tangents

        # get the node
        self.node = self._create_node(node)

        # init all parameters by reading the node-attributes
        self._attr_holders = self._check_attr_holders(sources, attr_holders)
        self._sources = self._get_sources()
        self._targets = self._get_targets()
        self._insamples = self._get_insamples()
        self._outsamples = self._get_outsamples()
        self._scale_tangents = self.node.scaleTangentWeights.get()
        self._paramsamples = self.node.parameterisationSamples.get()
        self._orientation = self.node.outRotateMode.get()
        self._cyclic = self.node.cyclic.get()
        self._rotateorder = RIG.ROTATIONORDER_KEYS[self.node.rotateOrder.get()]
        self._aim_axis = RIG.AXIS_KEYS[self.node.aimAxis.get()]
        self._up_axis = RIG.AXIS_KEYS[self.node.upAxis.get()]
        self._mode = self._mode_dict.get(self.node.blendType.get())
        self._hierarchy = self.node.outputsAsHierarchy.get()
        self._twist = self.node.inSample[0].twist.get()

        # set the node-attributes with given values
        if sources:
            kwargs['sources'] = sources
        if targets:
            kwargs['targets'] = targets

        self.set_values(kwargs)
        if create_attributes is False:
            self._set_insample_attributes()


    # =========================================================================
    # Properties --------------------------------------------------------------
    # =========================================================================

    @property
    def aim_axis(self):
        return self._aim_axis

    @aim_axis.setter
    def aim_axis(self, aim_axis):
        self._aim_axis = aim_axis
        index = RIG.AXIS_KEYS.index(aim_axis)
        self.node.aimAxis.set(index)

    @property
    def up_axis(self):
        return self._up_axis

    @up_axis.setter
    def up_axis(self, up_axis):
        self._up_axis = up_axis
        index = RIG.AXIS_KEYS.index(up_axis)
        self.node.upAxis.set(index)

    @property
    def insamples(self):
        return self._insamples

    @insamples.setter
    def insamples(self, samples):
        self._set_insamples(samples)

    @property
    def outsamples(self):
        return self._outsamples

    @outsamples.setter
    def outsamples(self, samples):
        self._set_outsamples(samples)

    @property
    def sources(self):
        return self._sources

    @sources.setter
    def sources(self, sources):
        self._set_insamples(sources)
        if self._create_attributes:
            self._add_attributes_to_sources(sources)  # add and link attributes
        self.connect_sources(sources)
        self._sources = sources

    @property
    def targets(self):
        return self._targets

    @targets.setter
    def targets(self, targets):
        self._set_outsamples(targets)
        self.connect_targets(targets, connect=self._connect)
        self._targets = targets

    @property
    def orientation(self):
        return self._orientation

    @orientation.setter
    def orientation(self, val):
        self.node.outRotateMode.set(val)
        self._orientation = val

    @property
    def param_samples(self):
        return self._paramsamples

    @param_samples.setter
    def param_samples(self, val):
        self.node.parameterisationSamples.set(val)
        self._paramsamples = val

    @property
    def scale_tangents(self):
        return self._scale_tangents

    @scale_tangents.setter
    def scale_tangents(self, val):
        self.node.scaleTangentWeights.set(val)
        self._scale_tangents = val

    @property
    def mode(self):
        return self._orientation

    @mode.setter
    def mode(self, val):
        if isinstance(val, basestring):
            val = self._mode_dict.get(val.lower(), 2)
        self.node.blendType.set(val)
        self._orientation = val

    @property
    def twist(self):
        return self._twist

    @twist.setter
    def twist(self, val):
        self._twist = val
        if val is True:
            self._add_twist(self._attr_holders)
        else:
            self._remove_twist(self._attr_holders)

    @property
    def cyclic(self):
        return self._cyclic

    @cyclic.setter
    def cyclic(self, val):
        self.node.cyclic.set(val)
        self._cyclic = val

    @property
    def hierarchy(self):
        return self._hierarchy

    @hierarchy.setter
    def hierarchy(self, val):
        self.node.outputsAsHierarchy.set(val)
        self._hierarchy = val

    @property
    def rotateorder(self):
        return self._rotateorder

    @rotateorder.setter
    def rotateorder(self, val):
        self.node.rotateOrder.set(RIG.ROTATIONORDER_SWITCH[val])
        self._rotateorder = val

    # =========================================================================
    # Public Functions --------------------------------------------------------
    # =========================================================================

    def set_values(self, kwargs):
        if 'sources' in kwargs:
            self.sources = kwargs.get('sources')

        if 'targets' in kwargs:
            self.targets = kwargs.get('targets')

        if 'insamples' in kwargs:
            self.insamples = kwargs.get('insamples')

        if 'outsamples' in kwargs:
            self.outsamples = kwargs.get('outsamples')

        if 'scale_tangents' in kwargs:
            self.scale_tangents = kwargs.get('scale_tangents')

        if 'param_samples' in kwargs:
            self.param_samples = kwargs.get('param_samples')

        if 'orientation' in kwargs:
            self.orientation = kwargs.get('orientation')

        if 'cyclic' in kwargs:
            self.cyclic = kwargs.get('cyclic')

        if 'rotateorder' in kwargs:
            self.rotateorder = kwargs.get('rotateorder')

        if 'aim_axis' in kwargs:
            self.aim_axis = kwargs.get('aim_axis')

        if 'up_axis' in kwargs:
            up_axis = kwargs.get('up_axis')

            if up_axis[1] == self.aim_axis[1]:
                if self.aim_axis[1] != "z":
                    up_axis = "+z"
                elif self.aim_axis[1] != "y":
                    up_axis = "+y"

            self.up_axis = up_axis

        if 'twist' in kwargs:
            self.twist = kwargs.get('twist')

        if 'mode' in kwargs:
            self.mode = kwargs.get('mode')

        if 'hierarchy' in kwargs:
            self.hierarchy = kwargs.get('hierarchy')

    def connect_sources(self, sources):
        for i, obj in enumerate(sources):
            if isinstance(sources[i], pm.Attribute):
                sources[i] >> self.node.inSample[i].inMatrix
            else:
                sources[i].attr(self._source_attr) >> self.node.inSample[i].inMatrix

    def connect_targets(self, targets, connect='mtrs'):
        if targets:
            # targets is a nurbscurve
            if isinstance(targets, list) and isinstance(targets[0], pm.nodetypes.NurbsCurve):
                cvs = pm.ls(targets[0].cv[:], fl=True)
                self.outsamples = cvs
                for i, cv in enumerate(cvs):
                    self.node.outTranslate[i] >> cv
                return

            if not self.outsamples:
                self.outsamples = targets
            target_attr = connect.lower()
            # establish the provided out-plugs
            out_plug_dict = {'m': 'outMatrix',
                             't': 'outTranslate',
                             'r': 'outRotate',
                             's': 'outScale'}

            # targets is a dictionary
            if isinstance(targets, dict):
                for val in connect:
                    for i, target in enumerate(targets.get(val, [])):
                        self.node.attr(out_plug_dict[val])[i] >> target
                return

            # targets is something else
            plugs = []
            if 'm' in target_attr:
                plugs.append(('outMatrix', self._target_attr))
            if 't' in target_attr:
                plugs.append(('outTranslate', 't'))
            if 'r' in target_attr:
                plugs.append(('outRotate', 'r'))
            if 's' in target_attr:
                plugs.append(('outScale', 's'))

            for i, target in enumerate(targets):
                if isinstance(target, pm.Attribute):
                    self.node.attr(plugs[0][0])[i] >> target
                else:
                    for plug in plugs:
                        self.node.attr(plug[0])[i] >> target.attr(plug[1])

    def hide_aim_attr(self):
        '''
        since the aim should normally be active it might be useful to just
        activate it and forget about it
        '''
        for obj in self._attr_holders:
            obj.aim.setKeyable(False)

    # =========================================================================
    # Non-Public Functions ----------------------------------------------------
    # =========================================================================

    def _create_node(self, node):
        if isinstance(node, pm.PyNode):
            if node.type() == 'millMatrixRamp':
                return node
        elif pm.objExists(self._name):
            return pm.PyNode(self._name)
        else:
            return pm.createNode('millMatrixRamp', name=self._name)

    def _check_samples(self, samples):
        ''' convert samples into a list of samples '''

        # case 1: a dictionary is given
        # >> find largest list in contents of dictionary
        if isinstance(samples, dict):
            max_val = 0
            for key in samples:
                val = len(samples[key])
                if val > max_val:
                    max_val = val
            samples = max_val

        # case 2: a list is given
        # >> if a valid list is given return either the list or continue the tests
        if isinstance(samples, list):
            if not isinstance(samples[0], (int, float)):
                samples = len(samples)
            else:
                return samples

        # case 3: integer given as amount of samples to create
        if isinstance(samples, int):
            if samples == 1:
                return [0.5]

        return linspace_float(self._start_value,
                              self._end_value,
                              num=samples or 2)

    def _set_insamples(self, samples):
        samples = self._check_samples(samples)
        if samples:
            for i, sample in enumerate(samples):
                if sample < 0.0002:
                    sample = 0.0001
                self.node.inSample[i].inValue.set(sample)
            self._insamples = samples
        return samples

    def _set_outsamples(self, samples):
        samples = self._check_samples(samples)
        if samples:
            for i, sample in enumerate(samples):
                self.node.sampleValue[i].set(sample)
            self._outsamples = samples
        return samples

    def _set_insample_attributes(self):
        """ set defaultvalues if no attributes are created """
        for i in range(len(self.insamples)):
            self.node.inSample[i].tangentAimBlend.set(self._default_aim)
            self.node.inSample[i].tangentInWeight.set(self._default_tangent)
            self.node.inSample[i].tangentOutWeight.set(self._default_tangent)
            self.node.inSample[i].inbetween.set(self._default_inbetween)

    def _add_attributes_to_sources(self, sources):
        ''' add attributes if they are not existing '''

        if not sources:
            return

        len_objs = len(sources)
        mirror_max_index = 0
        if self._mirror_tangents is True:
            mirror_max_index = len_objs / 2

        for i, obj in enumerate(self._attr_holders):
            # add  and connect attributes
            if not obj.hasAttr('BEZIER'):
                mattr.add_headline(obj, 'BEZIER')

            if not obj.hasAttr('aim'):
                obj.addAttr('aim', min=0.0, max=1.0, dv=self._default_aim, k=True)
            obj.aim >> self.node.inSample[i].tangentAimBlend
            mirror = i > mirror_max_index
            attr_dict = {False: "tangentInWeight",
                         True: "tangentOutWeight"}
            if self._split_tangents is True and 0 < i < len_objs - 1:
                tangent_tags = self.tangent_tags
                if obj.name()[0] == "C" and self.aim_axis[-1] == "x":
                    tangent_tags = ["Left", "Right"]
                attr_name = 'tangent' + tangent_tags[0]
                if not obj.hasAttr(attr_name):
                    obj.addAttr(attr_name, min=0.00001, max=1.0, dv=self._default_tangent, k=True)
                obj.attr(attr_name) >> self.node.inSample[i].attr(attr_dict[not mirror])
                attr_name = 'tangent' + tangent_tags[1]
                if not obj.hasAttr(attr_name):
                    obj.addAttr(attr_name, min=0.00001, max=1.0, dv=self._default_tangent, k=True)
                obj.attr(attr_name) >> self.node.inSample[i].attr(attr_dict[mirror])
            else:
                if not obj.hasAttr('tangent'):
                    obj.addAttr('tangent', min=0.00001, max=1.0, dv=self._default_tangent, k=True)
                obj.tangent >> self.node.inSample[i].tangentInWeight
                obj.tangent >> self.node.inSample[i].tangentOutWeight

            # take care of slide-attibute
            if not obj.hasAttr('slide'):
                obj.addAttr('slide', at='bool', dv=self._default_inbetween)
            obj.slide.set(channelBox=True)
            obj.slide >> self.node.inSample[i].inbetween

            if self._twist:
                if not obj.hasAttr('twist'):
                    obj.addAttr('twist', dv=0.0, k=True)
                obj.twist >> self.node.inSample[i].twist

        return sources

    def _add_twist(self, sources):
        ''' add attributes if they are not existing '''
        if not sources:
            return
        twist_attrs = []
        for i, obj in enumerate(sources):
            if not obj.hasAttr('twist'):
                obj.addAttr('twist', dv=0.0, k=True)
            obj.twist >> self.node.inSample[i].twist
            twist_attrs.append(obj.twist)
        return twist_attrs

    def _remove_twist(self, sources):
        ''' add attributes if they are not existing '''
        if not sources:
            return

        for i, obj in enumerate(sources):
            if obj.hasAttr('twist'):
                obj.twist // self.node.inSample[i].twist
                pm.deleteAttr(obj, at='twist')

    def _get_sources(self):
        sources = []
        num = self.node.inSample.evaluateNumElements()
        for i in range(num):
            nodes = self.node.inSample[i].inMatrix.inputs(scn=True, p=True)
            if nodes:
                sources.append(nodes[0])
            else:
                sources.append(None)

        return sources

    def _get_targets(self):
        # look for connections
        out_plug_dict = {'m': 'outMatrix',
                         't': 'outTranslate',
                         'r': 'outRotate',
                         's': 'outScale'}

        target_dict = {}
        for tag in out_plug_dict:
            targets = self.node.attr(out_plug_dict[tag]).outputs(p=True)
            if targets:
                target_dict[tag] = targets
        return target_dict

    def _check_attr_holders(self, sources, attr_holders):
        # no attr-holder is given
        if attr_holders is None:
            attr_holders = sources

        if sources:
            if len(attr_holders) == len(sources):
                # filter out attributes and just keep nodes
                return [attr_holder.node() for attr_holder in attr_holders]
            else:
                raise RuntimeError("Amount of Attributeholders doesn't match with sources!")

    def _get_insamples(self):
        num = self.node.inSample.evaluateNumElements()
        if num:
            insamples = [self.node.inSample[i].inValue.get() for i in range(num)]
            return insamples

    def _get_outsamples(self):
        num = self.node.sampleValue.evaluateNumElements()
        if num:
            outsamples = [self.node.sampleValue[i].get() for i in range(num)]
            return outsamples
