'''
Created on 15 Aug 2016

@author: andreasg
'''
import pymel.core as pm
import millrigger.utils.name as mname
from millrigger.utils.attributes import add_millspring_attr

# plugins
pm.loadPlugin("millSpring", qt=True)


def create_millspring(transforms, create_offsets=True,
                      start_frame=1, **kwargs):

    is_attribute = isinstance(start_frame, pm.Attribute)
    springs = []

    for node in transforms:
        par = node.getParent()
#         child = node.getChildren(type='transform')[0]
        child = node
        namer = mname.Name(node.name())

        spring = pm.createNode("millSpring", n=namer.replace(suffix='MSPG'))
        if create_offsets is True:
            rot = pm.createNode('transform', parent=par, name=namer.replace(suffix='ROT'))
            node.setParent(rot)
        else:
            rot = child

        par.worldMatrix >> spring.inMatrix
        child.matrix >> spring.baseOffset
        pm.Attribute('time1.outTime') >> spring.time
        spring.outRotate >> rot.rotate
        if is_attribute:
            start_frame >> spring.startFrame
        else:
            spring.startFrame.set(start_frame)

        for item in kwargs:
            spring.attr(item).set(kwargs[item])

        # expose attributes:
        spring.enable.showInChannelBox(True)
        spring.enableCache.showInChannelBox(True)
        spring.axis.showInChannelBox(True)
        spring.maxAngle.showInChannelBox(True)
        springs.append(spring)
    return springs


def create_millspring_by_rigobjectchain(chain,
                                        create_offsets=True,
                                        create_attributes=True,
                                        start_frame=1,
                                        start_index=1,
                                        shared_index=1,
                                        **kwargs):
    """
    Creates millspring dynamics along an entire rig object chain.

    :param chain: The RigObjectChain class
    :param create_offsets: If true, adds a rotation transform into the hierarchy
    :param create_attributes: If true, creates the attributes to drive the spring on the rig objects
    :param start_frame: The frame to start the spring on
    :param start_index: The first index to start adding dynamics too
    :param shared_index: Which object in the chain that should hold the shared attributes
    :param kwargs:
    :return:
    """
    is_attribute = isinstance(start_frame, pm.Attribute)
    shared = chain[shared_index].obj
    springs = []

    for rig_obj, rig_child in zip(chain[start_index:], chain[start_index + 1:]):
        namer = rig_obj.namer

        spring = pm.createNode("millSpring", n=namer.replace(suffix='MSPG'))

        if rig_obj.ofs:
            obj = rig_obj.ofs
        else:
            create_offsets = True
            obj = rig_obj.obj

        if create_offsets is True:

            rot = pm.createNode('transform',
                                parent=rig_obj.zero,
                                name=namer.replace(suffix='ROT'))
            obj.setParent(rot)
        else:
            rot = rig_obj.ofs

        rig_obj.zero.worldMatrix >> spring.inMatrix
        rig_child.zero.matrix >> spring.baseOffset
        pm.Attribute('time1.outTime') >> spring.time
        spring.outRotate >> rot.rotate
        if is_attribute:
            start_frame >> spring.startFrame
        else:
            spring.startFrame.set(start_frame)

        if create_attributes:
            # create attributes
            attr_data = add_millspring_attr(rig_obj.obj, shared=shared, start_frame=False)

            # connect local attributes
            for item in attr_data.local:
                item[1] >> spring.attr(item[0])
                item[1].set(kwargs[item[0]])

            # connect chain attributes
            for item in attr_data.chain:
                item[1] >> spring.attr(item[0])
                item[1].set(kwargs[item[0]])

            attr_data.enable >> spring.enable
            attr_data.enable.set(kwargs.get('enable', True))
            attr_data.cache >> spring.enableCache
            attr_data.cache.set(kwargs.get('cache', False))
        else:
            for item in kwargs:
                spring.attr(item).set(kwargs[item])
        springs.append(spring)
    return springs
