"""
.. module:: utils.wrapper
   :synopsis: Package of classes used to ease the work with plughins/nodes

.. moduleauthor:: andreasg

"""
