"""
Class to deal with Mill's "Curveinterp"-plugin

.. module:: util.curveinterp
   :synopsis: Class to deal with Mill's "Curveinterp"-plugin

.. moduleauthor:: andreasg

"""
# libraries

# maya modules
import pymel.core as pm

# package modules
from millrigger.globals.rig import STR_TO_VEC_SWITCH, VEC_TO_STR_SWITCH
from millrigger.utils import name as mname
from millrigger.utils.maths import linspace_float

ATTR_LIST = ['outTranslate', 'outTranslateX', 'outTranslateY', 'outTranslateZ',
             'outRotate', 'outRotateX', 'outRotateY', 'outRotateZ',
             'outMatrix']


class BezierCurveInterp(object):
    ''' Class to deal with Mill's "Curveinterp"-plugin

    :param curve: curve or curveInterp
    :type curve: PyNode

    :param name: Name of node.
    :type name: String

    :param matrix_objs: Input Matrices
    :type matrix_objs: List of MMatrix objects

    :param add_to_tags: Value(s) to add the tags of a name
    :type add_to_tags: String or List of strings

    :param num_samples: Amount of samples
    :type num_samples: Integer

    :rType: CurveInterp-object
    '''

    def __init__(self, curve, name=None, add_to_tags=None,
                 suffix=None, insamples=None, existing_only=False):
        '''
        :param curve: curve
        :type curve: String

        :param name: Name of node.
        :type name: String

        :param matrix_objs: Input Matrices
        :type matrix_objs: List of MMatrix objects

        :param add_to_tags: Value(s) to add the tags of a name
        :type add_to_tags: String or List of strings

        :param num_samples: Amount of samples
        :type num_samples: Integer
        '''

        self._insamples = None
        self._numsamples = None

        self.cint_type = 'bezier'
        self.curve = curve
        if name:
            self.namer = mname.Name(name, add_to_tags=add_to_tags, index=None, suffix=suffix or "curveInterp")
        else:
            self.namer = mname.Name(self.curve.name(), index=None, add_to_tags=add_to_tags, suffix=suffix or "curveInterp")
        self.name = self.namer.create_name()

        self.curveshapes = curve.getShapes(type='nurbsCurve', noIntermediate=True)
        self.num_segments = len(self.curveshapes)
        self.nodes = self.create_nodes(existing_only)
        if self.nodes:
            self._insamples = self._init_insamples(insamples)
            self._numsamples = len(self._insamples)
            self.samples = None
            self.samples_grp = None
            self.samples_srt_grp = None
            self.sample_offsets = None
            self.global_scale = None

    def create_nodes(self, existing_only):
        ''' Create the curveInterp-Node

        :param name: Name of node.
        :type name: String

        :param num_samples: Amount of samples
        :type num_samples: Integer

        :rType: PyNode
        '''
        nodes = self._node_check()

        if nodes:
            return nodes

        # only create new curveInterps if existing_only is False
        if existing_only:
            return None

        for i, crv in enumerate(self.curveshapes):
            cint = pm.createNode('curveInterp', name=self.namer.replace(index=i + 1), parent=self.curve)
            cint.numSamples.set(2)
            cint.arcLen.set(1)
            cint.alignToCurve.set(0)
            cint.sampleMode.set(1)
            crv.ws >> cint.inCurve
            crv_orig = crv.listHistory(type='nurbsCurve', breadthFirst=True)  # get ShapeOrig if needed
            locs = crv_orig[-1].inputs(type='locator')
            locs[0].worldMatrix >> cint.matrix0
            locs[-1].worldMatrix >> cint.matrix1
            nodes.append(cint)
        return nodes

    @property
    def out_samples(self):
        ''' set amount of samples along the curve '''
        out_sample_list = []
        for node in self.nodes:
            insamples = [val for val in node.inSamples.get() if 0.0 <= val <= 1.0]
            for i in range(len(insamples)):
                out_sample_list.append(node.outSample[i])
        return out_sample_list

    @property
    def arclen(self):
        ''' set distribution of samples to percentage or parametric '''
        mode_dict = {0: 'maya', 1: 'romberg'}
        active = self.nodes[0].arcLen.get()
        if active:
            return mode_dict[self.nodes[0].arcLenMethod.get()]
        else:
            return 'deactivate'

    @arclen.setter
    def arclen(self, method):
        ''' Set the method the arclen is calculated

        :param method: Valid values: None, "Maya", "Romberg" )
        :type method: String
        '''
        if isinstance(method, basestring):
            method = method.lower()
            mode_dict = {'maya': 0, 'romberg': 1}
            val = mode_dict.get(method, -1)
            if val >= 0:
                for node in self.nodes:
                    node.arcLenMethod.set(val)
            for node in self.nodes:
                node.arcLen.set(val >= 0)
        else:
            if method is None:
                method = 0
            for node in self.nodes:
                node.arcLen.set(method)

    @property
    def in_samples(self):
        if self.nodes:
            return self._get_insamples()

    @in_samples.setter
    def in_samples(self, insamples):
        self.samplemode = 1
        self._numsamples = len(insamples)

        # get lists of samplevalues per node
        insamples_list = self._distribute_insamples(insamples)
        if not self._resample_test(insamples_list):

            # disconnect out-samples and store connection-data
            connections = self._disconnect_samples()

            # redistribute samples to each node
            for node, values in zip(self.nodes, insamples_list):
                node.numSamples.set(len(values))
                node.inSamples.set(values, typ='doubleArray')

            # reconnect connections if they existed before
            if connections:
                self._reconnect_samples(connections, insamples_list)
            self._insamples = insamples

        else:
            # redistribute samples to each node
            for node, values in zip(self.nodes, insamples_list):
                node.numSamples.set(len(values))
                node.inSamples.set(values, typ='doubleArray')

    @property
    def num_samples(self):
        ''' get amount of samples '''
        return self._numsamples

    @property
    def sample_mode(self):
        return self.nodes[0].sampleMode.get()

    @sample_mode.setter
    def sample_mode(self, value):
        for node in self.nodes:
            node.sampleMode.set(value)

    @property
    def aim(self):
        a0 = self.nodes[0].aimLocalAxis0.get()
        a1 = self.nodes[0].aimLocalAxis1.get()
        a2 = self.nodes[0].aimLocalAxis2.get()
        return VEC_TO_STR_SWITCH.get((a0, a1, a2))

    @property
    def sec_axis(self):
        up_dict = {0: 'x', 1: 'y', 2: 'z'}
        return up_dict.get(self.nodes[0].secAimLocalAxis.get())

    @property
    def orientation(self):
        return self.nodes[0].alignToCurve.get()

    def set_orientation(self, mode, aim='+x', up=None):
        ''' Define the aim and up-vector

        :param mode: Type of aim-behaviour ("off", "flow", "aim_ahead", "aim_ahead_no_flip")
        :type mode: String

        :param aim: Aim Axis
        :type aim: String = +x/+y/+z/-x/-y/-z

        :param up: Up Axis
        :type up: String = x/y/z
        '''
        mode_dict = {'off': 0, 'flow': 1, 'aim_ahead': 2, 'aim_ahead_no_flip': 3}
        aim = STR_TO_VEC_SWITCH[aim.lower()]
        for node in self.nodes:
            node.alignToCurve.set(mode_dict.get(mode, 0))
            node.aimLocalAxis0.set(aim[0])
            node.aimLocalAxis1.set(aim[1])
            node.aimLocalAxis2.set(aim[2])

        up_dict = {'x': 0, 'y': 1, 'z': 2}
        if up:
            up = up[-1].lower()
        up = up_dict.get(up, 3)  # 3 as value if no axis is given
        for node in self.nodes:
            node.secAimLocalAxis.set(up)

    def create_sample_objs(self, node_type='transform', no_tags=False, suffix='SRT', last=False,
                           parent=None, hierarchy=False, create_offsets=False):
        """ Creates the samples objects driven by the curve interp

        :param node_type: NodeType of the object.
        :type node_type: String

        :param suffix: Override for the object's name suffix
        :type suffix: String

        :param last: Whether the last element needs to be END
        :type last: Boolean

        :param parent: Object to parent under
        :type parent: PyNode

        :param hierarchy: Whether the objects should be created in a hierarchy
        :type hierarchy: Boolean

        :param create_offsets: Whether the objects should be given ofs groups
        :type create_offsets: Boolean
        """
        self.samples = []
        self.sample_offsets = []

        if no_tags is True:
            tags = None
        else:
            tags = self.namer.tags

        if parent is None:
            name = self.namer.replace(tags=tags, add_to_suffix='GRP')
            parent = pm.createNode('transform', name=name)

        if not parent.hasAttr('globalScale'):
            parent.addAttr('globalScale', dv=1.0)
        self.global_scale = parent.globalScale  # attribute to connect the global scale to
        self.samples_grp = parent

        if hierarchy is False:
            # most common usage
            self._create_basic_samples(node_type=node_type,
                                       tags=tags,
                                       suffix=suffix,
                                       parent=parent,
                                       create_offsets=create_offsets)

        else:
            # create a hierarchy of sample-transforms
            if create_offsets is False:
                self._create_hierarchy_samples(node_type=node_type,
                                               tags=tags,
                                               suffix=suffix,
                                               parent=parent
                                               )
            else:
                self._create_hierarchy_samples_with_offsets(node_type=node_type,
                                                            tags=tags,
                                                            suffix=suffix,
                                                            parent=parent
                                                            )
        if last is True:
            name = self.namer.replace(tags=tags, index='END', suffix=suffix)
            self.samples[-1].rename(name)

        return self.samples

    def create_hierarchy_matrices(self):
        # create sample-matrices for use in a hierarchy

        self.samples = []
        # first element doesn't need inversematrix
        out_samples = self.out_samples
        self.samples.append(out_samples[0].outMatrix)

        # create inverseMatrix and multMatrix to provide
        # local matrix for each element in the hierarchy
        for i in range(self.num_samples - 1):
            mmlt = pm.createNode('multMatrix',
                                 name=self.namer.replace(index=i + 1,
                                                         suffix='multMatrix'))
            minv = pm.createNode('inverseMatrix',
                                 name=self.namer.replace(index=i + 1,
                                                         suffix='inverseMatrix'))
            out_samples[i].outMatrix >> minv.inputMatrix
            out_samples[i + 1].outMatrix >> mmlt.matrixIn[0]
            minv.outputMatrix >> mmlt.matrixIn[1]
            self.samples.append(mmlt.matrixSum)
        return self.samples

    # =========================================================================
    # Non-Public Functions ----------------------------------------------------
    # =========================================================================

    def _create_basic_samples(self, node_type='joint', tags=None,
                              add_to_tags='bone', suffix='SRT',
                              parent=None, create_offsets=False):

        for i, out_sample in range(self.out_samples):
            name = self.namer.replace(index=i + 1, tags=tags,
                                      add_to_tags=add_to_tags, suffix=suffix)
            sample = pm.createNode(node_type,
                                   name=name,
                                   parent=parent)
            driven = sample
            self.samples.append(sample)

            if create_offsets is True:
                ofs = pm.createNode(node_type,
                                    name=name + '_OFS',
                                    parent=parent)
                sample.setParent(ofs)
                driven = ofs
                self.sample_offsets.append(ofs)

            out_sample.outTranslate >> driven.t
            out_sample.outRotate >> driven.r
            self.global_scale >> driven.sx
            self.global_scale >> driven.sy
            self.global_scale >> driven.sz

    def _create_hierarchy_samples(self, node_type='joint', tags=None, suffix='BONE',
                                  parent=None):
        # create a hierarchy of sample-transforms
        for i, out_sample in range(self.out_samples):
            name = self.namer.replace(index=i + 1, tags=tags, suffix=suffix)
            sample = pm.createNode(node_type, name=name, parent=parent)

            name = self.namer.replace(index=i + 1, tags=tags, suffix='decomposeMatrix')
            mdcp = pm.createNode('decomposeMatrix', name=name)

            name = self.namer.replace(index=i + 1, tags=tags, suffix='multMatrix')
            mmlt = pm.createNode('multMatrix', name=name)

            # simple composeMatrix instead of transforms with offsets
            name = self.namer.replace(index=i + 1, tags=tags, suffix='MCMP')
            mcmp = pm.createNode('composeMatrix', name=name)
            out_sample.outTranslate >> mcmp.inputTranslate
            out_sample.outRotate >> mcmp.inputRotate
            self.global_scale >> mcmp.inputScaleX
            self.global_scale >> mcmp.inputScaleY
            self.global_scale >> mcmp.inputScaleZ
            mcmp.outputMatrix >> mmlt.matrixIn[0]

            sample.parentInverseMatrix >> mmlt.matrixIn[1]

            mmlt.matrixSum >> mdcp.inputMatrix
            mdcp.outputTranslate >> sample.t
            mdcp.outputRotate >> sample.r
            mdcp.outputScaleX >> sample.sx
            mdcp.outputScaleY >> sample.sy
            mdcp.outputScaleZ >> sample.sz
            parent = sample
            self.samples.append(sample)

    def _create_hierarchy_samples_with_offsets(self, node_type='joint',
                                               tags=None,
                                               suffix='BONE', parent=None):
        '''
        create samples in a hierarchy driven by samples with offsets
        for getting a single hierarchy that can be easily pairblended
        '''
        name = self.namer.replace(index=None, tags=tags, suffix='CINT_SRTS')
        self.samples_srt_grp = pm.createNode('transform', name=name)
        self.samples_srt_grp.v.set(False)

        for i, out_sample in range(self.out_samples):
            # create sample-hierarchy
            name = self.namer.replace(index=i + 1, tags=tags, suffix=suffix)
            sample = pm.createNode(node_type, name=name, parent=parent)

            name = self.namer.replace(index=i + 1, tags=tags, suffix='decomposeMatrix')
            mdcp = pm.createNode('decomposeMatrix', name=name)

            name = self.namer.replace(index=i + 1, tags=tags, suffix='multMatrix')
            mmlt = pm.createNode('multMatrix', name=name)

            # create worldspace transforms with offsets are created as
            # helper construct to work with the arrayramp
            name = self.namer.replace(index=i + 1, tags=tags, suffix='CINT_OFS')
            cint_ofs = pm.createNode('transform',
                                     parent=self.samples_srt_grp,
                                     name=name
                                     )

            name = self.namer.replace(index=i + 1, tags=tags, suffix='CINT_SRT')
            cint_srt = pm.createNode('transform', parent=cint_ofs, name=name)

            out_sample.outTranslate >> cint_ofs.t
            out_sample.outRotate >> cint_ofs.r
            cint_srt.worldMatrix >> mmlt.matrixIn[0]

            sample.parentInverseMatrix >> mmlt.matrixIn[1]

            mmlt.matrixSum >> mdcp.inputMatrix
            mdcp.outputTranslate >> sample.t
            mdcp.outputRotate >> sample.r
            mdcp.outputScale >> sample.s
            self.global_scale >> cint_ofs.sx
            self.global_scale >> cint_ofs.sy
            self.global_scale >> cint_ofs.sz
            parent = sample
            self.samples.append(sample)
            self.sample_offsets.append(cint_srt)

    def _disconnect_samples(self):
        '''
        returns a list of plugs that get disconnected with the idea of
        reconnecting them later again
        '''
        connection_list = []
        valid = False
        for node in self.nodes:
            for i in range(node.numSamples.get()):
                attr_dict = {}
                for at in ATTR_LIST:
                    found = node.outSample[i].attr(at).outputs(c=True, p=True)
                    if found:
                        found[0][0] // found[0][1]
                        attr_dict[found[0][0].attrName()] = found[0][1]
                        valid = True
                connection_list.append(attr_dict)
        if valid:
            return connection_list

    def _reconnect_samples(self, connection_list, in_samples_list):
        '''
        reconnect again
        '''
        i = 0
        for node in self.nodes:
            valid_samples = [val for val in node.inSamples.get() if 0.0 <= val <= 1.0]
            for j in range(len(valid_samples)):
                attr_dict = connection_list[i]
                for at in attr_dict:
                    node.outSample[j].attr(at) >> attr_dict[at]
                i += 1
        return connection_list

    def _node_check(self):
        cint_nodes = []
        for i in range(self.num_segments):
            cint_name = self.namer.replace(index=i + 1)
            if pm.objExists(cint_name):
                cint_nodes.append(pm.PyNode(cint_name))
        return cint_nodes

    def _init_insamples(self, insamples):
        '''
        returns either a list of given insamples
        or an equally distributed list of values if given a single integer value
        or a filtered list of existing insamples
        '''
        insample_list = []
        if isinstance(insamples, list):
            insample_list = insamples
        elif isinstance(insamples, int):
            insample_list = linspace_float(0, 1, num=insamples)
        else:
            insample_list = self._get_insamples()

        # redistribute samples to each node
        for node, values in zip(self.nodes, self._distribute_insamples(insample_list)):
            node.numSamples.set(len(values))
            node.inSamples.set(values, typ='doubleArray')

        return insample_list

    def _get_insamples(self):
        '''
        returns a filtered list of existing insamples
        '''
        insamples = []
        for i, node in enumerate(self.nodes):
            segment_insamples = node.inSamples.get()
            if segment_insamples:
                values = [(val + i) / self.num_segments for val in segment_insamples
                          if 0.0 <= val <= 1.0]
            else:
                values = [0.0, 1.0]
            insamples.extend(values)
        return insamples

    def _distribute_insamples(self, insamples):
        '''
        return a list of percentage-values for each segment of a chain of curves
        '''
        insamples_list = []
        values = [val * self.num_segments for val in insamples]
        # split values in groups

        for i in range(self.num_segments):
            if i == 0:
                segment_values = [val - i for val in values if i <= val <= i + 1]
            else:
                segment_values = [val - i for val in values if i < val <= i + 1]
            if len(segment_values) == 1:
                segment_values.append(1.1)
            elif len(segment_values) == 0:
                segment_values = [1.1, 1.2]
            insamples_list.append(segment_values)
        return insamples_list

    def _resample_test(self, insample_list):
        ref_values = [len(val) for val in self._distribute_insamples(self._insamples)]
        test_values = [len(val) for val in insample_list]
        return ref_values == test_values
