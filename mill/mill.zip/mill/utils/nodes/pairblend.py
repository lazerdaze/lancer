"""
Class to deal with Maya's pairblend-node

.. module:: util.pairblend
   :synopsis: Class to deal with Maya's pairblend-node

.. moduleauthor:: andreasg

"""

# maya modules
import pymel.core as pm
import maya.api.OpenMaya as om

# package modules
from millrigger.utils import name as mname

CONNECT_DICT = {'t': 'Translate',
                'r': 'Rotate'}


class PairBlend(object):
    ''' Class to deal with Maya's pairblend-node

    :param name: Name of node.
    :type name: String

    :param source1: Node to connect as the first input
    :type source1: Transform

    :param source2: Node to connect as the second input
    :type source2: Transform

    :param target: Node to connect as the target
    :type target: Transform

    :param weight: Set or connect the weight value
    :type weight: Attribute or Float

    :param connect: Which transforms to connect s=scale, r=rotate, t=translate
    :type connect: string

    :param add_to_tags: Value(s) to add the tags of a name
    :type add_to_tags: String or List of strings

    :rType: PyNode
    '''
    def __init__(self, name=None, source1=None, source2=None, target=None,
                 weight=None, connect="rt", add_to_tags=None):

        # if we have no sources, don't do anything
        if source1 is None and source2 is None:
            pm.warning("No sources provided for pairblend!")
            return

        # if we have no sources, don't do anything
        connect = [attr for attr in connect if attr in "rt"]
        if connect == []:
            pm.warning("Pairblend can only blend rotation and translation!")
            return

        # make the name and pair node
        if name is None:
            if target is not None:
                namer = mname.Name(target.name())
                tags = namer.suffix.lower()
                name = namer.replace(add_to_tags=tags, suffix='PBLND')
            else:
                name = 'pairBlend'
        self.node = pm.createNode('pairBlend', name=name)

        # connect everything up
        if source1:
            self.connect_source1(source1, connect)

        if source2:
            self.connect_source2(source2, connect)

        if target:
            self.connect_target(target, connect)

        if weight is not None:
            self.connect_weight(weight)
        return

    @property
    def name(self):
        return self.node.name()

    def connect_source1(self, transform, connect):
        """ connects the given transforms rot and pos to be the first input

        :param transform: Node to connect as the first input
        :type transform: Transform

        :param connect: Which transforms to connect s=scale, r=rotate, t=translate
        :type connect: string
        """
        for attr in connect:
            self._filter_in(transform, attr, 1)
        return

    def connect_source2(self, transform, connect):
        """ connects the given transforms rot and pos to be the second input

        :param transform: Node to connect as the second input
        :type transform: Transform

        :param connect: Which transforms to connect s=scale, r=rotate, t=translate
        :type connect: string
        """
        for attr in connect:
            self._filter_in(transform, attr, 2)
        return

    def connect_target(self, transform, connect, rename=False):
        """ connects the given transforms rot and pos to be the target

        :param transform: Node to connect as the target
        :type transform: Transform

        :param connect: Which transforms to connect s=scale, r=rotate, t=translate
        :type connect: string

        :param rename: Whether to rename the pairblend to match the target
        :type rename: Boolean
        """
        for attr in connect:
            self._filter_out(transform, attr)
        return

    def connect_weight(self, weight):
        ''' Either links the weight to an attribute or sets it to a value

        :param weight: Attribute to drive the weight or a value to set it
        :type weight: Attribute or Float

        '''
        if isinstance(weight, pm.Attribute):
            weight >> self.node.weight
        elif isinstance(weight, float) or isinstance(weight, int):
            self.node.weight.set(weight)
        return

    def set_euler(self, euler):
        ''' Sets whether the node uses euler or Quaternian interpolation

        :param euler: True: euler, False: Quaternian
        :type euler: Boolean

        '''
        self.node.rotInterpolation.set(not euler)

    def connect_rotation(self, rot1=None, rot2=None, out=None):
        ''' connect rotation attributes of pairblend node

        :param rot1: First in rotation attribute
        :type rot1: Attribute

        :param rot2: Second in rotation attribute
        :type rot2: Attribute

        :param out: Rotation attribute to drive
        :type out: Attribute
        '''
        self._connect_rt('r', rot1, rot2, out)

    def connect_translation(self, pos1=None, pos2=None, out=None):
        ''' connect translation attributes of pairblend node

        :param pos1: First in translation attribute
        :type pos1: Attribute

        :param pos2: Second in translation attribute
        :type pos2: Attribute

        :param out: Translation attribute to drive
        :type out: Attribute
        '''
        self._connect_rt('t', pos1, pos2, out)

    def _connect_rt(self, attr, source1, source2, out):
        ''' connect attributes of pairblend-node '''
        if source1:
            self._filter_in(source1, attr, 1)
        if source2:
            self._filter_in(source2, attr, 2)
        if out:
            self._filter_outt(out, attr)

    def _filter_in(self, val, attr, index):
        ''' connects or set value depending on the input '''
        at = self.node.attr('in%s%d' % (CONNECT_DICT[attr], index))
        if isinstance(val, (list, tuple, pm.datatypes.Vector, om.MVector)):
            at.set(val)
        elif isinstance(val, pm.Attribute):
            val >> at
        elif isinstance(val, pm.PyNode):
            val.attr(attr) >> at
        else:
            raise AttributeError('Invalid input : %s' % val)

    def _filter_out(self, val, attr):
        ''' connects or set value depending on the input '''
        at = self.node.attr('out%s' % CONNECT_DICT[attr])
        if isinstance(val, pm.Attribute):
            at >> val
        elif isinstance(val, pm.PyNode):
            at >> val.attr(attr)
        else:
            raise AttributeError('Invalid input : %s' % val)
