"""
Wrapper functions for constraint-creation

.. module:: util.nodes.constraints
   :synopsis: Wrapper functions for constraint-creation

.. moduleauthor:: andreasg

"""

# maya modules
import maya.api.OpenMaya as om
import pymel.core as pm

# package modules
from millrigger.globals import rig as RIG
from millrigger.globals.name import TYPE_SUFFIX_DICT
from millrigger.utils import name as mname
from millrigger.utils import matrix as mmtrx

pm.loadPlugin("millSimpleConstraint", qt=True)

# ========================================================================
# Public -----------------------------------------------------------------
# ========================================================================


def create_constraint(constraint_type, source, target, snap=False, **kwargs):
    ''' Wrapper for creating any kind of constraint

    :param constraint_type: Valid Values are 'simple', 'point', 'orient', 'aim', 'parent'
    :type constraint_type: String

    :param source: Transform to constrain to
    :type source: Transform

    :param target: Transform to be constrained
    :type target: Transform

    :param snap: Snap transforms to source
    :type snap: Boolean

    :param name: Name of node.
    :type name: String

    :rType: PyNode

    '''
    constraint_dict = {'point': pm.pointConstraint,
                       'orient': pm.orientConstraint,
                       'parent': pm.parentConstraint
                       }
    if constraint_type == 'simple':
        con = create_simple_constraint(source, target, snap=snap, **kwargs)
    elif constraint_type == 'aim':
        con = create_aim_constraint(source, target, snap=snap, **kwargs)
    else:
        con = constraint_dict[constraint_type](source, target, mo=not snap, **kwargs)

    con = con.rename(_auto_name(target, con.type()))
    return con


def create_simple_constraint(source, target, snap=True, match=None, connect='srt'):
    """ Creates a simple constraint

    :param source: Object to constrain to
    :type source: PyNode

    :param target: Object to be constrained
    :type target: PyNode

    :param match: Object to match the transform of
    :type match: PyNode

    :param snap: Snap transforms to source
    :type snap: Boolean

    :param connect: Define with attributes should be connected. Default="srt"
    :type connect: String

    :rType: millSimpleConstraint
    """
    namer = mname.Name(target.name())

    # check the source, taking it's worldMatrix if it's an object
    if isinstance(source, pm.Attribute):
        if not source.type() == "matrix":
            raise ValueError("'%s' must be a matrix or PyNode type" % str(source))
    else:
        source = source.worldMatrix[0]

    # record inputs in case we need an offset
    if match is None:
        match = source
    else:
        # check the match, taking it's worldMatrix if it's an object
        if isinstance(match, pm.Attribute):
            if not match.type() == "matrix":
                raise ValueError("'%s' must be a matrix or PyNode type" % str(source))
        else:
            match = match.worldMatrix[0]

    # create and hook-up the constraint
    scon = pm.createNode("millSimpleConstraint",
                         name=namer.replace(add_to_tags=namer.suffix.lower(),
                                            suffix='millSimpleConstraint')
                         )

    # add an offset, if needed
    if not snap:
        ro = target.ro.get()
        s_matrix = mmtrx.to_tmatrix(match.get()).asMatrixInverse()
        t_matrix = mmtrx.get_matrix(target, ws=True)

        offset = om.MTransformationMatrix(t_matrix * s_matrix)
        pos = offset.translation(om.MSpace.kWorld)
        rot = offset.rotation()
        rot.reorderIt(ro)
        rot = (om.MAngle(rot.x).asDegrees(),
               om.MAngle(rot.y).asDegrees(),
               om.MAngle(rot.z).asDegrees())
        scl = offset.scale(om.MSpace.kWorld)

        scon.translateOffset.set(pos)
        scon.rotateOffset.set(rot)
        scon.scaleOffset.set(scl)

    # connect everything
    source >> scon.inMatrix
    target.parentInverseMatrix >> scon.parentInverseMatrix
    target.rotateOrder >> scon.rotateOrder
    target.rotatePivot >> scon.rotatePivot
    if 't' in connect:
        scon.outTranslate >> target.translate
    if 'r' in connect:
        scon.outRotate >> target.rotate
    if 's' in connect:
        scon.outScale >> target.scale

    return scon


def create_point_constraint(source, target, snap=True):
    """ Creates an orient constraint

    :param source: Object to constrain to
    :type source: PyNode

    :param target: Object to be constrained
    :type target: PyNode

    :param snap: Snap transforms to source
    :type snap: Boolean

    :rType: PointConstraint
    """
    return create_constraint("point", source, target, snap=snap, name=None)


def create_orient_constraint(source, target, snap=True):
    """ Creates an orient constraint

    :param source: Object to constrain to
    :type source: PyNode

    :param target: Object to be constrained
    :type target: PyNode

    :param snap: Snap transforms to source
    :type snap: Boolean

    :rType: OrientConstraint
    """
    return create_constraint("orient", source, target, snap=snap)


def create_aim_constraint(source, target, snap=True, aim="+z", up="+y",
                          pole_obj=None, axis_obj=None, axis_aim="+y"):
    """ Creates an aim constraint

    :param source: Object to constrain to
    :type source: PyNode

    :param target: Object to be constrained
    :type target: PyNode

    :param snap: Snap transforms to source
    :type snap: Boolean

    :param aim: Aim Axis
    :type aim: String = +x/+y/+z/-x/-y/-z

    :param up: Up Axis
    :type up: String = +x/+y/+z/-x/-y/-z

    :param pole_obj: If not None, use the Object Up.
    :type pole_obj: PyNode

    :param axis_obj: If not None, use the Object Rotation Up.
    :type axis_obj: PyNode

    :param axis_aim: Aim Vector for the
    :type axis_aim: String = +x/+y/+z/-x/-y/-z

    :rType: AimConstraint
    """
    if pole_obj is not None and axis_obj is not None:
        raise ValueError("Cannot have both pole_obj and axis_obj")
    con = pm.aimConstraint(source, target, mo=not snap)
    con.aimVector.set(RIG.STR_TO_VEC_SWITCH[aim])
    con.upVector.set(RIG.STR_TO_VEC_SWITCH[up])

    if pole_obj is not None:
        con.worldUpType.set(1)
        con.setWorldUpObject(pole_obj.name())

    if axis_obj is not None:
        con.worldUpType.set(2)
        _pymel_check(axis_obj).worldMatrix >> con.worldUpMatrix
        con.worldUpVector.set(RIG.STR_TO_VEC_SWITCH[axis_aim])
    return con


def make_delay_data(source, target, constraint_type="simple", snap=True, **kwargs):
    """
    Creates the data needed for the delayed constraint workflow
    """
    data = {"source": source,
            "target": target,
            "constraint_type": constraint_type,
            "snap": snap
            }
    data.update(kwargs)
    return data


def update_simple_constraint_offset(scon, match):
    # update simpleconstraint-offset-matrix
    ro = scon.rotateOrder.get()
    parent_matrix = mmtrx.to_mmatrix(scon.parentInverseMatrix.get()).inverse()
    if isinstance(match, pm.Attribute):
        match_matrix = mmtrx.to_mmatrix(match.get())
    elif isinstance(match, pm.PyNode):
        match_matrix = mmtrx.to_mmatrix(mmtrx.get_matrix(match, ws=True))
    elif isinstance(match, om.MMatrix):
        match_matrix = mmtrx.to_mmatrix(match)
    else:
        pm.warning('Cannot update constraint with given match!')
        return
    offset = om.MTransformationMatrix(parent_matrix * match_matrix.inverse())
    pos = offset.translation(om.MSpace.kWorld)
    rot = offset.rotation()
    rot.reorderIt(ro)
    rot = (om.MAngle(rot.x).asDegrees(),
           om.MAngle(rot.y).asDegrees(),
           om.MAngle(rot.z).asDegrees())
    scl = offset.scale(om.MSpace.kWorld)

    scon.translateOffset.set(pos)
    scon.rotateOffset.set(rot)
    scon.scaleOffset.set(scl)


# ======================================================================================================================
# Non-Public -----------------------------------------------------------------------------------------------------------
# ======================================================================================================================


def _auto_name(obj, objtype, name=None):
    if name:
        return name
    else:
        type_suffix = TYPE_SUFFIX_DICT.get(objtype)
        if type_suffix is not None:
            name = mname.Name(obj.name()).replace(suffix=type_suffix)
            return name
        else:
            raise ValueError('No suffix exists for : %s' % objtype)

def _pymel_check(name):
    """
    Checks to see whether the given name is a string and, if so, wraps it in a pymel object

    :param name: If this is a string, returns a PyNode
    :return:
    """
    if isinstance(name, basestring):
        name = pm.PyNode(name)
    return name
