"""
.. module:: utils.create
   :synopsis: Creation of nodes. Returns will always be Rigdata-classes

.. moduleauthor:: andreasg
"""

import pymel.core as pm
import maya.api.OpenMaya as om

from millrigger.globals.node import TRANSFORMS, UTILITY_DICT
from millrigger.globals.name import TYPE_SUFFIX_DICT
from millrigger.globals.rig import ROTORDER_SWITCH, STR_TO_VEC_SWITCH
from millrigger.utils.data import RigData
from millrigger.utils import matrix as mmtrx
from millrigger.utils import name as mname
from millrigger.utils import transform as mtrans
from millrigger.utils import attributes as mattr
from millrigger.utils.nodes import pairblend as mpblnd
from millrigger.utils.nodes import curveinterp as mcint
from millrigger.utils.nodes import constraints as mcon
from millrigger.utils.nodes import transforms as mntrs
from millrigger.utils.nodes import matrixblend as mmblend
from millrigger.utils.nodes import matrixramp as mmramp
from millrigger.objects import srtgroup as msrt

pm.loadPlugin("curveInterp", quiet=True)


def simple_node(node_type, name=None, skip=False):
    '''Create a nodes and return a Rigdata-class

    :param node_type: NodeType of the object.
    :type node_type: String

    :param name: Name of node.
    :type name: String

    :param skip: if node already exists in scene, skip creation and return existing node
    :type skip: Boolean

    :rType: RigData
    '''
    node_data = RigData()

    if name:
        if pm.objExists(name):
            if skip:
                node_data.node = pm.PyNode(name)
            else:
                node_data.node = pm.createNode(node_type, name=name)
        else:
            if node_type == 'locator':
                node_data.node = pm.createNode('locator').getParent().rename(name)
                node_data.shape = node_data.node.getShape(type='locator')
            else:
                node_data.node = pm.createNode(node_type, name=name)
    else:
        node_data.node = pm.createNode(node_type)

    if node_type in TRANSFORMS:
        node_data.transform = node_data.node

    elif pm.objectType(node_data.node, isa='shape'):
        node_data.shape = node_data.node
        node_data.transform = node_data.node.getParent()

    return node_data


def node(node_type, name=None, parent=None, matrix=None, operation=None, skip=False):
    '''Create a nodes with options and return a Rigdata-class

    :param node_type: type of node, also "dummyCube"
    :type node_type: String

    :param name: Name of node
    :type name: String

    :param parent: Use as a parent for the new node.
    :type parent: Transform

    :param matrix: Matrix to match, if given a PyNode will attempt to take transform
    :type matrix: Transform or Matrix

    :param operation: If node has operation as parameter...
    :type operation: Integer

    :param skip: if node already exists in scene, skip creation and return existing node
    :type skip: Boolean

    :rType: RigData
    '''
    if node_type in UTILITY_DICT:
        node_type, operation = UTILITY_DICT[node_type]

    if node_type == 'dummyCube':
        node_data = RigData
        node_data.transform = mntrs.dummycube(name=name, skip=skip)
    else:
        node_data = simple_node(node_type, name=name, skip=skip)

    if node_type in TRANSFORMS:
        if parent:
            pm.parent(node_data.transform, parent)
            node_data.parent = parent

        if matrix is not None:
            if isinstance(matrix, pm.PyNode):
                mtrans.match(matrix,
                             node_data.transform
                             )
            elif isinstance(matrix, om.MMatrix):
                mmtrx.set_matrix(node_data.transform,
                                 matrix,
                                 ws=True
                                 )
            elif isinstance(matrix, om.MTransformationMatrix):
                mmtrx.set_matrix(node_data.transform,
                                 mmtrx.to_mmatrix(matrix),
                                 ws=True
                                 )

    elif operation and node_data.node.hasAttribute('operation'):
        node_data.node.operation.set(operation)

    return node_data


def locator(name='C_generic_LOC', matrix=None, parent=None, world_space=True,
            localscale=1.0, hide_shape=False):
    ''' creates a locator and places it with given matrix under given parent

    :param name: Name of new locator
    :type name: String

    :param parent: parent of the new locator or None
    :type parent: PyNode

    :param matrix: Transformation-matrix
    :type matrix: MMatrix

    :param world_space: Whether to use the world space (True) or the local space (False)
    :type world_space: Boolean

    :rType: Locator

    '''

    node = pm.createNode('transform', name=name, parent=parent)
    shp = pm.createNode('locator', name=name + 'Shape', parent=node)
    shp.localScale.set(localscale, localscale, localscale)

    if matrix:
        mmtrx.set_matrix(node, matrix, world_space)

    node_data = RigData()
    node_data.transform = node
    node_data.shape = shp

    if hide_shape:
        shp.visibility.set(False)
    return node_data


def locators_driving_curve(curve, name, parent=None):
    """
    Adds a locator at every CV position on the given curve and hooks up their
    world position.

    :param curve: Curve to drive
    :type curve: PyNode

    :param name: Name of new locator
    :type name: String

    :param parent: parent of the new locator or None
    :type parent: PyNode
    """
    namer = mname.Name(name)
    out = []
    for i, cv in enumerate(curve.getCVs()):
        matrix = mmtrx.get_position_matrix(x=cv.x, y=cv.y, z=cv.z)
        name = namer.replace(index=i + 1,
                             suffix="LOC"
                             )
        loc = locator(name=name,
                      matrix=matrix,
                      parent=parent
                      )
        loc.transform.r.set(0, 0, 0)
        loc.shape.worldPosition >> curve.getShape().controlPoints[i]
        out.append(loc.transform)
    return out


def add_locator_shape(parent, suffix="LOC"):
    ''' Adds a locator-shape to the given node

    :param parent: Object to parent under
    :type parent: PyNode
    :param suffix: suffix for locatorshape
    :type suffix: String

    :rType: LocatorShape
    '''
    existing = pm.listRelatives(parent, type="locator")
    if existing:
        return existing[0]

    namer = mname.Name(parent.name())
    name = namer.replace(add_to_suffix=suffix) + 'Shape'
    loc = pm.createNode('locator', name=name, parent=parent, skipSelect=True)
    loc.visibility.set(0)
    return loc


def simple_constraint(source, target, snap=True, match=None, connect='srt'):
    ''' Wrapper for "millSimpleConstraint"

    :param source: Object to drive the input
    :type source: PyNode

    :param target: Object to be driven
    :type target: PyNode

    :param snap: Snap transforms to source
    :type snap: Boolean

    :param name: Name of node.
    :type name: String

    :rType: RigdataCls

    '''
    return mcon.create_simple_constraint(source, target, snap=snap,
                                         match=match, connect=connect)


def pairblend(source1=None, source2=None, target=None, weight=None, euler=True,
              connect='rt', name=""):
    ''' Wrapper for pairBlend

    :param source1: First transform
    :type source1: Transform

    :param source2: Second transform
    :type source2: Transform

    :param target: Driven node
    :type target: Transform

    :param weight: Float value or Pymel-Attribute to set/drive the weight0-attribute
    :type weight: Float/Attribute

    :param euler: True: Euler, False: Quaternian
    :type euler: Boolean

    :param connect: Define with transforms should be connected. Default="rt"
    :type connect: String

    :rType: PyNode
    '''
    if name:
        namer = mname.Name(target.name(), suffix=TYPE_SUFFIX_DICT['pairBlend'])
    elif target:
        namer = mname.Name(target.name(), suffix=TYPE_SUFFIX_DICT['pairBlend'])
    else:
        raise ValueError("If no target given, 'pairblend' needs a name")

    pb = mpblnd.PairBlend(name=namer.create_name(),
                          source1=source1,
                          source2=source2,
                          target=target,
                          weight=weight,
                          connect=connect,
                          add_to_tags=None
                          )
    pb.set_euler(euler)
    return pb.node


def curveinterp(curve, matrix_objs, add_to_tags=None, mode='off', num_samples=5, arclen=0,
                aim='+x', up=None, return_CurveInterp_object=False):
    ''' Wrapper for the curveInterp class

    :param curve: Curve used by the curveInterp-plugin
    :type curve: NurbsCurve

    :param matrix_objs: Matrices used as TwistIn, TwistOut and Inbetweens
    :type matrix_objs: List of Transforms

    :param add_to_tags: addition to tags in Name
    :type add_to_tags: String

    :param mode: Type of aim-behaviour ("off", "flow", "aim_ahead", "aim_ahead_no_flip")
    :type mode: String

    :param num_samples: Amount of samples
    :type num_samples: Integer

    :param arclen: None, 'Maya' or 'Romberg'
    :type arclen: String

    :param aim: '+x', '+y', '+z', '-x', '-y', '-z',
    :type aim: String

    :param up: 'x', 'y', 'z'
    :type up: String

    :param return_CurveInterp_object: If true, the function returns a millrigger.utils.nodes.curvinterp.CurveInterp object
    :type return_CurveInterp_object: Boolean

    :rType: PyNode or millrigger.utils.nodes.curvinterp.CurveInterp
    '''
    cint = mcint.CurveInterp(curve,
                             matrix_objs=matrix_objs,
                             add_to_tags=add_to_tags)
    cint.num_samples = num_samples
    cint.arclen = arclen
    cint.set_orientation(mode, aim, up)

    if return_CurveInterp_object:
        return cint
    else:
        return cint._cint


def matrixramp_from_objects(objects,
                            name="C_generic_TMP",
                            num_samples=5,
                            aim='+x',
                            up="+z",
                            samples_parent=None,
                            sample_type="transform",
                            samples_suffix="SRT",
                            curve_orientation=True,
                            attr_objects=None,
                            slide=True,
                            linear_ends=False):
    """
    Creates a matrix ramp that drives the given number of transforms in the sample
    :param objects: The Controls to drive the ramp
    :param name: a name for the matrix ramp and the samples
    :param num_samples: the number of samples to create
    :param aim: the aim axis
    :param up: the up axis
    :param samples_parent: the parent for the samples
    :param sample_type: default transform
    :param samples_suffix: The suffix given to all the samples
    :param curve_orientation: If True, the samples will match the orientation of the internal ramp curve
    :return:
    """
    if not attr_objects:
        attr_objects = objects

    namer = mname.Name(name)
    targets = []
    for i in range(num_samples):
        target = pm.createNode(sample_type,
                               n=namer.replace(index=i + 1,
                                               suffix=samples_suffix),
                               p=samples_parent
                               )
        targets.append(target)

    ramp = mmramp.MatrixRamp(sources=objects,
                             targets=targets,
                             aim_axis=aim,
                             up_axis=up,
                             orientation=curve_orientation,
                             namer=namer,
                             attr_holders=attr_objects,
                             )

    # set the slide on the middle controls
    if slide and num_samples > 2:
        for obj in attr_objects[1:-1]:
            obj.slide.set(True)

    # if the ends want to be linear, set the tangents to zero and mmove the samples in a bit
    if linear_ends:
        attr_objects[0].tangent.set(1e-05)
        attr_objects[-1].tangent.set(1e-05)
        samples = ramp.outsamples
        samples[0] = 0.01
        samples[-1] = 0.99
        ramp.outsamples = samples

    data = RigData()
    data.samples = targets
    data.node_class = ramp
    data.node = ramp.node
    return data


def curveinterp_from_objects(objects,
                             name='C_generic_CRV',
                             add_to_tags=None,
                             degree=2,
                             mode="aim_ahead",
                             num_samples=5,
                             arclen=0,
                             aim='+x',
                             up="z",
                             make_samples=True,
                             samples_parent=None,
                             sample_type="transform",
                             samples_suffix="SRT",
                             hierarchy=True,
                             lock_length_attr=None,
                             squash_attr=None,
                             stretch_attr=None,
                             global_scale_attr=None):
    """Creates a curve from the given transforms and adds a curve interp

    :param objects: List of transforms for each CV of the resulting curve
    :type objects: List of PyNode

    :param name: Name of node.
    :type name: String

    :param add_to_tags: addition to tags in Name (good for bone-srts).
    :type add_to_tags: String

    :param degree: Degree of the curve
    :type degree: Integer

    :param mode: Type of aim-behaviour ("off", "flow", "aim_ahead", "aim_ahead_no_flip")
    :type mode: String

    :param num_samples: Amount of samples
    :type num_samples: Integer

    :param arclen: None, 'Maya' or 'Romberg'
    :type arclen: String

    :param aim: '+x', '+y', '+z', '-x', '-y', '-z',
    :type aim: String

    :param up: 'x', 'y', 'z'
    :type up: String

    :param make_samples: Whether to add bone objects to the curve interp
    :type make_samples: Boolean

    :param sample_type: What kind of object, if any to drive with the interp
    :type sample_type: String

    :param samples_parent: Where to place the bones, if being made
    :param samples_parent: PyNode

    :param samples_suffix: The suffix to give the sample objects
    :param samples_suffix: String

    :param hierarchy: Whether the bones are in the hierarchy
    :type hierarchy: Bool

    :param stretch_attr: attribute that drives the stretch of the sample-offsets
    :type stretch_attr: Pymel-Attribute

    :param squash_attr: attribute that drives the amount of squash of the sample-offsets
    :type squash_attr: Pymel-Attribute or float within range (-1.0, 0.0)

    :param lock_length_attr: blend-attribute to fix the length of sample-objects
    :type lock_length_attr: PyMel-Attribute

    :rType: millrigger.utils.nodes.curvinterp.CurveInterp
    """
    curve = curve_from_objects(objects, name, degree)
    cint = curveinterp(curve=curve,
                       matrix_objs=objects,
                       add_to_tags=add_to_tags,
                       mode=mode,
                       num_samples=num_samples,
                       arclen=arclen,
                       aim=aim,
                       up=up[-1],
                       return_CurveInterp_object=True
                       )
    if make_samples:
        cint.create_sample_objs(node_type=sample_type,
                                suffix=samples_suffix,
                                last=False,
                                parent=samples_parent,
                                hierarchy=hierarchy,
                                create_offsets=False,
                                stretch_attr=stretch_attr,
                                squash_attr=squash_attr,
                                lock_length_attr=lock_length_attr,
                                global_scale_attr=global_scale_attr
                                )
    return cint


def ik_handle(start_jnt, end_jnt, parent=None, name=None):
    ''' Wrapper for ikHandle-creation

    :param start_jnt: Start joint of chain
    :type start_jnt: Joint

    :param end_jnt: End joint of chain
    :type end_jnt: Joint

    :param parent: Parent of new ikHandle
    :type parent: PyNode


    :rType: RigData
    '''
    if name is None:
        namer = mname.Name(start_jnt.name(), index=None)
    else:
        namer = mname.Name(name)
    ikh, eff = pm.ikHandle(sj=start_jnt,
                           ee=end_jnt,
                           sol="ikRPsolver"
                           )
    ikh.visibility.set(False)
    ikh.rename(namer.replace(suffix='ikHandle'))
    eff.rename(namer.replace(suffix='ikEffector'))
    if parent:
        ikh.setParent(parent)

    return ikh, eff


def spline_ik_handle(start_jnt, end_jnt, curve, parent=None, matrix_objs=None,
                     up_vector=(0, 1, 0), up_vector_end=None,
                     aim_axis='+x', up_axis='+y'):
    ''' Wrapper for splineIkHandle-creation

    :param start_jnt: Start joint of chain
    :type start_jnt: Joint

    :param end_jnt: End joint of chain
    :type end_jnt: Joint

    :param curve: nurbsCurve
    :type curve: PyNode

    :param parent: Parent of new ikHandle
    :type parent: PyNode

    :param matrix_objs: transforms providing worldMatrices used for advanced twist
    :type matrix_objs: PyNode or List of PyNodes

    :rType: RigData
    '''
    namer = mname.Name(start_jnt.name(), index=None)
    ikh, eff = pm.ikHandle(sj=start_jnt,
                           ee=end_jnt,
                           curve=curve,
                           ccv=False,
                           sol="ikSplineSolver"
                           )
    ikh.visibility.set(False)
    ikh.rename(namer.replace(suffix='ikHandle'))
    eff.rename(namer.replace(suffix='ikEffector'))
    if parent:
        ikh.setParent(parent)

    aim_axis_dict = {'+x': 0, '-x': 1, '+y': 2, '-y': 3, '+z': 4, '-z': 5}
    up_axis_dict = {'+x': 6, '-x': 7, '+y': 0, '-y': 1, '+z': 3, '-z': 4}

    # set start and end-twistmatrix
    if matrix_objs:
        ikh.dTwistControlEnable.set(True)
        up_vector_end = up_vector_end or up_vector
        ikh.dWorldUpVector.set(up_vector)
        ikh.dWorldUpVectorEnd.set(up_vector_end)
        ikh.dForwardAxis.set(aim_axis_dict[aim_axis])
        ikh.dWorldUpAxis.set(up_axis_dict[up_axis])
        if isinstance(matrix_objs, list):
            ikh.dWorldUpType.set(4)
            matrix_objs[0].worldMatrix >> ikh.dWorldUpMatrix
            matrix_objs[-1].worldMatrix >> ikh.dWorldUpMatrixEnd
        else:
            ikh.dWorldUpType.set(3)
            matrix_objs.worldMatrix >> ikh.dWorldUpMatrix
    return ikh, eff


def curve_from_objects(objs, name='C_generic_CRV', degree=2):
    ''' Create a Nurbs curve and link it with the locators

    :param objs: List of objects for each CV of the resulting curve
    :type objs: List of PyNode

    :param name: Name of node.
    :type name: String

    :param degree: Degree of the curve
    :type degree: Integer

    :rType: RigData
    '''
    pos = [(0, 0, 0)]
    if len(objs) == 2:
        degree = 1
    curve = pm.curve(name=name,
                     d=degree,
                     p=pos * len(objs)
                     )
    for i, obj in enumerate(objs):
        loc = add_locator_shape(obj)
        loc.wp >> curve.cv[i]

    namer = mname.Name(name)
    curve.rename(namer.replace(suffix="CRV"))
    return curve


def curve_from_matrices(matrices, name='C_generic_CRV', degree=2):
    ''' Create a Nurbs curve using the positions of the matrices

    :param matrices: List of objects for each CV of the resulting curve
    :type matrices: List of MMatrix

    :param name: Name of node.
    :type name: String

    :param degree: Degree of the curve
    :type degree: Integer

    :rType: RigData
    '''
    pos = [(0, 0, 0)]
    curve = pm.curve(name=name,
                     d=degree,
                     p=pos * len(matrices)
                     )
    for i, matrix in enumerate(matrices):
        vec = mmtrx.get_posvector(matrix)
        curve.cv[i].setPosition([vec.x, vec.y, vec.z], space="world")
    return curve


def transform_for_matrix(matrix_attr, name, suffix="FOLLOW", parent=None,
                         snap=True, connect="srt"):
    """
    Creates a transform node that is simple constrained to a matrix attr

    :param matrix_attr: Matrix Attribute
    :type matrix_attr: Matrix Attribute

    :param name: Name of node.
    :type name: String

    :param suffix: Override for the object's name suffix
    :type suffix: String

    :param parent: Object to parent under
    :type parent: PyNode

    :param snap: Snap transforms to source
    :type snap: Boolean

    :param connect: Define with attributes should be connected. Default="srt"
    :type connect: String
    """
    namer = mname.Name(name=name,
                       suffix=suffix
                       )
    transform = pm.createNode("transform",
                              name=namer.replace(),
                              parent=parent
                              )
    mcon.create_simple_constraint(matrix_attr,
                                  transform,
                                  snap=snap,
                                  connect=connect
                                  )
    return transform


def matrix_blend(source1=None, source2=None, target=None, blend_attr=None,
                 connect='srt', add_to_tags=None, constrain=False, snap=False):
    """
    Creates a blend matrix constraint on the target, blending between two
    sources.

    :param source1: either a pymel object or matrix
    :type source1: PyNode

    :param source2: either a pymel object or matrix
    :type source2: PyNode

    :param target: Object to be constrained
    :type target: PyNode

    :param blend_attr: Define with attributes should be connected. Default="srt"
    :type blend_attr: pm.Attribute

    :param connect: Define with attributes should be connected. Default="srt"
    :type connect: String

    :param constrain: If true, constrains the blend to the target
    :type constrain: Boolean
    """
    blend = mmblend.MatrixBlend(name=None,
                                source1=source1,
                                source2=source2,
                                target=target,
                                blend=blend_attr,
                                connect=connect,
                                add_to_tags=None,
                                constrain=constrain,
                                snap=snap
                                )

    return blend.node


def offset_matrix_node(node, parent=None):
    """
    creates a multMatrix node that delivers a relative offset-matrix to a parent
    :param node: either a pymel object or matrix
    :type node: PyNode

    :param parent: either a pymel object or matrix
    :type parent: PyNode

    :rType: PyNode
    """
    parent_inv_matrix = parent.worldInverseMatrix or node.parentInverseMatrix
    name = mname.Name(node).replace(suffix='MMLT')
    mmlt = pm.createNode('multMatrix', name=name)
    node.worldMatrix >> mmlt.matrixIn[0]
    parent_inv_matrix >> mmlt.matrixIn[1]
    return mmlt


def _get_source_matrix(source, use_world):
    """
    check the sources, taking the right matrix worldMatrix if it's an object
    """
    if isinstance(source, pm.Attribute):
        if not source.type() == "matrix":
            raise ValueError("'%s' must be a matrix or PyNode type" % str(source))
    else:
        if use_world:
            source = source.worldMatrix[0]
        else:
            source = source.matrix
    return source


def angle_aim(start_obj, end_obj, zero=None, aim_axis="+x"):
    """
    creates an aim_construct similar to an aimConstraint, but without the upvector

    :param name: The base name for the aimers ('start' and 'end' tags are added)
    :param start_obj: a pynode transform that drives the start
    :param end_obj: a pynode transform that drives the end
    :param aim: +/- & x/y/z string
    :return: PyNode "pointMatrixMult"
    """
    namer = mname.Name(start_obj)

    zero = zero or start_obj.getParent()

    # create a locator shape for the end_object if it is not already existing
    shp = add_locator_shape(end_obj, suffix="CNST")

    mpmm = pm.createNode("pointMatrixMult",
                         name=namer.replace(suffix="pointMatrixMult")
                         )
    angl = pm.createNode("angleBetween",
                         name=namer.replace(suffix="angleBetween")
                         )
    shp.worldPosition >> mpmm.inPoint
    zero.worldInverseMatrix >> mpmm.inMatrix
    mpmm.o >> angl.v2
    angl.v1.set(mpmm.o.get())
    angl.euler >> start_obj.r
    return mpmm


def simple_aimer(name, start_parent, end_parent,
                 num_inbetweens=0, aim="+x", up="+z"):
    """
    Creates an aiming srt-chain with uniform distibution along aim.

    :param name: The base name for the aimers ('start' and 'end' tags are added)
    :param start_parent: a pynode transform that drives the start
    :param end_parent: a pynode transform that drives the end
    :param num_inbetweens: amount of inbetween srt
    :param aim: +/- & x/y/z string
    :param up: +/- & x/y/z string
    :return:
    """
    namer = mname.Name(name)

    # make the srts
    matrix = mmtrx.get_matrix(start_parent)
    chain = msrt.SRTGroupChain(name=namer.create_name(),
                               matrices=[matrix] * (2 + num_inbetweens),
                               parent=start_parent,
                               suffix="SRT",
                               create_zero=False,
                               create_ofs=False
                               )

    # make the aim constraints
    mcon.create_aim_constraint(source=end_parent,
                               target=chain.root,
                               axis_obj=start_parent,
                               aim=aim,
                               up=up,
                               axis_aim=up
                               )

    dist = pm.createNode('distanceBetween',
                         name=namer.replace(suffix='distanceBetween'))
    mdcp = pm.createNode('decomposeMatrix',
                         name=namer.replace(suffix='decomposeMatrix'))
    mpmm = pm.createNode('pointMatrixMult',
                         name=namer.replace(suffix='pointMatrixMult'))
    mdl = pm.createNode('multDoubleLinear',
                        name=namer.replace(suffix='multDoubleLinear'))

    end_parent.worldMatrix >> mdcp.inputMatrix
    start_parent.worldInverseMatrix >> mpmm.inMatrix
    mdcp.outputTranslate >> mpmm.inPoint
    mpmm.output >> dist.point2
    dist.distance >> mdl.input1
    multiplier = sum(STR_TO_VEC_SWITCH[aim])
    mdl.input2.set(multiplier / (1.0 + num_inbetweens))
    for item in chain[1:]:
        mdl.output >> item.obj.attr('t' + aim[-1])
    return chain


def dual_aimers(name, start_matrix, end_matrix, start_parent, end_parent, aim="+x", up="+z",
                invert_end_aim=True, create_cnst=False):
    """
    Creates two str group rig objects that aim at each other.

    :param name: The base name for the aimers ('start' and 'end' tags are added)
    :param start_matrix: om.MMatrix
    :param end_matrix: om.MMatrix
    :param start_parent: a pynode transform that drives the start
    :param end_parent:a pynode transform that drives the end
    :param aim: +/- & x/y/z string
    :param up: +/- & x/y/z string
    :param invert_end_aim: if true, it reverses the aim of the end so that they both have the same orientation
    :return:
    """
    namer = mname.Name(name)

    # make the srts
    start_aimer = msrt.SRTGroup(name=namer.replace(add_to_tags="start"),
                                matrix=start_matrix,
                                parent=start_parent,
                                suffix="AIM",
                                create_cnst=create_cnst
                                )
    end_aimer = msrt.SRTGroup(name=namer.replace(add_to_tags="end"),
                              matrix=end_matrix,
                              parent=end_parent,
                              suffix="AIM",
                              create_cnst=create_cnst
                              )

    # make the aim constraints
    mcon.create_aim_constraint(source=end_aimer.root,
                               target=start_aimer.top,
                               axis_obj=start_aimer.root,
                               aim=aim,
                               up=up,
                               axis_aim=up
                               )
    if invert_end_aim:
        aim = {"+": "-", "-": "+"}[aim[0]] + aim[1]
    mcon.create_aim_constraint(source=start_aimer.root,
                               target=end_aimer.top,
                               axis_obj=end_aimer.root,
                               aim=aim,
                               up=up,
                               axis_aim=up
                               )
    return start_aimer, end_aimer


def distance(name, rig_object1, rig_object2, global_scale):
    """
    returns an attribute that

    :param name: a name for the nodes
    :param rig_object1:
    :param rig_object2:
    :param global_scale:
    :return:
    """
    namer = mname.Name(name)

    # squash and stretch node
    distance = pm.createNode("distanceBetween", n=namer.replace(suffix="DIST"))
    global_div = pm.createNode("multiplyDivide", n=namer.replace(suffix="GSCALE"))
    global_div.operation.set(2)

    # connect
    _get_world_pos(rig_object1) >> distance.point1
    _get_world_pos(rig_object2) >> distance.point2
    distance.distance >> global_div.input1X
    global_scale >> global_div.input2X
    return global_div.outputX


def modulebuilder_bone(node, modulebuilder):
    """
    Given a transform node and a modulebuilder class, creates a constrained transform and a millrig bone

    :param node: PyNode transform
    :param modulebuilder: millRig.scriptedModule.BaseModuleBuilder class
    :return: PyNode transfrom
    """
    namer = mname.Name(node.name())
    srt = msrt.SRTGroup(name=namer.replace(add_to_tags="bone"),
                        matrix=mmtrx.get_matrix(node),
                        create_zero=False,
                        create_ofs=False
                        )
    mcon.create_simple_constraint(source=node, target=srt.top)
    srt.create_bone(modulebuilder)
    return srt.root


def jointchain(name, len_list, add_to_tags=None, suffix='BONE',
               aim_axis='+x', ro='xyz', last=True, parent=None):
    '''
    Creates and returns a jointchain with numeric indices and "END"-index for the last element.
    The lenList defines the length and amount of the created joints.
    '''
    aim_vec = mmtrx.get_as_mvector(aim_axis)
    pos_list = [0] + len_list
    jnts = []
    parent = parent
    chain_names = mname.create_chain_names(len(pos_list), last=last,
                                           startindex=1, force_index=True,
                                           name=name, add_to_tags=add_to_tags,
                                           suffix=suffix)

    for jnt_name, pos in zip(chain_names, pos_list):
        jnt = pm.createNode('joint', name=jnt_name, parent=parent)
        jnt.t.set(pos * aim_vec)
        jnt.ro.set(ROTORDER_SWITCH[ro])
        parent = jnt
        jnts.append(jnt)

    return jnts


def parent_to_follicle(node, parent=None, data=None):
    """
    create a follicle as parent to the given node.
    This should also work if a rigobject-class is given as "data"
    :param node: transform
    :type node: PyNode
    :param nrb: nurbsSurface-transform-Node
    :type nrb: PyNode
    :param uv: uv-values
    :type uv: Tuple or List of Floats
    :param parent: transform
    :type parent: PyNode
    :param data: Class
    :type data: Class or RigDataClass
    """
    data = data or RigData()
    namer = data.namer or mname.Name(node)
    name = namer.replace(suffix=namer.suffix, add_to_suffix='FOLL')
    data.foll = pm.createNode('transform', name=name, parent=parent)
    data.follshape = pm.createNode('follicle',
                                   name=data.foll.name() + 'Shape',
                                   parent=data.foll)
    data.follshape.outTranslate >> data.foll.t
    data.follshape.outRotate >> data.foll.r
    data.follshape.visibility.set(False)
    data.u_plug = data.foll.pu
    data.v_plug = data.foll.pv
    return data


    def connect_to_nurbs(self, nrb=None, uv=None):
        """
        connect nurbs to follicle and set u/v-values
        :param nrb: nurbsSurface-transform-Node
        :type nrb: PyNode
        :param uv: nurbsSurface-transform-Node
        :type uv: PyNode
        """
        nrb = nrb or self.nrb
        uv = uv or self.uv
        if nrb:
            nrb.getShape().ws >> self.follshape.inputSurface
        if uv:
            self.u_plug.set(uv[0])
            self.v_plug.set(uv[1])


def _get_world_pos(rig_object):
    """
    returns a world position attribute from the rigobject

    :param rig_object:
    :return:
    """
    try:
        return rig_object.cnst.worldPosition
    except:
        namer = mname.Name(rig_object.obj.name())
        dcmp = pm.createNode("decomposeMatrix", n=namer.replace(suffix="decomposeMatrix"))
        rig_object.top.worldMatrix >> dcmp.inputMatrix
        return dcmp.outputTranslate

