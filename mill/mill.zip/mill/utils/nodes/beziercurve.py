"""
.. module:: utils.nodes.matrixramp
   :synopsis: Class for creation of bezier-style matrixsamples

.. moduleauthor:: andreasg
"""

# maya imports
import pymel.core as pm

# package imports
from millrigger.globals import rig as RIG
from millrigger.utils import name as mname
from millrigger.utils import attributes as mattr
from millrigger.utils.maths import linspace_float

# plugins
pm.loadPlugin("millBezierCurve", qt=True)


class BezierCurve(object):

    ''' wrapper-class for millMatrixRamp-node

    :param name: Name of node.
    :type name: String

    :param namer: an existing Nameclass can be used
    :type namer: NameClass

    :param suffix: overwrite the suffix
    :type suffix: String

    :param add_to_tags: additional tag for the name
    :type add_to_tags: String

    :param node: if the MillBezierCurve-node already exists it can be used
    :type node: PyNode

    :param object: Create the result, or just the dependency node.
    :type object: Boolean

    :param source_attr: matrix-attribute that drives the insamples
    :type source_attr: String

    :param create_attributes: if True bezier-attributes are created
    :type create_attributes: Boolean

    :param split_tangents: if True tangent-attributes are split into "in" and "out" part
    :type split_tangents: Boolean

    :param mirror_tangents: if True tangent-attribute-names are flipped half-way
    :type mirror_tangents: Boolean

    :param sources: Objects to drive the input
    :type sources: List of PyNodes

    :param attr_holders: Objects to add the attributes to (might not always be the sources...)
    :type attr_holders: List of PyNodes

    :param insamples: list of sample-values
    :type insamples: List of Floats

    :param aim_axis: Orientation of the curve
    :type aim_xis:  +x/+y/+z/-x/-y/-z

    :param scale_tangents: scaling of the handle will also affect the tangents
    :type scale_tangents: Boolean

    :param default_aim: default blend-value for all aim-attributes
    :type default_aim: Float

    :param default_tangent: default tangent-state for all attributes
    :type default_aim: Float

    :rType: PyNode

    '''

    def __init__(self,
                 name='C_bezier_MBEZ',
                 tangent_tags=['in', 'out'],
                 source_attr='worldMatrix',
                 namer=None,
                 add_to_tags=None,
                 suffix=None,
                 node=None,
                 sources=None,
                 attr_holders=None,
                 create_attributes=True,
                 split_tangents=True,
                 mirror_tangents=False,
                 default_aim=1.0,
                 default_tangent=0.33,
                 object=True,
                 **kwargs):

        self._mode_dict = {'linear': 1, 'smooth': 2, 1: 'linear', 2: 'smooth'}
        self._namer = namer or mname.Name(node or name)
        self._name = self._namer.replace(add_to_tags=add_to_tags,
                                         suffix=suffix or 'millBezierCurve')
        self.tangent_tags = [tag.capitalize() for tag in tangent_tags]

        # user parameters
        self._create_attributes = create_attributes
        self._source_attr = source_attr
        self._default_aim = default_aim
        self._default_tangent = default_tangent
        self._split_tangents = split_tangents
        self._mirror_tangents = mirror_tangents

        # get the node and curve
        self.node = self._create_node(node)
        self.curve = None
        self.shape = None

        # init all parameters by reading the node-attributes
        self._attr_holders = self._check_attr_holders(sources, attr_holders)
        self._sources = self._get_sources()
        self._insamples = self._get_insamples()
        self._scale_tangents = self.node.scaleTangentWeights.get()
        self._paramsamples = self.node.parameterisationSamples.get()
        self._cyclic = self.node.cyclic.get()
        self._aim_axis = RIG.AXIS_KEYS[self.node.aimAxis.get()]

        # set the node-attributes with given values
        if sources:
            kwargs['sources'] = sources
        self.set_values(kwargs)
        if create_attributes is False:
            self._set_insample_attributes()

        # create curve-node if needed
        if object:
            self._create_curve()

    # =========================================================================
    # Properties --------------------------------------------------------------
    # =========================================================================

    @property
    def aim_axis(self):
        return self._aim_axis

    @aim_axis.setter
    def aim_axis(self, aim_axis):
        index = RIG.AXIS_KEYS.index(aim_axis)
        self.node.aimAxis.set(index)

    @property
    def insamples(self):
        return self._insamples

    @insamples.setter
    def insamples(self, samples):
        self._set_insamples(samples)

    @property
    def sources(self):
        return self._sources

    @sources.setter
    def sources(self, sources):
        self._set_insamples(sources)
        if self._create_attributes:
            self._add_attributes_to_sources(sources)  # add and link attributes
        self.connect_sources(sources)
        self._sources = sources

    @property
    def param_samples(self):
        return self._paramsamples

    @param_samples.setter
    def param_samples(self, val):
        self.node.parameterisationSamples.set(val)
        self._paramsamples = val

    @property
    def scale_tangents(self):
        return self._scale_tangents

    @scale_tangents.setter
    def scale_tangents(self, val):
        self.node.scaleTangentWeights.set(val)
        self._scale_tangents = val

    @property
    def cyclic(self):
        return self._cyclic

    @cyclic.setter
    def cyclic(self, val):
        self.node.cyclic.set(val)
        self._cyclic = val

    # =========================================================================
    # Public Functions --------------------------------------------------------
    # =========================================================================

    def set_values(self, kwargs):
        if 'sources' in kwargs:
            self.sources = kwargs.get('sources')

        if 'insamples' in kwargs:
            self.insamples = kwargs.get('insamples')

        if 'scale_tangents' in kwargs:
            self.scale_tangents = kwargs.get('scale_tangents')

        if 'param_samples' in kwargs:
            self.param_samples = kwargs.get('param_samples')

        if 'cyclic' in kwargs:
            self.cyclic = kwargs.get('cyclic')

        if 'aim_axis' in kwargs:
            self.aim_axis = kwargs.get('aim_axis')

    def connect_sources(self, sources):
        for i, obj in enumerate(sources):
            if isinstance(sources[i], pm.Attribute):
                sources[i] >> self.node.inSample[i].inMatrix
            else:
                sources[i].attr(self._source_attr) >> self.node.inSample[i].inMatrix

    def hide_aim_attr(self):
        '''
        since the aim should normally be active it might be useful to just
        activate it and forget about it
        '''
        for obj in self._attr_holders:
            obj.aim.setKeyable(False)

    # =========================================================================
    # Non-Public Functions ----------------------------------------------------
    # =========================================================================

    def _create_node(self, node):
        if isinstance(node, pm.PyNode):
            if node.type() == 'millBezierCurve':
                return node
        elif pm.objExists(self._name):
            return pm.PyNode(self._name)
        else:
            return pm.createNode('millBezierCurve', name=self._name)

    def _create_curve(self):
        if self.node:
            name = self._namer.replace(suffix="CRV")
            if pm.objExists(name):
                self.curve = pm.PyNode(name)
                self.shape = self.curve.getShape(type="nurbsCurve")
            else:
                self.shape = pm.createNode("nurbsCurve", name=name + "Shape")
                self.node.outCurve >> self.shape.create
                self.curve = self.shape.getParent()
        return

    def _check_samples(self, samples):
        ''' convert samples into a list of samples '''

        # case 1: a dictionary is given
        # >> find largest list in contents of dictionary
        if isinstance(samples, dict):
            max_val = 0
            for key in samples:
                val = len(samples[key])
                if val > max_val:
                    max_val = val
            samples = max_val

        # case 2: a list is given
        # >> if a valid list is given return either the list or continue the tests
        if isinstance(samples, list):
            if not isinstance(samples[0], (int, float)):
                samples = len(samples)
            else:
                return samples

        # case 3: integer given as amount of samples to create
        if isinstance(samples, int):
            if samples == 1:
                return [0.5]
        return linspace_float(0.0, 1.0, num=samples or 2)

    def _set_insamples(self, samples):
        samples = self._check_samples(samples)
        if samples:
            for i, sample in enumerate(samples):
                if sample < 0.0002:
                    sample = 0.0001
                self.node.inSample[i].inValue.set(sample)
            self._insamples = samples
        return samples

    def _set_insample_attributes(self):
        """ set defaultvalues if no attributes are created """
        for i in range(len(self.insamples)):
            self.node.inSample[i].tangentAimBlend.set(self._default_aim)
            self.node.inSample[i].tangentInWeight.set(self._default_tangent)
            self.node.inSample[i].tangentOutWeight.set(self._default_tangent)

    def _add_attributes_to_sources(self, sources):
        ''' add attributes if they are not existing '''

        if not sources:
            return

        len_objs = len(sources)
        mirror = None
        mirror_max_index = 0
        if self._mirror_tangents is True:
            mirror_max_index = len_objs / 2

        for i, obj in enumerate(self._attr_holders):
            # add  and connect attributes
            if not obj.hasAttr('BEZIER'):
                mattr.add_headline(obj, 'BEZIER')

            if not obj.hasAttr('aim'):
                obj.addAttr('aim', min=0.0, max=1.0, dv=self._default_aim, k=True)
            obj.aim >> self.node.inSample[i].tangentAimBlend
            mirror = i > mirror_max_index
            attr_dict = {False: "tangentInWeight",
                         True: "tangentOutWeight"}
            if self._split_tangents is True and 0 < i < len_objs - 1:
                attr_name = 'tangent' + self.tangent_tags[0]
                if not obj.hasAttr(attr_name):
                    obj.addAttr(attr_name, min=0.00001, max=1.0, dv=self._default_tangent, k=True)
                obj.attr(attr_name) >> self.node.inSample[i].attr(attr_dict[not mirror])
                attr_name = 'tangent' + self.tangent_tags[1]
                if not obj.hasAttr(attr_name):
                    obj.addAttr(attr_name, min=0.00001, max=1.0, dv=self._default_tangent, k=True)
                obj.attr(attr_name) >> self.node.inSample[i].attr(attr_dict[mirror])
            else:
                if not obj.hasAttr('tangent'):
                    obj.addAttr('tangent', min=0.00001, max=1.0, dv=self._default_tangent, k=True)
                obj.tangent >> self.node.inSample[i].tangentInWeight
                obj.tangent >> self.node.inSample[i].tangentOutWeight

        return sources

    def _get_sources(self):
        sources = []
        num = self.node.inSample.evaluateNumElements()
        for i in range(num):
            nodes = self.node.inSample[i].inMatrix.inputs(scn=True, p=True)
            if nodes:
                sources.append(nodes[0])
            else:
                sources.append(None)

        return sources

    def _check_attr_holders(self, sources, attr_holders):
        # no attr-holder is given
        if attr_holders is None:
            attr_holders = sources

        if sources:
            if len(attr_holders) == len(sources):
                # filter out attributes and just keep nodes
                return [attr_holder.node() for attr_holder in attr_holders]
            else:
                raise RuntimeError("Amount of Attributeholders doesn't match with sources!")

    def _get_insamples(self):
        num = self.node.inSample.evaluateNumElements()
        if num:
            insamples = [self.node.inSample[i].inValue.get() for i in range(num)]
            return insamples

