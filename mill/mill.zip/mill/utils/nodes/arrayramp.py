"""
Class to deal with Mill's "millArrayRampSRT"-plugin

.. module:: util.curveinterp
   :synopsis: Class to deal with Mill's "millArrayRampSRT"-plugin

.. moduleauthor:: andreasg

"""
# libraries
from numpy import linspace

# maya modules
import pymel.core as pm

# package modules
from millrigger.utils import name as mname

# plugins
pm.loadPlugin("millArrayRampSRT", qt=True)
pm.loadPlugin("arrayRampNode", qt=True)


class ArrayRamp(object):
    ''' Class to deal with Mill's "millArrayRampSRT"-plugin

    :param name: Name of node.
    :type name: String

    :param sources: Objects to drive the input
    :type sources: List of PyNodes

    :param targets: Objects to be driven
    :type targets: List of PyNodes

    :param in_samples: list of values between 0 and 1 where the node samples in_values
    :type in_samples: List of Floats

    :param out_samples: list of values between 0 and 1 where the node samples out_values
    :type out_samples: List of Floats

    :param connect: Define with transforms should be connected. Default="srt"
    :type connect: String

    :rType: ArrayRamp-class
    '''

    def __init__(self, name=None, add_to_tags=None,
                 sources=None, targets=None,
                 in_samples=None, out_samples=None,
                 connect='srt', mode='linear'):

        self.in_dict = {'t': 'inTranslate',
                        'r': 'inRotate',
                        's': 'inScale'}

        self.out_dict = {'t': 'outTranslate',
                         'r': 'outRotate',
                         's': 'outScale'}

        self.mode_dict = {'none': 0,
                          'linear': 1,
                          'smooth': 2,
                          'spline': 3}

        self.interp_dict = {'t': 'translate',
                            'r': 'rotate',
                            's': 'scale'}

        self.mode = self.mode_dict.get(mode.lower(), 1)

        self.name = name or 'millArrayRampSRT'
        self.sources = sources
        self.targets = targets
        self.in_samples = in_samples
        self.out_samples = out_samples
        self.connect = [value.lower() for value in connect if value in 'srtSRT']
        self.node = None

        self.create()

    def create(self):
        # create node
        if self.sources is None and self.targets is None:
            return

        self.node = pm.createNode('millArrayRampSRT', name=self.name)
        self.node.addAttr('mode', dv=1)

        in_len = len(self.sources)
        out_len = len(self.targets)

        if self.in_samples is None:
            self.in_samples = linspace(0, 1, len(self.sources))

        if self.out_samples is None:
            self.out_samples = linspace(0, 1, len(self.targets))

        if len(self.in_samples) == in_len and len(self.out_samples) == out_len:
            for i, in_node in enumerate(self.sources):
                for attr in self.connect:
                    in_node.attr(attr) >> self.node.inData[i].attr(self.in_dict[attr])

            for i, out_node in enumerate(self.targets):
                for attr in self.connect:
                    self.node.outData[i].attr(self.out_dict[attr]) >> out_node.attr(attr)

            # samples can only be set after nodes are connected
            for i in range(in_len):
                self.node.inSamples[i].set(self.in_samples[i])

            for i in range(out_len):
                self.node.outSamples[i].set(self.out_samples[i])

            for i in range(in_len):
                for connect in self.connect:
                    for axis in 'XYZ':
                        attr = '{0}.{1}{2}curve[{3}].{1}{2}curve_Interp'.format(self.node.name(),
                                                                                self.interp_dict[connect],
                                                                                axis,
                                                                                i
                                                                                )
                        self.node.mode >> pm.Attribute(attr)


class ArrayRamp2(object):
    ''' Class to deal with Mill's "millArrayRampSRT"-plugin

    :param name: Name of node.
    :type name: String

    :param sources: Objects to drive the input
    :type sources: List of PyNodes

    :param targets: Objects to be driven
    :type targets: List of PyNodes

    :param in_samples: list of values between 0 and 1 where the node samples in_values
    :type in_samples: List of Floats

    :param out_samples: list of values between 0 and 1 where the node samples out_values
    :type out_samples: List of Floats

    :param connect: Define with transforms should be connected. Default="srt"
    :type connect: String

    :rType: ArrayRamp-class
    '''

    def __init__(self, name=None, add_to_tags=None,
                 sources=None, targets=None,
                 in_samples=None, out_samples=None,
                 connect='srt', mode='linear'):

        self.in_dict = {'t': 'inTranslate',
                        'r': 'inRotate',
                        's': 'inScale'}

        self.out_dict = {'t': 'outTranslate',
                         'r': 'outRotate',
                         's': 'outScale'}

        self.mode_dict = {'none': 0,
                          'linear': 1,
                          'smooth': 2,
                          'spline': 3}

        self.interp_dict = {'t': 'translate',
                            'r': 'rotate',
                            's': 'scale'}

        self.mode = self.mode_dict.get(mode.lower(), 1)

        self.name = name or 'C_generic_ARMP'
        self.namer = mname.Name(self.name)

        self.sources = sources
        self.targets = targets
        self.in_samples = in_samples
        self.out_samples = out_samples
        self.connect = [value.lower() for value in connect if value in 'srtSRT']
        self.nodes = None

        self.create()

    def create(self):
        # create node
        if self.sources is None and self.targets is None:
            return

        self.nodes = []

        in_len = len(self.sources)
        out_len = len(self.targets)

        if self.in_samples is None:
            self.in_samples = linspace(0, 1, in_len)

        if self.out_samples is None:
            self.out_samples = linspace(0, 1, out_len)

        if len(self.in_samples) == in_len and len(self.out_samples) == out_len:
            for connect in self.connect:
                for axis in 'xyz':
                    attr = connect + axis
                    name = self.namer.replace(add_to_tags=attr)
                    node = pm.createNode('millArrayRampNode', name=name)
#                     node.addAttr('mode', dv=1)
                    for i, pos in enumerate(self.in_samples):
                        node.curve[i].curve_Position.set(pos)
                        self.sources[i].attr(attr) >> node.curve[i].curve_FloatValue
#                         node.mode >> node.curve[i].curve_Interp

                    for i, pos in enumerate(self.out_samples):
                        node.inSamples[i].set(pos)
                        node.outSamples[i] >> self.targets[i].attr(attr)
                    self.nodes.append(node)
