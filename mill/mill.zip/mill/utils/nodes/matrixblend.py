"""
Class to deal with the millMatrixBlend-node

.. module:: util.matrixblend
   :synopsis: Class to deal with the millMatrixBlend-node

.. moduleauthor:: andreasg

"""

# maya modules
import pymel.core as pm

# package modules
from millrigger.utils import name as mname
from millrigger.utils import matrix as mmtrx
from millrigger.utils.nodes import constraints as mcon

# make sure the plugin is active
pm.loadPlugin('millMatrixBlend', qt=True)


class MatrixBlend(object):
    ''' Class to deal with Maya's pairblend-node

    :param name: Name of node.
    :type name: String

    :param source1: Node to connect as the first input
    :type source1: Transform

    :param source2: Node to connect as the second input
    :type source2: Transform

    :param target: Node to connect as the target
    :type target: Transform

    :param blend: Set or connect the blend value
    :type blend: Attribute or Float

    :param connect: Which transforms to connect s=scale, r=rotate, t=translate
    :type connect: string

    :param snap: If snap is false the offset will be maintained
    :type snap: Boolean

    :param add_to_tags: Value(s) to add the tags of a name
    :type add_to_tags: String or List of strings

    :param constrain: if True, uses a simple constraint to connect the target to the blend in world space
    :type constrain: Bool

    :rType: PyNode
    '''

    def __init__(self, name=None, source1=None, source2=None, target=None, blend=0.0, connect="srt", add_to_tags=None,
                 constrain=False, snap=False, rotate_order=None):
        # if we have no sources or a target, don't do anything
        if name is None and target is None:
            raise ValueError("MatrixBlend requires a name or a target")

        self.namer = mname.Name(name or target, add_to_tags=add_to_tags)
        tags = self.namer.suffix.lower()
        name = self.namer.replace(add_to_tags=tags, suffix='millMatrixBlend')
        self.snap = snap

        self.node = pm.createNode('millMatrixBlend', name=name)
        self._blend = self._filter_blend(blend)
        self._target = target
        self._source1 = self._filter_input(source1, 'inMatrix1')
        self._source2 = self._filter_input(source2, 'inMatrix2')
        self._rotate_order = rotate_order

        # connect everything up
        if target:
            self.connect_target(self._target, connect, constrain)
        if self._rotate_order is not None:
            self.set_rotate_order(rotate_order)

    @property
    def name(self):
        return self.node.name()

    @property
    def blend(self):
        return self.node.blend.get()

    @blend.setter
    def blend(self, val):
        ''' connect or set weight-value of matrixBlend-node '''
        if isinstance(val, pm.Attribute):
            val >> self.node.blend
        elif isinstance(val, float) or isinstance(val, int):
            self.node.blend.set(val)
        else:
            raise AttributeError('Invalid input for weight: %s' % val)

    @property
    def source1(self):
        '''
        returns either the value of the inMatrix1-attribute or the
        pymel-Attribute it is connected to
        '''
        return self._source1

    @source1.setter
    def source1(self, val):
        ''' connect or set inMatrix1-attribute of matrixBlend-node '''
        self._filter_input(val, 'inMatrix1')
        self._source1 = val

    @property
    def source2(self):
        '''
        returns either the value of the inMatrix2-attribute or the
        pymel-Attribute it is connected to
        '''
        return self._source2

    @source2.setter
    def source2(self, val):
        ''' connect or set inMatrix2-attribute of matrixBlend-node '''
        self._filter_input(val, 'inMatrix2')
        self._source2 = val

    def connect_target(self, transform, connect, constrain_to_target):
        """ connects the given transforms rot and pos to be the target

        :param transform: Node to connect as the target
        :type transform: Transform

        :param connect: Which transforms to connect s=scale, r=rotate, t=translate
        :type connect: string

        :param constrain_to_target: if True, uses a simple constraint
        :type constrain_to_target: Bool
        """
        if constrain_to_target:
            mcon.create_simple_constraint(source=self.node.outMatrix, target=transform, connect=connect)
        else:
            if "t" in connect:
                self.node.outTranslate >> transform.translate

            if "r" in connect:
                self.node.outRotate >> transform.rotate
                self.node.rotateOrder.set(transform.rotateOrder.get())

            if "s" in connect:
                self.node.outScale >> transform.scale

    def set_rotate_order(self, rotate_order):
        """ either sets or connects the rotate order to the matrixBlend node

        :param rotate_order: string or int
        :return:
        """
        if isinstance(rotate_order, pm.Attribute):
            rotate_order >> self.node.rotateOrder
        else:
            self.node.rotateOrder.set(rotate_order)

    def _filter_input(self, source, attr):
        ''' connects or set value depending on the input '''

        if source is None:
            self.node.attr(attr).disconnect()
            mmlt_name = self.namer.replace(index=attr[-1], suffix='multMatrix')
            if pm.objExists(mmlt_name):
                pm.delete(mmlt_name)

        elif isinstance(source, pm.nodetypes.Transform):
            self._connect(source, attr)

        elif isinstance(source, pm.general.Attribute):
            source >> self.node.attr(attr)

        else:
            try:
                val = mmtrx.matrix_to_list(source)
                self.node.attr(attr).disconnect()
                self.node.attr(attr).set(val)
                return val
            except ValueError('Invalid input : %s' % source):
                return

    def _space_check(self, source):
        ''' check if spaceconvertions are needed '''
        source_parent = source.getParent()
        if self._target:
            target_parent = self._target.getParent()
            return (source_parent == target_parent)
        return False

    def _connect(self, source, attr, snap=None):
        ''' create and connect multMatrix '''

        snap = snap or self.snap
        # source and target are in the same space >> no multMatrix is needed
        mmlt_name = self.namer.replace(index=attr[-1], suffix='multMatrix')

        if pm.objExists(mmlt_name):
            pm.delete(mmlt_name)
        if self._space_check(source) is True:
            source.matrix >> self.node.attr(attr)
        else:
            mmlt = pm.createNode('multMatrix', name=mmlt_name)
            if snap is True:
                source.worldMatrix >> mmlt.matrixIn[0]
                self._target.parentInverseMatrix >> mmlt.matrixIn[1]
            else:
                mmlt.matrixIn[0].set(self._target.worldMatrix.get())
                source.worldMatrix >> mmlt.matrixIn[1]
                self._target.parentInverseMatrix >> mmlt.matrixIn[2]
            mmlt.matrixSum >> self.node.attr(attr)

    def _filter_blend(self, val):
        ''' connects or set value depending on the input '''

        if val is None:
            self.node.blend.disconnect()

        elif isinstance(val, float):
            self.node.blend.set(val)

        elif isinstance(val, pm.Attribute):
            try:
                val >> self.node.blend
            except ValueError('Invalid input : %s' % val):
                return
        return val

