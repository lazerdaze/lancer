"""
.. module:: shape
   :synopsis: Import, export and creation of nurbsCurves.

.. moduleauthor:: andreasg, fabiane, ren, petera
"""
# python imports
import os
import json

# maya imports
import pymel.core as pm
import maya.cmds as cmds
import maya.api.OpenMaya as om
from pymel.core.nodetypes import NurbsCurve

# package imports

from millrigger.globals.io import CTRL_PATH
from millrigger.globals.name import TYPE_SUFFIX_DICT
from millrigger.globals.node import COMPONENT_DICT
from millrigger.utils.data import RigData
from millrigger.utils import matrix as mmtrx
from millrigger.utils import vector as mvec
from millrigger.utils.nodes import create as mcre
from rigging.utils.sym import copy_table
import millrigger.utils.name as mname
import millrigger.utils.attributes as mattr


# =============================================================================
# Public Functions ------------------------------------------------------------
# =============================================================================

def get_filelist(path=None, ext=None, nameOnly=None):
    """
    Return the file list found in the given path
    If nameOnly is True, returns without the file extension
    If ext is given, list only the files ending with it
    """

    if ext and not nameOnly:
        nameOnly = False
    try:
        file_list = os.listdir(path)
        if ext:
            file_list[:] = [item for item in file_list if item.endswith('.' + ext)]
        if nameOnly:
            file_list[:] = [item.rsplit('.', 1)[0] for item in file_list]
        return file_list
    except OSError:
        print("--- path '%s' doesn't exist" % path)


def shape_select(obj, nodetype=None):
    """
    :param obj: transform or shape-node
    :type nurbs: PyNode

    :rtype: RigData
    """
    data = RigData()

    # selection is shape
    if isinstance(obj, pm.nodetypes.Shape):
        data.shape = obj
        data.transform = obj.getParent()
        return data

    # selection is transform
    if isinstance(obj, pm.nodetypes.Transform):
        data.transform = obj
        if nodetype:
            data.shape = obj.getShape(type=nodetype)
        else:
            data.shape = obj.getShape()
        return data


def get_nurbscurve_data(shape_node, param=True):
    '''Exports all data needed to recreate a nurbsCurve-shape

    :param shape_node: shapeNode
    :type shape_node: nurbsCurve

    :param param: parameterization (0 to 1) or (0 to #Spans)
    :type param: boolean

    .. note::
        For usage as control-shape:
        Shape needs to be 1 Unit in size and
        must be aligned with Y-axis
    '''

    crv_obj = NurbsCurve(shape_node)
    knot_list = map(int, crv_obj.getKnots())

    pos_list = mvec.get_cv_vectorlist(shape_node, ws=True)
    form = str(crv_obj.form())
    max_index = crv_obj.numCVs()

    # in case the parameter-range is not matching the cvCount
    if param:
        if crv_obj.getKnotDomain()[1] == 1:
            knot_list[:] = [round(knot * (max_index - 1), 0) for knot in knot_list]

    data = RigData()
    data.object_type = 'nurbsCurve'
    data.max_index = max_index
    data.degree = crv_obj.degree()
    data.spans = crv_obj.spans.get()
    data.form = form
    data.knots = knot_list
    data.pos_list = [[v.x, v.y, v.z] for v in pos_list]
    return data


def export_nurbscurve_data(shape_node, shape_name='tmp', path=CTRL_PATH, param=True):
    '''Exports all data needed to recreate a nurbsCurve-shape

    :param shape_node: shapeNode
    :type shape_node: nurbsCurve

    :param name: fileName
    :type name: string

    :param path: filePath
    :type path: string

    :param param: parameterization (0 to 1) or (0 to #Spans)
    :type param: boolean

    .. note::
        For usage as control-shape:
        Shape needs to be 1 Unit in size and
        must be aligned with Y-axis
    '''

    file_path = os.path.join(path, shape_name + '.json')

    data_dict = get_nurbscurve_data(shape_node, param).__dict__

    with open(file_path, "w") as f:
        json.dump(data_dict, f, indent=1)
    print "curvedata saved in file: %s" % file_path


def import_nurbscurve_data(shape_name, path=CTRL_PATH):
    ''' Reads nurbs-curve-data

    :param name: fileName
    :type name: string

    :param path: filePath
    :type path: string

    :rType: RigData-class
    '''
    file_path = os.path.join(CTRL_PATH, shape_name + '.json')
    if os.path.isfile(file_path):
        with open(file_path, "r") as file_obj:
            data_dict = json.load(file_obj)
        if data_dict:
            curve_data = RigData()
            curve_data.__dict__ = data_dict
            return curve_data
        else:
            pm.warning("Data is empty, check your file : '%s'" % file_path)


def create_nurbscurve(shape_name, parent=None, name=None, color=17, size=1.0,
                      aim='+x', up='+y', offset=None, debug=False):
    '''Function to create a nurbscurve-shape on a transform or joint-parent

    :param shape_name: controlshape-name in library
    :type shape_name: string

    :param parent: If a transform/joint is given, no extra transform is created
    :type parent: transform

    :param name: name of resulting curve-transform-node
    :type name: string

    :param color: Indexcolor-value
    :type color: int

    :param size: Scaling-factor of standard sized controlShape (1 Unit)
    :type size: float

    :param aim: Aim Axis
    :type aim: String = +x/+y/+z/-x/-y/-z

    :param up: Up Axis
    :type up: String = +x/+y/+z/-x/-y/-z

    :param offset: Offset to the shape
    :type offset: Vector

    :param debug: If True, this brings in the shape with no modifications at all
    :type debug: Bool

    :rtype: nurbsCurve

    .. note::
        If *parent* is defined, the curveshape will be transferred to the parent
        and the original curve-parent will be removed
    '''

    # import shape data
    shape = import_nurbscurve_data(shape_name)

    if not shape:
        print('--- no curvedata available/imported ---')
        return None

    # converts lists to vectors
    vectors = map(om.MVector, shape.pos_list)

    if not debug:
        # rotate and size vectors
        vectors = _rotate_vectors(vectors, aim, up)
        vectors = _translate_vectors(vectors, offset)
        vectors = _scale_vectors(vectors, size)

    # convert vectors to lists
    pos_list = [(v.x, v.y, v.z) for v in vectors]

    # check if curve is "periodic"
    if isinstance(shape.form, int):
        periodic = shape.form > 1
    else:
        periodic = shape.form == 'periodic'

    # Closed linear curves need special treatment...(sigh...)
    if shape.degree == 1:
        nrbs_crv = pm.curve(degree=1, point=pos_list)

        if periodic > 0:
            pm.closeCurve(nrbs_crv,
                          constructionHistory=False,
                          replaceOriginal=True
                          )
    else:
        # if periodic > 0:
        #     vec_list = vec_list + vec_list[:shape.degree]
        nrbs_crv = pm.curve(periodic=periodic,
                            degree=shape.degree,
                            point=pos_list,
                            knot=shape.knots
                            )

    if name:
        nrbs_crv.rename(name)

    crv_shape = nrbs_crv.getShape()

    if color is not None:
        crv_shape.ove.set(1)
        crv_shape.ovc.set(color)

    if parent:
        crv_shape.setParent(parent, shape=True, relative=True)
        pm.delete(nrbs_crv)
        if parent.type() == 'joint':
            parent.drawStyle.set(2)
        crv_shape.rename(parent.name() + 'Shape')
    return crv_shape


def drive_visibility(shapes, driver, default=1.0, attr_name=None):
    """
    Drives the visibility of the shape

    :param shapes: either a shape or a list of them (of a single obj)
    :param driver: If an attribute, drives the visibility directly. If a transform, give it
                   an attribute and use that to drive.
    :param default: The default value for the visibility
    :return:
    """
    # if shape isn't a list, make it one, then loop through
    if not isinstance(shapes, list):
        shapes = [shapes]

    # get a driver for the given shapes
    if not isinstance(driver, pm.Attribute):
        # look for RigObjects
        try:
            driver = driver.obj
        except AttributeError:
            driver = driver

        # use the custom name, if we need it
        if attr_name is not None:
            driver = mattr.add_generic_switch(node=driver,
                                              default=default,
                                              attr_name=attr_name
                                              )
        else:
            driver = mattr.add_visibility_attr(node=driver,
                                               items=shapes[0].getParent(),
                                               default=default
                                               )[0]

    for shape in shapes:
        namer = mname.Name(shape.name())

        shape.overrideEnabled.set(1)

        # if there's already an input, use an mult as an 'and' node to chain them together
        inputs = shape.overrideVisibility.inputs(p=True)
        if inputs:
            name = namer.replace(add_to_tags="vis", suffix="multDoubleLinear")
            mult = mcre.node(node_type="multDoubleLinear", name=name).node

            # connect existing and new
            inputs[0] >> mult.input1
            driver >> mult.input2
            driver = mult.output

            # disconnect the old attr
            shape.overrideVisibility.disconnect()

        driver >> shape.overrideVisibility


def get_shapeorig_node(node, cleanup=True):
    '''
    Returns the shapeOrig-node of the given node if found.
    If no origNode is found it returns the standard shapeNode.
    With the cleanup-option set, it will also check for any redundant unconnected intermediate-shapeNodes and deletes them
    '''
    attrDict = {'mesh': 'worldMesh[0]',
                'nurbsCurve': 'worldSpace[0]',
                'nurbsSurface': 'worldSpace[0]',
                'lattice': 'worldLattice[0]'}

    origNodeList = [item for item in node.getShapes() if item.isIntermediateObject()]
    resultList = []
    for orig in origNodeList:
        attr = attrDict.get(orig.type())
        if not orig.attr(attr).isConnected():
            if cleanup:
                pm.delete(orig)
        else:
            resultList.append(orig)
    if len(resultList) == 1:
        newName = mname.remove_enddigits(resultList[0].name())
        origNode = resultList[0].rename(newName)
    else:
        try:
            origNode = resultList[0]
        except IndexError:
            origNode = None
    return origNode


def update_intermediate(src, tgt):
    '''
    very useful script for updating the baseShape of meshes while preserving the rig
    '''
    srcShp = src.getShape(type='deformableShape')
    tgtShp = get_shapeorig_node(tgt)
    if not tgtShp:
        tgtShp = tgt.getShape(type='deformableShape')
    if tgtShp:
        ioState = tgtShp.io.get()
        tgtShp.io.set(False)
        if tgtShp.type() == 'mesh':
            # pm.polyTransfer(tgtShp, ao=srcShp, v=True, ch=False)
            srcShp.worldMesh >> tgtShp.inMesh
            pm.refresh()
            srcShp.worldMesh // tgtShp.inMesh
        elif tgtShp.type() in ['nurbsCurve', 'nurbsSurface']:
            srcShp.worldSpace >> tgtShp.create
            pm.refresh()
            srcShp.worldSpace // tgtShp.create
        else:
            copy_shape(srcShp, tgtShp, ws=True)
        tgtShp.io.set(ioState)
        print('origShape: {0} was replaced with: {1}'.format(tgtShp, srcShp))


def extract_intermediate(geo, name=None):
    """
    extract the intermediate shape without any constructionhistory

    :param geo: geometry with construction-history
    :type geo: PyNode/Transform
    :param name: the name of the new obj (suffix will be type-based)
    :type name: String
    :return: PyNode
    """
    intermed = pm.listRelatives(geo, shapes=True)[-1]
    geo_type = intermed.type()
    new_obj = None
    namer = mname.Name(geo)
    name = name or namer.replace(suffix='ORIG_GEO')
    if geo_type == 'mesh':
        new_obj = pm.polyCube(name=name.replace('_GEO', '_PLY'), ch=False)[0]
        intermed.worldMesh >> new_obj.getShape().inMesh
        pm.refresh()
        intermed.worldMesh // new_obj.getShape().inMesh
        copy_table(geo, new_obj)

    elif geo_type == 'nurbsCurve':
        new_obj = pm.circle(name=name.replace('_GEO', '_CRV'), ch=False)[0]
        intermed.worldSpace >> new_obj.getShape().create
        pm.refresh()
        intermed.worldSpace // new_obj.getShape().create
    elif geo_type == 'nurbsSurface':
        new_obj = pm.nurbsPlane(name=name.replace('_GEO', '_NRB'), ch=False)[0]
        intermed.worldSpace >> new_obj.getShape().create
        pm.refresh()
        intermed.worldSpace // new_obj.getShape().create
    elif geo_type == 'lattice':
        new_obj = pm.createNode('transform', name=name.replace('_GEO', '_LTC'))
        shape = pm.createNode('lattice', name=name.replace('_GEO', '_LTC'), parent=new_obj)
        intermed.worldLattice >> shape.latticeInput
        pm.refresh()
        intermed.worldLattice // shape.latticeInput
    return new_obj


def mirror_shape(src, ws=True):
    # all in cmds because we're working with components

    src = src.name()
    shape_list = _get_deformable_shapes(src)
    if shape_list is None:
        return

    type_dict = {'nurbsCurve': '.cv[*]',
                 'nurbsSurface': '.cv[*][*]',
                 'mesh': '.vtx[*]',
                 'lattice': '.pt[*][*][*]'
                 }

    for shp in shape_list:
        # get the mirror name
        tgt = mname.get_mirrorname(shp)
        if not cmds.objExists(tgt):
            return

        # mirror the shape
        if cmds.shapeCompare(shp, tgt) is False:
            return
        pos_list = [om.MVector(-1 * vec.x, vec.y, vec.z) for vec in mvec.get_vectorlist(shp, ws=ws)]

        for cv, pos in zip(cmds.ls(tgt + type_dict[cmds.objectType(shp)], fl=True), pos_list):
            cmds.xform(cv, ws=ws, os=not ws, a=True, t=pos)


def copy_shape(src, *tgts, **kwargs):
    ws = kwargs.get('ws', True)

    type_dict = {'nurbsCurve': '.cv[*]',
                 'nurbsSurface': '.cv[*][*]',
                 'mesh': '.vtx[*]',
                 'lattice': '.pt[*][*][*]'
                 }

    shape_list = _get_deformable_shapes(src.name())
    if shape_list is None:
        return

    for shp in shape_list:
        pos_list = mvec.get_vectorlist(shp, ws=ws)
        shp_type = cmds.objectType(shp)
        for tgt in tgts:
            # get the mirror name
            tgt_shapes = _get_deformable_shapes(tgt.name())
            for tgt_shp in tgt_shapes:
                try:
                    if not cmds.shapeCompare(shp, tgt_shp) is False:
                        components = cmds.ls(tgt_shp + type_dict[shp_type], fl=True)
                        for component, pos in zip(components, pos_list):
                            cmds.xform(component, ws=ws, os=not ws, a=True, t=pos)
                    else:
                        print "FUCK"

                except RuntimeError:
                    print "FAILED"
                    pass


def copy_shapenode(shp, obj_list, **kwargs):
    if isinstance(obj_list, pm.PyNode):
        obj_list = [obj_list]
    shpType = kwargs.get('shpType', 'nurbsCurve')
    for obj in obj_list:
        namer = mname.Name(obj)
        tmp = shp.duplicate(rc=True)[0]
        newShp = tmp.getShape(type=shpType)
        pm.parent(newShp, obj, add=True, s=True)
        if kwargs.get('suffix'):
            newName = namer.replace(suffix=kwargs['suffix']) + 'Shape'
        elif namer.suffix == 'CTRL':
            newName = namer.replace(suffix='CTRL') + 'Shape'
        else:
            newName = namer.replace(suffix=TYPE_SUFFIX_DICT[shpType]) + 'Shape'
        newShp.rename(newName)
        pm.delete(tmp)
    return newShp


def set_override_color(node_list, color, shpType='shape'):
    ''' Sets the shapeColor of any given nodes '''
    for node in node_list:
        if node.type() != "locator":
            shp_list = node.getShapes(type=shpType)
            for shp in shp_list:
                try:
                    shp.overrideEnabled.set(True)
                    shp.overrideColor.set(color)
                except Exception as e:
                    print str(e)


def match_rebuildcurve(src, tgt):
    '''
    Looks for rebuildCurve-node and matches all parameters to the given src-nurbsCurve.
    This is useful for the case if a references node needs to match a nurbscurve in a scene.
    '''
    src_shp = src.getShape(type='nurbsCurve')
    tgt_shp = tgt.getShape(type='nurbsCurve')
    if src_shp and tgt_shp:
        try:
            rb_crv = tgt.create.inputs()[0]
        except IndexError:
            pm.warning("no rebuildCurve-Node found")
            return
        for attr in ['spans', 'degree']:
            rb_crv.attr(attr).set(src_shp.attr(attr).get())
        for src_cv, tgt_cv in zip(src_shp.comp('cv'), tgt_shp.comp('cv')):
            xyz = src_cv.getPosition(space='world')
            tgt_cv.setPosition(xyz, space='world')


def set_override_displaytype(node_list, displayType, shpType='shape'):
    '''
    Sets the displayType('normal','template','reference') of any given nodes
    '''
    for node in node_list:
        shp_list = node.getShapes(type=shpType)
        for shp in shp_list:
            shp.overrideEnabled.set(True)
            shp.overrideDisplayType.set(displayType)


def add_locatorshape(obj, hidden=True):
    '''
    adds a locatorshape to obj
    if hidden is True the locatorshape will be hidden
    '''
    namer = mname.Name(obj)
    shp = pm.createNode('locator', name=namer.replace(suffix='LOC'), p=obj)
    shp.visibility.set(not hidden)
    return shp


def add_instanced_shape(shp, obj_list):
    for obj in obj_list:
        try:
            shp_list = obj.getShapes()
            if shp not in shp_list:
                pm.parent(shp, obj, s=True, add=True)
        except RuntimeError:
            pass


def get_componentlist(obj, flatten=False):
    '''
    Get the componentList of the selected object (based on its type)
    If the object is a PyNode, return a PyNode comp list (Very slow!)
    Else, just return a normal maya.cmds list (Faster)
    @flatten = return a flattent list instead of a sliced one. eg: list[0:3600]
    '''
    toPyNode = False
    if isinstance(obj, pm.PyNode):
        toPyNode = True
    else:
        obj = pm.PyNode(obj)
    if pm.objectType(obj, isAType='deformableShape'):
        shp = obj
    else:
        shp = obj.getShape(type='deformableShape')
    shpType = shp.type()
    if shpType in COMPONENT_DICT:
        compList = cmds.ls(shp.name() + ".%s[*]" % COMPONENT_DICT[shpType], flatten=flatten)
    if toPyNode:
        compList = shp.comp(COMPONENT_DICT[shpType])
    return compList


# =============================================================================
# Non-Public Functions --------------------------------------------------------
# =============================================================================

def _rotate_vectors(vectors, aim, up):
    """
    rotates the pos list from the default +y/+z orientation
    returns a vector list
    """
    # build matrix
    aim_vec = mvec.get_axis_vector(aim)
    up_vec = mvec.get_axis_vector(up)

    # catch input errors
    if aim_vec == up_vec:
        pm.warning("Aim and Up vectors are the same, ignoring shape rotate")
        return vectors

    aim_matrix = om.MTransformationMatrix(mmtrx.get_aim_matrix(None, aim_vec, up_vec, "+y", "+z"))
    quat = aim_matrix.rotation()

    return [vec.rotateBy(quat) for vec in vectors]


def _scale_vectors(vectors, scale):
    """
    scales the vectors
    """
    out = []
    if isinstance(scale, (float, int)):
        for vec in vectors:
            out.append(vec * scale)
    elif isinstance(scale, om.MVector):
        for vec in vectors:
            out.append(mvec.mult_vector_by_vector(vec, scale))
    elif isinstance(scale, (tuple, list)):
        scale = om.MVector(scale)
        for vec in vectors:
            out.append(mvec.mult_vector_by_vector(vec, scale))
    else:
        raise ValueError('Scale-value must be of type Float, Int,  Tuple, List or MVector.')
    return out


def _translate_vectors(vectors, offset):
    """
    translate the vectors
    """
    if offset is not None:
        out = []
        for vec in vectors:
            out.append(vec + offset)
        return out
    else:
        return vectors


def _get_deformable_shapes(node):
    if cmds.objectType(node, isType="locator"):
        return
    if cmds.objectType(node, isAType="deformableShape"):
        return [node]
    else:
        return cmds.listRelatives(node, shapes=True, type='deformableShape')
    
