
"""
.. module:: matrix
   :synopsis: API 2.0 transformation-matrix related functions

.. moduleauthor:: andreasg, petera
"""


# maya imports
import maya.api.OpenMaya as om
import maya.cmds as cmds
import pymel.core as pm
import math

# package imports
from millrigger.globals import rig as RIG
from millrigger.utils import nurbs as mnrbs
from millrigger.utils import vector as mvec
from millrigger.utils import maths as mmaths
from millrigger.utils import api as mapi

IDENTITY_MATRIX = om.MMatrix()
NEG_SCALE_X_MATRIX = om.MMatrix([-1, 0, 0, 0,
                                 0, 1, 0, 0,
                                 0, 0, 1, 0,
                                 0, 0, 0, 1])
# for convienience
MMatrix = om.MMatrix


def get_matrix(node, ws=True):
    """ Returns the MMatrix transform of the given node

    :param node: The node you need the matrix of
    :type node: PyNode

    :param ws: Whether to use worldspace transformation
    :type ws: Boolean
    """
    if not isinstance(node, basestring):
        node = node.name()
    return om.MMatrix(cmds.xform(node, q=True, m=True, ws=ws))


def set_matrix(node, matrix, ws=True):
    """ Sets the MMatrix transform on the given node

    :param node: The node you're setting the transform of
    :type node: PyNode

    :param ws: Whether to use worldspace transformation
    :type ws: Boolean
    """
    if not isinstance(node, basestring):
        node = node.name()
    cmds.xform(node, m=matrix_to_list(matrix), ws=ws)


def matrix_to_list(matrix):
    """ convert MMatrix to list of floats

    :param matrix: Converts the given matrix to float list
    :type matrix: Matrix
    """
    if isinstance(matrix, om.MTransformationMatrix):
        matrix = matrix.asMatrix()
        return [value for value in matrix]

    elif isinstance(matrix, om.MMatrix):
        return [item for item in matrix]

    elif isinstance(matrix, pm.datatypes.Matrix):
        out = []
        for row in matrix:
            for column in row:
                out.append(column)
        return out

    elif isinstance(matrix, list):
        return matrix

    else:
        print matrix
        raise ValueError("matrix is of type '%s', not implemented" % type(matrix))


def vectors_to_matrix(vector1=om.MVector(1, 0, 0), vector2=om.MVector(0, 1, 0), vector3=om.MVector(0, 0, 1),
                      vector4=om.MVector(0, 0, 0)):
    """ convert 4 vector3s to 4x4 matrix

    :param vector1: Vector for the first row (X Axis Aim)
    :type vector1: Vector

    :param vector2: Vector for the second row (Y Axis Aim)
    :type vector2: Vector

    :param vector3: Vector for the third row (Z Axis Aim)
    :type vector3: Vector

    :param vector4: Vector for the fourth row (Translation)
    :type vector4: Vector
    """
    # check for lists:
    vector1 = mvec.get_as_mvector(vector1)
    vector2 = mvec.get_as_mvector(vector2)
    vector3 = mvec.get_as_mvector(vector3)
    vector4 = mvec.get_as_mvector(vector4)

    val_list = [vector1.x, vector1.y, vector1.z, 0,
                vector2.x, vector2.y, vector2.z, 0,
                vector3.x, vector3.y, vector3.z, 0,
                vector4.x, vector4.y, vector4.z, 1]
    return om.MMatrix(val_list)


def get_aim_matrix(base_vec, aim_pos, up_pos, aim_axis='+x', up_axis='+z',
                   relative=False):
    """creates a transformation-matrix in the way that an aimConstraint would

    :param base_vec: position of the base in worldspace
    :type base_vec: Vector

    :param aim_pos: aim-position in worldspace
    :type aim_pos: Vector

    :param up_pos: up-position in worldspace
    :type up_pos: Vector

    :param aim_axis: the aim_vector direction of the matrix.
                     Values: '+x','+y','+z','-x','-y','-z'
    :type aim_axis: string

    :param up_axis: the up_vector direction of the matrix.
                    Values: '+x','+y','+z','-x','-y','-z'
    :type up_axis: string

    :param relative: If checked the aim and upvectors are not world-space
                     but relative to base-vec
    :type relative: Boolean

    :rType: MMatrix
    """
    if base_vec is None:
        base_vec = om.MVector.kZeroVector

    if relative:
        aim_vec = aim_pos.normal()
        up_vec = up_pos.normal()
    else:
        aim_vec = (aim_pos - base_vec).normal()
        up_vec = (up_pos - base_vec).normal()

    tangent_vec = (aim_vec ^ up_vec).normal()
    up_vec = (tangent_vec ^ aim_vec).normal()

    if aim_axis[-1] == up_axis[-1]:
        raise AttributeError('aim_axis "%s" and up_axis "%s" need to be different!' % (aim_axis, up_axis))

    aim_vec, up_vec, tangent_vec = _reorder_aim_axis(aim_vec,
                                                     up_vec,
                                                     tangent_vec,
                                                     aim_axis,
                                                     up_axis
                                                     )
    return vectors_to_matrix(aim_vec, up_vec, tangent_vec, base_vec)


def get_aim_vector(matrix, axis):
    """Get the worldspace-Vector of the objects axis

    :param matrix: api 2.0 Matrix
    :type matrix: MMatrix

    :param axis: The aim-axis.
                 Values: '+x','+y','+z','-x','-y','-z'
    :type axis: string

    :rType: MVector
    """

    """
    pos_matrix = om.MTransformationMatrix(matrix)
    aim_matrix = om.MTransformationMatrix(matrix)
    pos = pos_matrix.translation(om.MSpace.kWorld)
    aim_matrix.translateBy(om.MVector(RIG.STR_TO_VEC_SWITCH[axis]),
                           om.MSpace.kPreTransform
                           )
    aim = aim_matrix.translation(om.MSpace.kWorld)
    return aim - pos
    """

    if "x" in axis.lower():
        x = om.MVector(matrix[0], matrix[1], matrix[2])
        if axis.startswith("-"):
            return x * -1
        else:
            return x

    if "y" in axis.lower():
        y = om.MVector(matrix[4], matrix[5], matrix[6])
        if axis.startswith("-"):
            return y * -1
        else:
            return y

    if "z" in axis.lower():
        z = om.MVector(matrix[8], matrix[9], matrix[10])
        if axis.startswith("-"):
            return z * -1
        else:
            return z


def get_mirror_matrix(matrix, mirrorplane='YZ', flip=False):
    """Creates a transformation-matrix for mirror-behaviour

    :param matrix: matrix
    :type matrix: MMatrix

    :param aim_axis: the aim_vector direction of the matrix.
                     Values: '+x','+y','+z','-x','-y','-z'
    :type aim_axis: string

    :param mirrorplane: the aim_vector direction of the matrix.
                     Values: 'XY','XZ','YZ'
    :type mirrorplane: string

    :rType: MMatrix

    """

    mult_dict = {'XY': (1, 1, -1),
                 'XZ': (1, -1, 1),
                 'YZ': (-1, 1, 1)}

    tmatrix = to_tmatrix(matrix)
    mirror_vec = om.MVector(mult_dict[mirrorplane])
    base_vec = mvec.mult_vector_by_vector(tmatrix.translation(om.MSpace.kWorld),
                                          mirror_vec
                                          )
    aim_vec = mvec.mult_vector_by_vector(get_aim_vector(matrix, '+x'),
                                         mirror_vec
                                         )
    up_vec = mvec.mult_vector_by_vector(get_aim_vector(matrix, '-z'),
                                        mirror_vec
                                        )
    if flip is True:
        up_vec = up_vec * -1.0
    tangent_vec = (up_vec ^ aim_vec).normal()  # reversed
    up_vec = (tangent_vec ^ aim_vec).normal()
    return vectors_to_matrix(-aim_vec, -tangent_vec, -up_vec, base_vec)


def get_reflect_matrix(matrix):
    """
     Creates a MMatrix for mirroring with no inverse scaling,just with
     the facing rotated to face the other direction.

    :param matrix: matrix
    :type matrix: MMatrix
    """
    flip = om.MMatrix([-1.0, 0.0, 0.0, 0.0,
                       0.0, 1.0, 0.0, 0.0,
                       0.0, 0.0, 1.0, 0.0,
                       0.0, 0.0, 0.0, 1.0]
                      )

    matrix = matrix * flip
    rows = get_matrix_rows(matrix)
    rows[2] = rows[2] * -1
    return vectors_to_matrix(*rows)


def get_reflect_aim_matrix(matrix, axis="x"):
    """
     Creates a MMatrix for mirroring with no inverse scaling,just with
     the facing rotated to face the other direction.

    :param matrix: matrix
    :type matrix: MMatrix
    """
    x = -1.0 if "x" in axis else 1.0
    y = -1.0 if "y" in axis else 1.0
    z = -1.0 if "z" in axis else 1.0
    flip = om.MMatrix([x, 0.0, 0.0, 0.0,
                       0.0, y, 0.0, 0.0,
                       0.0, 0.0, z, 0.0,
                       0.0, 0.0, 0.0, 1.0]
                      )

    matrix = flip * matrix * flip

    return matrix


def get_position_matrix(x=0.0, y=0.0, z=0.0, vector=None):
    """ Creates a matrix that just holds translation data

    :param x: Value for X
    :type x: float
    :param y:Value for Y
    :type y: float
    :param z:Value for Z
    :type z: float

    :rType: MMatrix
    """
    if vector is not None:
        return om.MMatrix([1, 0, 0, 0,
                           0, 1, 0, 0,
                           0, 0, 1, 0,
                           vector.x, vector.y, vector.z, 1])
    else:
        return om.MMatrix([1, 0, 0, 0,
                           0, 1, 0, 0,
                           0, 0, 1, 0,
                           x, y, z, 1])


def get_rotation_matrix(x=0.0, y=0.0, z=0.0, vector=None, ro='xyz'):
    """ Creates a matrix that just holds rotation data

    :param x: Value for X
    :type x: Float
    :param y:Value for Y
    :type y: Float
    :param z:Value for Z
    :type z: Float
    :param ro: "xyz"
    :type ro: String

    :rType: MMatrix
    """

    ro_index = RIG.ROTATIONORDER_SWITCH[ro]
    vector = vector or [x, y, z]
    if isinstance(vector, om.MVector):
        vector = [vector.x, vector.y, vector.z]
    values = [math.radians(val) for val in vector]
    rot_matrix = om.MEulerRotation(values, order=ro_index).asMatrix()
    return rot_matrix


def get_posvector(matrix):
    if isinstance(matrix, pm.PyNode):
        matrix = get_matrix(matrix)
    return om.MVector(matrix[-4], matrix[-3], matrix[-2])


def get_average_posvector(*matrices):
    """ get average position vector based on matrices

    :param matrices: list of matrices
    :type matrices: List of MMatrix

    :rType: MVector
    """
    count = 0
    pos = om.MVector(0.0, 0.0, 0.0)

    for mtrx in matrices:
        pos += get_posvector(mtrx)
        count += 1

    return pos / count


def extract_position_matrix(matrix):
    """ extracts a matrix that just holds translation data

    :param x: matrix
    :type x: MMatrix

    :rType: MMatrix
    """
    matrix = to_mmatrix(matrix)
    return om.MMatrix([1, 0, 0, 0,
                      0, 1, 0, 0,
                      0, 0, 1, 0,
                      matrix[-4], matrix[-3], matrix[-2], 1])


def extract_rotation_matrix(matrix):
    """ extracts a matrix that just holds rotation data

    :param x: matrix
    :type x: MMatrix

    :rType: MMatrix
    """
    matrix = to_mmatrix(matrix).asRotateMatrix()
    return to_mmatrix(matrix)


def matrix_distance(a, b):
    """ returns distance between 2 matrices

    :param a, b: matrix
    :type a, b: MMatrix

    :rType: Float
    """
    dist = (get_posvector(a) - get_posvector(b)).length()
    return dist


def matrices_on_curve_upvector(curve, param_list=None, num_ctrls=None,
                               up_vec=om.MVector.kYaxisVector, aim_axis='+x',
                               up_axis='+z', inherit_up=False):
    """creates list of ,matrices on a curve like a splineik jointchain

    :param curve:
    :type curve: PyNode

    :param param_list:
    :type param_list: list of floats

    :param num_ctrls:
    :type num_ctrls: list of floats

    :param up_vec:
    :type up_vec: MVector

    :param aim_axis:
    :type aim_axis: String

    :param up_axis:
    :type up_axis: String

    :param inherit_up:
    :type inherit_up: Boolaen

    :rType: list of MMatrices

    .. note::
        last matrix has same rotation as previous (no aim)

    matrixlist_on_curve

    """
    # check values
    if param_list is None and num_ctrls is None:
        raise ValueError("Either param_list or num_ctrls must be given")
    elif param_list is not None and num_ctrls is not None:
        raise ValueError("Only one of param_list or num_ctrls must be given")

    # make a new param list, if required
    if num_ctrls is not None:
        param_list = mmaths.linspace(start=0, end=1, num=num_ctrls)

    # make the vectors for the positions
    def vec_on_crv(param):
        pnt = mnrbs.point_on_curve_position(curve, param, True)
        return om.MVector(pnt)

    pos_vec_list = map(vec_on_crv, param_list)

    # make the aim vectors from the positions
    aim_vec_list = []
    for i in range(len(pos_vec_list) - 1):
        aim_vec = pos_vec_list[i + 1] - pos_vec_list[i]
        aim_vec_list.append(aim_vec)

    # the last aim will be the same as the previous
    aim_vec_list.append(aim_vec_list[-1])

    matrices = []
    for pos_vec, aim_vec in zip(pos_vec_list, aim_vec_list):
        matrix = get_aim_matrix(pos_vec,
                                aim_vec,
                                up_vec,
                                aim_axis,
                                up_axis,
                                relative=True
                                )
        if inherit_up is True:
            up_vec = get_aim_vector(matrix, up_axis)
        matrices.append(matrix)
    return matrices


def matrices_along_curve(curve,
                         samples=None,
                         start_matrix=None,
                         end_matrix=None,
                         use_percentage=False):
    """
    Creates list of matrices positioned along the given curve.
    The orientation of those matrices are blended between the given matrices
    :param curve: nurbsCurve
    :type curve: PyNode

    :param samples: list of curve-parameters or percentages (0.0 to 1.0)
    :type samples: list of floats

    :param start_matrix:
    :type start_matrix: MMatrix

    :param end_matrix:
    :type end_matrix: MMatrix

    :param use_percentage: use samples as percentages instead of parameter-values
    :type use_percentage: Boolean

    :rType: list of MMatrices
    """
    # check values
    if samples is None:
        raise ValueError("Samples are missing")
    elif start_matrix is None and end_matrix is None:
        raise ValueError("Need at least one matrix for start- or end-matrix")
    # make a new param list, if required
    if isinstance(samples, int):
        samples = mmaths.linspace_float(start=0, end=1, num=samples)

    # check for shapenode:
    node_type = curve.type()
    if node_type == "nurbsCurve":
        curve_shape = curve
    elif node_type == "transform":

        curve_shape = curve.getShape(type="nurbsCurve")

    # invalid parameters
    if not curve_shape:
        pm.warning("NurbsCurveShape needed!")
        return

    # convert parameter-values into percentage along curve
    if use_percentage:
        samples[:] = [mnrbs.percentage_to_param(curve_shape, sample) for sample in samples]

    # make the vectors for the positions
    def vec_on_crv(param):
        pnt = mnrbs.point_on_curve_position(curve_shape, param, True)
        return om.MVector(pnt)

    pos_vec_list = map(vec_on_crv, samples)
    pos_matrices = [get_position_matrix(vector=vec) for vec in pos_vec_list]
    ori_matrices = matrix_blend_samples(start_matrix, end_matrix, samples=samples, connect='r')
    matrices = [match_position(ori, pos) for ori, pos in zip(ori_matrices, pos_matrices)]
    return matrices


def get_matrix_on_surface(nrb, u=0.5, v=0.5, u_axis='+x', v_axis='+y', axis='u'):
    """
    return matrix for given UVs on nurbsSurface
    :param nrb: nurbsSurface
    :type nrb: PyNode

    :param u: U value
    :param v: V_value
    :param u_axis: xyz-axis to aim along u-axis
    :param v_axis: xyz-axis to aim along v-axis
    :param axis: use "u" or "v" as dominant axis
    :return: MMatrix
    """
    mobj = mapi.get_mobject(nrb.name())
    mnrb = om.MFnNurbsSurface(mobj)
    mpnt = mnrb.getPointAtParam(u, v)
    u_tangent, v_tangent = mnrb.tangents(u, v)
    if axis == 'v':
        mtx = get_aim_matrix(om.MVector(mpnt), v_tangent, u_tangent, aim_axis=v_axis, up_axis=u_axis,
                             relative=True)
    else:
        mtx = get_aim_matrix(om.MVector(mpnt), u_tangent, v_tangent, aim_axis=u_axis, up_axis=v_axis,
                             relative=True)
    return mtx


def to_tmatrix(matrix):
    """ Converts a matrix to an api2.0 Transformation Matrix

    :param matrix: Of any supported type
    :type matrix: MTransformationMatrix/MMatrix

    :rType: om.MTransformationMatrix
    """
    if isinstance(matrix, pm.datatypes.Matrix):
        return om.MTransformationMatrix(om.MMatrix(matrix))

    elif isinstance(matrix, om.MTransformationMatrix):
        return matrix

    elif isinstance(matrix, om.MMatrix):
        return om.MTransformationMatrix(matrix)

    else:
        ValueError("%s matrix is not of supported." % type(matrix))


def to_mmatrix(matrix):
    """ Converts a matrix to an api2.0 MMatrix

    :param matrix: Of any supported type
    :type matrix: pm.Matrix/MTransformationMatrix/MMatrix

    :rType: om.MMatrix
    """
    if isinstance(matrix, pm.datatypes.Matrix):
        return om.MMatrix(matrix)

    elif isinstance(matrix, om.MTransformationMatrix):
        return matrix.asMatrix()

    elif isinstance(matrix, om.MMatrix):
        return matrix

    else:
        ValueError("%s matrix is not of supported." % type(matrix))


def get_offset_matrix(source_matrix, target_matrix):
    """ Returns matrix that defines the offset of source and target-matrix

    :param source_matrix: Of any supported type
    :type source_matrix: Matrix

    :param target_matrix: Of any supported type
    :type target_matrix: Matrix

    :rType: om.MMatrix
    """
    source_matrix = source_matrix.inverse()
    return target_matrix * source_matrix


def get_matrix_rows(matrix):
    """
    Returns a list of 4 vectors, one for each row of the given matrix

    :param matrix: Matrix to fit
    :type matrix: MMatrix
    """
    if not isinstance(matrix, om.MMatrix):
        matrix = to_mmatrix(matrix)
    row0 = om.MVector(matrix[0], matrix[1], matrix[2])
    row1 = om.MVector(matrix[4], matrix[5], matrix[6])
    row2 = om.MVector(matrix[8], matrix[9], matrix[10])
    pos = om.MVector(matrix[12], matrix[13], matrix[14])
    return [row0, row1, row2, pos]


def get_matrix_axis(matrix, axis):
    """
    Returns a Vector for the given axis of the matrix

    :param matrix: Matrix
    :type matrix: MMatrix

    :param axis: The axis to return
    :type axis: String
    """
    rows = get_matrix_rows(matrix)
    axis_switch = {"x": 0, "y": 1, "z": 2}

    # get the row we need
    vector = rows[axis_switch[axis.lower()[-1]]]
    if axis[0] == "-":
        vector = vector * -1
    return vector


def fit_matrix_orientation(matrix, ori_matrix):
    """
    Takes a matrix and fits it's orientation to a given matrix. Essentially this switches round the rows so,
    for example the y axis, is put in the row that's closest to the y_axis of the ori_matrix

    :param matrix:
    :param ori_matrix:
    :return:
    """
    # get the rows from the matrices
    row_x, row_y, row_z, pos = get_matrix_rows(matrix)
    rows = [row_x, row_y, row_z]
    ori_row_x, ori_row_y, ori_row_z, ori_pos = get_matrix_rows(ori_matrix)

    # get the one that's closest to y
    dots = map(lambda v: abs(v * ori_row_y), rows)
    y_vec = rows.pop(dots.index(max(dots)))

    # invert the y, if needed
    if y_vec * ori_row_y < 0.0:
        y_vec = y_vec * -1

    # get the one that's closest to x
    dots = map(lambda v: abs(v * ori_row_x), rows)
    x_vec = rows.pop(dots.index(max(dots)))

    # invert the x, if needed
    if x_vec * ori_row_x < 0.0:
        x_vec = x_vec * -1

    # use a cross to get the last one
    z_vec = x_vec ^ y_vec
    return vectors_to_matrix(x_vec, y_vec, z_vec, pos)


def fit_matrix_to_world(matrix):
    """
    Takes a matrix and tries to 'best fit' it to the world matrix.
    This means that the axies will be reordered (and inverted, if needed) to be
    x being to the closest right, y being closest up and so on.

    :param matrix: Matrix to fit
    :type matrix: MMatrix
    """
    return fit_matrix_orientation(matrix=matrix, ori_matrix=om.MMatrix())


def match_position(ori_matrix=om.MMatrix(), pos_matrix=om.MMatrix()):
    """
    Makes a new matrix with the ori of one and the pos of another

    :param ori_matrix: Matrix to take the ori from
    :type ori_matrix: MMatrix

    :param pos_matrix: Matrix to take the pos from
    :type pos_matrix: MMatrix
    """
    ori_rows = get_matrix_rows(ori_matrix)
    pos_rows = get_matrix_rows(pos_matrix)
    new_rows = [ori_rows[0], ori_rows[1], ori_rows[2], pos_rows[3]]
    return vectors_to_matrix(*new_rows)


def _reorder_aim_axis(aim_vec, up_vec, tangent_vec, aim_axis, up_axis):

    if aim_axis[-1] != up_axis[-1]:

        if aim_axis[0] == '-':
            aim_vec, tangent_vec = -aim_vec, -tangent_vec
        if up_axis[0] == '-':
            up_vec, tangent_vec = -up_vec, -tangent_vec

        if aim_axis[-1] == 'x':
            if up_axis[-1] == 'y':
                aim_vec, up_vec, tangent_vec = aim_vec, up_vec, tangent_vec
            elif up_axis[-1] == 'z':
                aim_vec, up_vec, tangent_vec = aim_vec, -tangent_vec, up_vec

        elif aim_axis[-1] == 'y':
            if up_axis[-1] == 'x':
                aim_vec, up_vec, tangent_vec = up_vec, aim_vec, -tangent_vec
            if up_axis[-1] == 'z':
                aim_vec, up_vec, tangent_vec = tangent_vec, aim_vec, up_vec

        elif aim_axis[-1] == 'z':
            if up_axis[-1] == 'x':
                aim_vec, up_vec, tangent_vec = up_vec, tangent_vec, aim_vec
            if up_axis[-1] == 'y':
                aim_vec, up_vec, tangent_vec = -tangent_vec, up_vec, aim_vec
    return aim_vec, up_vec, tangent_vec


def get_as_mvector(vector):
    """ just as convenience as it is often needed for lot of matrix-actions """
    return mvec.get_as_mvector(vector)


def normal_axis(aim_axis='+x', up_axis='+y', as_vector=False):
    """ just as convenience as it is often needed for lot of matrix-actions """
    return mvec.normal_axis(aim_axis=aim_axis, up_axis=up_axis, as_vector=as_vector)


def get_match_matrix_from_axies(matrix, x_axis=None, y_axis=None, z_axis=None):
    """
    From the given matrix, return a new one with the new row order
    """
    matrix_rows = get_matrix_rows(matrix)
    row_select = {"x": 0, "y": 1, "z": 2}

    # check axies
    for each in [x_axis, y_axis, z_axis]:
        if each is not None:
            break
    else:
        return matrix

    if [x_axis, y_axis, z_axis].count(None) > 1:
        raise ValueError("Needs at least two axies out of x, y, z")

    # get x axis
    if x_axis is not None:
        x_vec = matrix_rows[row_select[x_axis[-1]]]
        if x_axis.startswith("-"):
            x_vec = x_vec * -1
    else:
        x_vec = None

    # get y axis
    if y_axis is not None:
        y_vec = matrix_rows[row_select[y_axis[-1]]]
        if y_axis.startswith("-"):
            y_vec = y_vec * -1
    else:
        y_vec = None

    # get z axis
    if z_axis is not None:
        z_vec = matrix_rows[row_select[z_axis[-1]]]
        if z_axis.startswith("-"):
            z_vec = z_vec * -1
    else:
        z_vec = None

    # get the remaining axis, if needed, from the cross product of the other two
    new_rows = [x_vec, y_vec, z_vec]
    for i, row in enumerate(new_rows):
        if row is None:
            ids = [0, 1, 2]
            ids.pop(i)
            new_rows[i] = new_rows[ids[0]] ^ new_rows[ids[1]]

    # add the existing translate
    new_rows.append(matrix_rows[-1])
    return vectors_to_matrix(*new_rows)


def add_offset_to_matrix(matrix, offset=om.MVector(0, 0, 1)):
    """
    add offset in local-space to matrix
    """
    offset = get_as_mvector(offset)
    offset_matrix = get_position_matrix(vector=offset)
    return offset_matrix * matrix


def get_offset_rotation(matrix, inverse_matrix=None, ro='xyz'):
    """
    get the offset rotation between 2 matrices and take in account
    the rotateOrder of the target_matrix

    :param matrix: Of any supported type
    :type matrix: MMatrix

    :param inverse_matrix: Of any supported type
    :type inverse_matrix: MMatrix

    :param ro: rotationorder: ('xyz',...)
    :type ro: String

    :rType: eulerrotation-values for xyz in degrees
    """
    ro_index = RIG.ROTATIONORDER_SWITCH[ro] + 1
    if inverse_matrix:
        matrix = get_offset_matrix(inverse_matrix, matrix)
    matrix = to_tmatrix(matrix)
    matrix.reorderRotation(ro_index)
    rot = [math.degrees(val) for val in matrix.rotation()]
    return rot


def blend_matrices(matrix1, matrix2, blend=0.5, connect='srt'):
    """
    blend between 2 transformation-matrixes
    :param matrix1: Of any supported type
    :type matrix1: MMatrix
    :param matrix2: Of any supported type
    :type matrix2: MMatrix
    :param blend: blend-value
    :type blend: float
    :param connect: Which transforms to blend s=scale, r=rotate, t=translate
    :type connect: string
    :rtype: MTransformationMatrix
    """
    matrix1 = to_tmatrix(matrix1)
    matrix2 = to_tmatrix(matrix2)

    out_matrix = om.MTransformationMatrix()

    if 't' in connect:
        trans1 = matrix1.translation(om.MSpace.kWorld)
        trans2 = matrix2.translation(om.MSpace.kWorld)
        out_trans = trans1 * (1.0 - blend) + trans2 * blend
        out_matrix.setTranslation(out_trans, om.MSpace.kWorld)

    if 's' in connect:
        scl1 = get_as_mvector(matrix1.scale(om.MSpace.kWorld))
        scl2 = get_as_mvector(matrix2.scale(om.MSpace.kWorld))
        out_scale = scl1 * (1.0 - blend) + scl2 * blend
        out_matrix.setScale(out_scale, om.MSpace.kWorld)

    if 'r' in connect:
        rot1 = matrix1.rotation(asQuaternion=True)
        rot2 = matrix2.rotation(asQuaternion=True)
        out_rot = om.MQuaternion.slerp(rot1, rot2, blend)
        out_matrix.rotateBy(out_rot, om.MSpace.kWorld)

    return out_matrix


def matrix_blend_samples(matrix1, matrix2, samples=3, start=0.0, end=1.0, connect='srt'):
    """
    create a list of matrices based on the blend between matrix a and b
    :param matrix1: Of any supported type
    :type matrix1: MMatrix
    :param matrix2: Of any supported type
    :type matrix2: MMatrix
    :param samples: amount of samples or list of samples
    :type samples: integer / list of floats
    :param start: first sample-value
    :type start: float
    :param end: last sample-value
    :type end: float
    :param connect: Which transforms to blend s=scale, r=rotate, t=translate
    :type connect: string
    :rtype: MMatrix
    """
    matrices = []
    if isinstance(samples, int):
        samples = mmaths.linspace_float(start, end, num=samples)

    for val in samples:
        matrices.append(blend_matrices(matrix1, matrix2, blend=val, connect=connect))
    return matrices


def point_matrix_multiply(vector, matrix):
    """
    multiply a vector by a matrix
    :param vector: vector to be transposed
    :type vector: MVector
    :param matrix: Of any supported type
    :type matrix: MMatrix
    :rtype: Mvector
    """
    pos_matrix = get_position_matrix(vector=vector)
    out_matrix = pos_matrix * to_mmatrix(matrix)
    return get_posvector(out_matrix)


def clean_scale(matrix):
    """
    makes all scaling positive
    :param matrix: Of any supported type
    :type matrix: MMatrix
    :rtype: MMatrix
    """

    tmatrix = to_tmatrix(matrix).setScale((1, 1, 1), 4)  # 4 == worldspace
    return to_mmatrix(tmatrix)


def get_axis_scaling(matrix):
    """
	extract scaling as integers from matrix
	:param matrix: Of any supported type
	:type matrix: MMatrix
	:rtype: Boolean
	"""
    scale_values = to_tmatrix(matrix).scale(4) # 4 == worldspace
    result = []
    for val in scale_values:
        if val < 0:
            result.append(-1)
        else:
            result.append(1)
    return result


