"""
.. module:: info
   :synopsis: Tools to get information about nodes

.. moduleauthor:: andreasg
"""

# maya imports
import pymel.core as pm
import millrigger.utils.api as mapi
import maya.api.OpenMaya as om

def get_nonlinear_deformertype(node):
    ''' Filter out the type nonlinear deformer as Maya doesn't provide that
    information

    :param node: The node you want to have the information about
    :type node: PyNode

    :rType: String
    '''
    attr_list = pm.listAttr(node)
    if ('curvature' in attr_list):
        return 'bend'
    elif ('startAngle' in attr_list):
        return 'twist'
    elif ('expand' in attr_list):
        return 'squash'
    elif ('curve' in attr_list):
        return 'flare'
    elif ('wavelength' in attr_list):
        if ('minRadius' in attr_list):
            return 'wave'
        else:
            return 'sine'
    else:
        pm.warning('Not a nonlinear deformer: %s' % node.name())
        return None


def get_history_node(node, node_type='geometryFilter'):
    ''' Returns all nodes found in the Nodes contruction-history
    that match the node_type-filter

    :param node: The node you want to have the information about
    :type node: PyNode

    :param node_type: Keyword of the node-type ("geometryFilter" = all deformertypes)
    :type node: String

    :rType: List of Strings
    '''

    history_list = pm.listHistory(node)
    result_list = [obj for obj in history_list if pm.objectType(obj, isAType=node_type)]
    return result_list


def find_related_deformers(node, node_type='geometryFilter'):
    ''' Returns all deformers found in the Nodes contruction-history

    :param node: The node you want to have the information about
    :type node: PyNode

    :param node_type: Keyword of the deformer-type ("geometryFilter" = all deformertypes)
    :type node: String

    :rType: List of String
    '''
    return get_history_node(node, node_type)


def find_related_rivet(node):
    ''' Returns connected rivets to any plug of the Node

    :param node: any Node
    :type node: Transform

    :rType: List of Rivets
    '''
    connections = list(set(pm.ls(node)[0].connections()))
    resultList = [obj for obj in connections if "Rivet" in obj.nodeType()]
    return resultList


def find_side(item, axis='x', ws=False, threshold=0.001):
    ''' Returns the side of an item base on a threshold as a signed integer

    :param item: item of interest
    :type item: Transform or single component

    :param ws: WorldSpace or ObjectSpace
    :type ws: Boolean

    :rType: Integer
    '''
    side_dict = {'x': 0, 'y': 1, 'z': 2}
    pos = pm.xform(item, a=True, ws=ws, os=not ws, q=True, t=True)
    val = pos[side_dict[axis.lower()]]
    if val < -1.0 * threshold:
        return -1
    elif val > threshold:
        return 1
    else:
        return 0


def get_selectiontype(sel):
    """
    return if the given node is a transform, shape or component
    """
    parent_list = ('transform', 'joint')
    if isinstance(sel, list):
        sel = sel[0]

    if '.' in str(sel):
        return 'component'

    elif pm.objectType(sel, isAType='shape'):
        return 'shape'

    elif pm.objectType(sel) in parent_list:
        return pm.objectType(sel)


# def get_nurbssize(nrb, ref_scale=1.0):
#     """
#     Get the arclength-based sidelength in U and V
#
#     :param nrb: The nurbs-surface
#     :type nrb: PyNode
#
#     :param ref_scale: the "global" reference scale
#     :type ref_scale: Float
#
#     :rType: List of Floats
#     """
#     sel = pm.ls(sl=True)
#     result = []
#     spans = (nrb.minMaxRangeV.get()[-1],
#              nrb.minMaxRangeU.get()[-1])
#     for uv, span in zip('vu', spans):
#         xxx = '%s.%s[%s]' % (nrb, uv, 0.5 * span)
#         crv = pm.duplicateCurve(xxx, ch=False, o=True)[0]
#         val = pm.arclen(crv) * ref_scale
#         result.append(val)
#         pm.delete(crv)
#     pm.select(sel, r=True)
#     return result


def get_nurbssize(nrb, ref_scale=1.0):
    """
    Get the arclength-based sidelength in U and V (averaged)

    :param nrb: The nurbs-surface
    :type nrb: PyNode

    :param ref_scale: the "global" reference scale
    :type ref_scale: Float

    :rType: tuple of Floats
    """

    if nrb.type() == 'transform':
        nrb = nrb.getShape(type='nurbsSurface')

    nfn = mapi.get_mfn_nurbssurface(nrb)

    cvs = nfn.cvPositions()

    num_u = nfn.numCVsInU
    num_v = nfn.numCVsInV
    cvs_in_u = [cvs[u * num_v:(u + 1) * num_v] for u in range(num_u)]
    cvs_in_v = [[item[v] for item in cvs_in_u] for v in range(num_v)]

    u_len = 0.0
    v_len = 0.0

    # calculate the average length in V
    for cvs in cvs_in_u:
        cd = om.MFnNurbsCurveData()
        co = cd.create()
        cfn = om.MFnNurbsCurve()
        cfn.create(cvs, nfn.knotsInV(), nfn.degreeInV, 1, False, True, co)
        v_len += cfn.length()
    v_len /= num_u

    # calculate the average length in U
    for cvs in cvs_in_v:
        cd = om.MFnNurbsCurveData()
        co = cd.create()
        cfn = om.MFnNurbsCurve()
        cfn.create(cvs, nfn.knotsInU(), nfn.degreeInU, 1, False, True, co)
        u_len += cfn.length()
    u_len /= num_v

    return tuple([u_len * ref_scale, v_len * ref_scale])
