'''
Functions for any system functionality

Created on 14 May 2015

@author: petera

'''
# maya imports
import maya.cmds as cmds

# package imports
from millrigger.globals import messages as mmsg


def ensure_millSimpleConstraint():
    """Makes sure that the simple constraint plugin is loaded """
    load_plugin("millSimpleConstraint")
    return


def load_plugin(pl_name):
    """ loads the plugin if it isn't already """
    if not cmds.pluginInfo(pl_name, q=True, l=True):
        try:
            cmds.loadPlugin(pl_name)
        except:
            cmds.warning(mmsg.error_no_plugin % pl_name)


def load_plugins(*plugin_list):
    """ loads the plugin if it isn't already """
    for pl_name in plugin_list:
        if not cmds.pluginInfo(pl_name, q=True, l=True):
            try:
                cmds.loadPlugin(pl_name)
            except:
                cmds.warning(mmsg.error_no_plugin % pl_name)
