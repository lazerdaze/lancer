'''
Module containing unbuild functionality

Created on 26 May 2015

@author: petera
'''
# maya imports
import pymel.core as pm

