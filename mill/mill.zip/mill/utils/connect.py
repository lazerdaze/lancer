'''
Created on 29 Apr 2015

@author: petera, andreasg

Module containing functions to deal with connecting elements of a rig
'''

# maya imports
import pymel.core as pm

# package imports
from millrigger.globals import messages as MSG
from millrigger.utils import name as mname
from millrigger.utils.nodes import pairblend as mpair
from millrigger.utils.nodes import matrixblend as mblnd
from millrigger.utils.nodes import constraints as mcon
from millrigger.objects import rigobject as rigobj


def parent_chain_together(nodes):
    """ parents the list of nodes above each other in order

    :param nodes: List of maya nodes to parent together
    :type nodes: list of PyNodes
    """
    for i in range(1, len(nodes)):
        pm.parent(nodes[i], nodes[i - 1])
    return


def simple_constrain_chains(sources, targets, connect="srt"):
    """ constrain the two chains together

    :param sources:List of maya nodes to drive the target chain
    :type sources: list of PyNodes

    :param targets:List of maya nodes to be driven
    :type targets: list of PyNodes

    :param connect: Which transforms to connect s=scale, r=rotate, t=translate
    :type connect: string
    """
    sources = _get_full_chain(sources)
    targets = _get_full_chain(targets)
    check_lengths(sources, targets)

    # connect the items
    for source, target in zip(sources, targets):
        if source is None and target is None:
            continue
        mcon.create_simple_constraint(source, target, connect=connect)
    return


def blend_chains(sources1, sources2, targets, blend_attr, connect="srt", use_matrix_blend=False):
    """

    :param sources1: First list of maya nodes to drive the target chain
    :type sources1: list of PyNodes

    :param sources2: Second list of maya nodes to drive the target chain
    :type sources2: list of PyNodes

    :param targets: List of maya nodes to be driven
    :type targets: list of PyNodes

    :param blend_attr: Attribute that drives the blend
    :type blend_attr: Float Attribute

    :param connect: Which transforms to connect s=scale, r=rotate, t=translate
    :type connect: string

    :rtype: list of pairblends
    """
    sources1 = _get_full_chain(sources1)
    sources2 = _get_full_chain(sources2)
    targets = _get_full_chain(targets)
    check_lengths(sources1, sources2, targets)

    blends = []
    for source1, source2, target in zip(sources1, sources2, targets):
        if source1 is None and source2 is None or target is None:
            continue

        if source1 != target and source2 != target:  # special case of setup
            if use_matrix_blend:
                if source1 is not None:
                    source1 = source1.matrix
                if source2 is not None:
                    source2 = source2.matrix
                matrix = mblnd.MatrixBlend(name=None,
                                           source1=source1,
                                           source2=source2,
                                           target=target,
                                           blend=blend_attr,
                                           connect=connect
                                           )
            else:
                pblnd = mpair.PairBlend(name=None,
                                        source1=source1,
                                        source2=source2,
                                        target=target,
                                        weight=blend_attr,
                                        connect=connect
                                        )
                pblnd.set_euler(True)
                blends.append(pblnd)
    return blends


def matrix_blend_chains(sources1, sources2, targets, blend_attr, connect="srt", constrain=False):
    """

    :param sources1: First list of maya nodes to drive the target chain
    :type sources1: list of PyNodes

    :param sources2: Second list of maya nodes to drive the target chain
    :type sources2: list of PyNodes

    :param targets: List of maya nodes to be driven
    :type targets: list of PyNodes

    :param blend_attr: Attribute that drives the blend
    :type blend_attr: Float Attribute

    :param connect: Which transforms to connect s=scale, r=rotate, t=translate
    :type connect: string

    :rtype: list of matrixblends
    """
    sources1 = _get_chain_tops(sources1)
    sources2 = _get_chain_tops(sources2)
    targets = _get_chain_tops(targets)
    check_lengths(sources1, sources2, targets)

    blends = []
    for source1, source2, target in zip(sources1, sources2, targets):
        if source1 is None and source2 is None or target is None:
            continue

        if source1 != target and source2 != target:  # special case of setup
            matrix = mblnd.MatrixBlend(name=None,
                                       source1=source1,
                                       source2=source2,
                                       target=target,
                                       blend=blend_attr,
                                       connect=connect,
                                       constrain=constrain
                                       )
            blends.append(matrix)
    return blends


def matrixsum_blend_chains(sources1, sources2, targets, blend_attr, connect="srt"):
    """

    :param sources1: First list of maya nodes to drive the target chain
    :type sources1: list of PyNodes

    :param sources2: Second list of maya nodes to drive the target chain
    :type sources2: list of PyNodes

    :param targets: List of maya nodes to be driven
    :type targets: list of PyNodes

    :param blend_attr: Attribute that drives the blend
    :type blend_attr: Float Attribute

    :param connect: Which transforms to connect s=scale, r=rotate, t=translate
    :type connect: string

    :rtype: list of matrixblends
    """

    check_lengths(sources1, sources2, targets)

    blends = []

    # first blend the roots
    for source1, source2, target in zip(sources1.roots, sources2.roots, targets.roots):
        if source1 is None and source2 is None or target is None:
            continue

        if source1 != target and source2 != target:  # special case of setup
            matrix = mblnd.MatrixBlend(name=None,
                                       source1=source1.matrix,
                                       source2=source2.matrix,
                                       target=target,
                                       blend=blend_attr,
                                       connect=connect,
                                       constrain=False
                                       )
            blends.append(matrix)


    # check for matrixsum:
    for source1, source2, target in zip(sources1, sources2, targets.objs):
        if source1 is None and source2 is None or target is None:
            continue

        if source1 != target and source2 != target:  # special case of setup
            if source1.matrixsum:
                src1 = source1.matrixsum.matrixSum
            else:
                src1 = source1.obj.matrix

            if source2.matrixsum:
                src2 = source2.matrixsum.matrixSum
            else:
                src2 = source2.obj.matrix
            matrix = mblnd.MatrixBlend(name=None,
                                       source1=src1,
                                       source2=src2,
                                       target=target,
                                       blend=blend_attr,
                                       connect=connect,
                                       constrain=False
                                       )
            blends.append(matrix)
    return blends


def link_srt(source, target, attr_list=['t', 'r', 's', 'ro']):
    ''' links a source to a target with a given attribute-list

    :param source: driver object
    :type source: transform

    :param target: driven object
    :type target: transform

    :param attr_list: List of maya attribute names to link
    :type attr_list: List of Strings
    '''
    if source is not None and target is not None:
        for attr in attr_list:
            source.attr(attr) >> target.attr(attr)


def link_hierarchy_by_matrix(source, target, force=False):
    """
    almost the same as a matrix-constraint, but this is only using local matrices
    -> should be very stable

    :param source: driver object
    :type source: rig-object

    :param target: driven object
    :type target: rig-object

    :param force: force creation of multMatrix and decompose even if it is not needed
    :type force: Boolean

    """
    namer = target.namer
    hierarchy = source.hierarchy(existing=True)

    # if only zero and obj exist, just link the attributes instead of creating construct
    print hierarchy
    if force is False and len(hierarchy) < 3:
        target.obj.t >> target.obj.t
        target.obj.r >> target.obj.r
        target.obj.s >> target.obj.s
        return

    mmlt = pm.createNode('multMatrix', name=namer.replace(suffix='multMatrix'))
    mdcp = pm.createNode('decomposeMatrix', name=namer.replace(suffix='decomposeMatrix'))

    for i, item in enumerate(hierarchy[-1:0:-1]):
        item.matrix >> mmlt.matrixIn[i]
    mmlt.matrixSum >> mdcp.inputMatrix

    # it is important that the target has 'xyz' as rotationorder
    target.obj.ro.set(0)
    mdcp.outputTranslate >> target.obj.t
    mdcp.outputRotate >> target.obj.r
    mdcp.outputScale >> target.obj.s
    return


def link_chains(sources, targets, constrain_first=True, connect_list=['t', 'r', 's', 'ro']):
    """  simple constrains the first item in the source, then links the rest

    :param sources:List of maya nodes to drive the target chain
    :type sources: list of PyNodes

    :param targets:List of maya nodes to be driven
    :type targets: list of PyNodes

    :param constrain_first: Whether to constrain the first two items
    :type constrain_first: Boolean
    """
    sources = _get_full_chain(sources)
    targets = _get_full_chain(targets)
    check_lengths(sources, targets)

    # run through the objects, ignoring any Nones
    for source, target in zip(sources, targets):
        if source is None:
            continue

        # constrain the first obj, if wanted
        if constrain_first is True:
            mcon.create_simple_constraint(source, target, snap=True)
            constrain_first = False

        # for each other, connect the transforms
        else:
            link_srt(source, target, attr_list=connect_list)
    return

# =============================================================================
# Non-Public Functions --------------------------------------------------------
# =============================================================================


def _get_full_chain(chain):
    """
    checks for zeros and ofs in the chain
    """
    try:
        return chain.hierarchy(existing=False)
    except AttributeError:
        pass

    if not isinstance(chain, list):
        chain = [chain, ]

    out = []
    for item in chain:
        try:
            out.extend(item.hierarchy(existing=False))
        except AttributeError:
            out.append(item)
    return out


def _get_chain_tops(chain):
    """
    checks for zeros and ofs in the chain
    """
    try:
        return chain.tops
    except AttributeError:
        pass
    #
    # if not isinstance(chain, list):
    #     chain = [chain, ]
    #
    # out = []
    # for item in chain:
    #     try:
    #         out.append(item.top)
    #     except AttributeError:
    #         out.append(item)
    return chain


def check_lengths(*args):
    """ returns true if each item in args has the same length """
    length = len(args[0])
    if not all([len(a) == length for a in args[1:]]):
        for a in args:
            print len(a),
            print "\n"
        raise ValueError(MSG.error_multi_list_size)
