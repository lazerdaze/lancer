"""
.. module:: transform
   :synopsis: functions that deal with dag-transformations

.. moduleauthor:: andreasg
"""

import pymel.core as pm
from millrigger.utils import matrix as mmtrx
from millrigger.utils import vector as mvec


def aim(obj, aim_pos, up_pos, aim_axis='+x', up_axis='+z', plane_type="None",
        preserve_children=True):
    '''rotates object in the way that an aimConstraint would

    :param obj: transform-node to be aimed
    :type obj: Transform

    :param aim_pos: aim-position in worldspace
    :type aim_pos: Vector or Transform

    :param up_pos: up-position in worldspace
    :type up_pos: Vector or Transform

    :param aim_axis: the aim_vector direction of the matrix.
                     Values: 'x','y','z','-x','-y','-z'
    :type aim_axis: string

    :param up_axis: the up_vector direction of the matrix.
                    Values: 'x','y','z','-x','-y','-z'
    :type up_axis: string

    :param plane_type: define the orientation of the up-vector: "None", "Normal" or "Tangent"
    :type plane_type: string

    :param preserve_children: preserves the placement of the children in worldspace
    :type preserve_children: Boolean
    '''

    # store placement of child-objects
    if preserve_children is True:
        children = obj.getChildren(type='transform')
        matrices = [mmtrx.get_matrix(item, ws=True) for item in children]
    else:
        children = []
        matrices = []

    # get vectors
    base_vec = mvec.get_vector(obj)
    aim_pos = mvec.get_vector(aim_pos)
    up_pos = mvec.get_vector(up_pos)

    if plane_type is not None:
        plane_type = plane_type.lower()
        if plane_type in ['normal', 'tangent']:
            if plane_type == 'normal':
                plane_type = 'side'
            up_vec = mvec.polevector(base_vec, aim_pos, up_pos, mode=plane_type)
            up_pos = base_vec + up_vec

    # orient the obj
    aim_matrix = mmtrx.get_aim_matrix(base_vec, aim_pos, up_pos, aim_axis, up_axis, relative=False)
    mmtrx.set_matrix(obj, aim_matrix)

    # restore placement of child-objects
    for item, matrix in zip(children, matrices):
        mmtrx.set_matrix(item, matrix, ws=True)


def chain_aim(chain, aim_axis='+x', up_axis='+z', plane_type="None",
              preserve_children=True, last=True):
    '''
    aim a chain of transforms towards its child while using the up-axis of its parent

    :param chain: list of transform-node to be aimed
    :type chain: list of Transform

    :param aim_axis: the aim_vector direction of the matrix.
                     Values: 'x','y','z','-x','-y','-z'
    :type aim_axis: String

    :param up_axis: the up_vector direction of the matrix.
                    Values: 'x','y','z','-x','-y','-z'
    :type up_axis: String

    :param plane_type: define the orientation of the up-vector: "None", "Normal" or "Tangent"
    :type plane_type: string

    :param last: if checked the last transform will aim towards its parent
    :type last: Boolean
    '''

    # aim the first element of the chain
    aim(chain[0], chain[1], chain[2], aim_axis, up_axis, plane_type, preserve_children)

    # aim chain[1:-1]
    for obj, aim_obj, up_obj in zip(chain[1:], chain[2:], chain):
        # store placement of child-objects
        if preserve_children is True:
            children = obj.getChildren(type='transform')
            matrices = [mmtrx.get_matrix(item, ws=True) for item in children]
        else:
            children = []
            matrices = []

        base_vec = mvec.get_vector(obj)
        aim_pos = mvec.get_vector(aim_obj)
        up_pos = mmtrx.get_aim_vector(mmtrx.get_matrix(up_obj), up_axis) + base_vec

        aim_matrix = mmtrx.get_aim_matrix(base_vec, aim_pos, up_pos,
                                          aim_axis, up_axis,
                                          relative=False)
        mmtrx.set_matrix(obj, aim_matrix)
        # restore placement of child-objects
        for item, matrix in zip(children, matrices):
            mmtrx.set_matrix(item, matrix, ws=True)

    # copy the orientation of chain[-2] to chain[-1]
    if last:
        obj = chain[-1]
        ori = chain[-2]
        # store placement of child-objects
        if preserve_children is True:
            children = obj.getChildren(type='transform')
            matrices = [mmtrx.get_matrix(item, ws=True) for item in children]
        else:
            children = []
            matrices = []

        ori_matrix = mmtrx.get_matrix(ori)
        pos_matrix = mmtrx.get_matrix(obj)

        mmtrx.set_matrix(chain[-1], mmtrx.match_position(ori_matrix, pos_matrix))

        # restore placement of child-objects
        for item, matrix in zip(children, matrices):
            mmtrx.set_matrix(item, matrix, ws=True)


def mirror(source, target, mirrorplane='YZ'):
    '''mirrors a transform based on its aim-axis and the mirror-plane
    to achieve mirrorbehaviour

    :param obj: transform-node to be aimed
    :type obj: Transform

    :param mirrorplane: the aim_vector direction of the matrix.
                     Values: 'XY','XZ','YZ'
    :type mirrorplane: string
    '''

    mtrx = mmtrx.get_matrix(source, ws=True)
    mirror_matrix = mmtrx.get_mirror_matrix(mtrx, mirrorplane)
    mmtrx.set_matrix(target, mirror_matrix, ws=True)


def match(source, targets, connect='srtjp', ws=True):
    '''Match the transforms of the tgtlistList to the source-node

    :param source: transform-node to be matched
    :type source: Transform

    :param targets: transform-nodes that will match the source-transform
    :type targets: Transforms

    :param connect: defaultvalue 'srtjp'. s=scale,
                r=rotation (rotationOrder taken into account),
                t=translation,
                j=jointOrientation for joints,
                p=preferred axis
    :type connect: string

    :param ws: True=worldSpace, False=objectSpace
    :type ws: boolean
    '''

    if isinstance(targets, (basestring, pm.PyNode)):
        targets = [targets, ]

    for target in targets:
        if 'j' in connect:
            if source.type() == 'joint':
                jo = source.jo.get()
                if pm.objectType(target) == 'joint':
                    target.jo.set(jo)

        if 'p' in connect:
            pivotWorldPos = pm.xform(source, ws=True, a=True, q=True, rp=True)
            pm.xform(target, ws=True, a=True, t=pivotWorldPos)

        # if we want all the transforms matched, use the matrix functions
        if 's' in connect and 'r' in connect and 't' in connect:
            rotOrder = source.rotateOrder.get()
            target.rotateOrder.set(rotOrder)
            mmtrx.set_matrix(target, mmtrx.get_matrix(source))

        # otherwise use the standard xform commands
        else:
            if 's' in connect:
                scl = pm.xform(source, r=True, q=True, s=True)
                pm.xform(target, r=True, s=scl)

            if 'r' in connect:
                rotOrder = source.rotateOrder.get()
                ori = pm.xform(source, ws=ws, os=not ws, q=True, ro=True)
                target.rotateOrder.set(rotOrder)
                pm.xform(target, ws=ws, os=not ws, ro=ori)

            if 't' in connect:
                pos = pm.xform(source, ws=ws, a=True, os=not ws, q=True, t=True)
                pm.xform(target, ws=ws, a=True, os=not ws, t=pos)


def zero(obj, connect='srtj'):
    '''
    "zero out" srtj-values by unlocking, setting the value and then restoring
    the original state of the attributes

    :param obj: transform-node to be matched
    :type obj: Transform

    :param connect: defaultvalue 'srtj'
                    s=scale
                    r=rotation (rotationOrder taken into account)
                    t=translation
                    j=jointOrientation for joints
                    p=preferred axis
    :type connect: string
    '''

    connect_dict = {'s': 's', 'r': 'r', 't': 't', 'j': 'jo'}
    state_dict = {}
    if obj.type() != 'joint':
        connect = connect.replace('j', '')

    for attr in connect:
        for axis in ['x', 'y', 'z', '']:
            attribute = connect_dict[attr] + axis
            lock = obj.attr(attribute).isLocked()
            keyable = obj.attr(attribute).isKeyable()
            state_dict.setdefault(attribute, [lock, keyable])
            obj.attr(attribute).unlock()
            obj.attr(attribute).set(k=True)

    for item in connect:
        for axis in 'xyz':
            try:
                obj.attr(connect_dict[attr] + axis).set(item == 's')
            except RuntimeError:
                pass

    for attr in connect:
        for axis in ['x', 'y', 'z', '']:
            attribute = connect_dict[attr] + axis
            lock, keyable = state_dict.get(attribute)
            obj.attr(attribute).set(l=lock)
            obj.attr(attribute).set(k=keyable)


def parent_and_zero(*items):
    '''
    parents and zeros out values in one go

    :param *items: transform-node to be matched
    :type items: Transforms
    '''
    # if we're given a list
    if isinstance(items[0], list):
        items = items[0]

    par = items[-1]
    for item in items[:-1]:
        item.setParent(par)
        zero(item, connect='srtj')
        item.s.set(1, 1, 1)
        item.r.set(0, 0, 0)
        item.t.set(0, 0, 0)
        if item.type() == 'joint':
            item.jo.set(0, 0, 0)


def center_to_boundingbox(obj):
    pm.xform(obj, cp=True)
    par = (pm.listRelatives(obj, parent=True) or [None])[0]
    tmp = mtrns.offset(obj, suffix='TMP')

    pm.makeIdentity(obj, apply=True, t=True, r=True, s=True)
    if par:
        pm.parent(obj, par)
    else:
        pm.parent(obj, w=True)
    pm.delete(tmp)


def average_position(items):
    x, y, z = 0.0, 0.0, 0.0
    for item in items:
        pos = pm.xform(item, a=True, ws=True, q=True, t=True)
        x += pos[0]
        y += pos[1]
        z += pos[2]
    div = len(items)
    x /= div
    y /= div
    z /= div
    return x, y, z
