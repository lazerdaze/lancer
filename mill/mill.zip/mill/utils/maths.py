"""
.. module:: math
   :synopsis: Collection of additional mathematical functions

.. moduleauthor:: andreasg
"""

from pymel.core.datatypes import Vector
from maya.api.OpenMaya import MVector
import numpy as np


def linspace(start, end, num=10, normalize=False):
    '''Creates a list of floats

    :param start: Start-value.
    :type start: Float

    :param end: End-value.
    :type end: Float

    :param num: Number of returned values
    :type num: Int

    :param normalize: Checked >> values will be returned in a range from 0.0 > 1.0
    :type normalize: Boolean

    :rType: List of Floats

    .. note::
        Simplified version of the numpy-linspace.
        We had problems with the Numpy-library in other offices...
    '''

    if isinstance(start, MVector) and isinstance(end, MVector):
        return linspace_MVector(start, end, num=num, normalize=normalize)

    elif isinstance(start, Vector) and isinstance(end, Vector):
        return linspace_Vector(start, end, num=num, normalize=normalize)

    elif isinstance(start, (float, int)) and isinstance(end, (float, int)):
        return linspace_float(float(start), float(end), num=num, normalize=normalize)

    else:
        raise TypeError("start and end must be of types MVector, Vector, flaot, int")


def linspace_float(start, end, num=10, normalize=False):
    '''Creates a list of floats

    :param start: Start-value.
    :type start: Float

    :param end: End-value.
    :type end: Float

    :param num: Number of returned values
    :type num: Int

    :param normalize: Checked >> values will be returned in a range from 0.0 > 1.0
    :type normalize: Boolean

    :rType: List of Floats

    .. note::
        Simplified version of the numpy-linspace.
        We had problems with the Numpy-library in other offices...
    '''

    result_list = list(np.linspace(start, end, num))
    result_list[:] = map(np.asscalar, result_list)

    if normalize:
        result_list[:] = [val / (end - start) for val in result_list]

    return result_list


def linspace_MVector(start, end, num=10, normalize=False):
    '''Creates a list of floats

    :param start: Start-value.
    :type start: MVector

    :param end: End-value.
    :type end: MVector

    :param num: Number of returned values
    :type num: Int

    :param normalize: Checked >> values will be returned in a range from 0.0 > 1.0
    :type normalize: Boolean

    :rType: List of MVectors
    '''

    x_values = linspace_float(start.x, end.x, num=num, normalize=normalize)
    y_values = linspace_float(start.y, end.y, num=num, normalize=normalize)
    z_values = linspace_float(start.z, end.z, num=num, normalize=normalize)
    vector_list = map(MVector, [(x, y, z) for x, y, z in zip(x_values, y_values, z_values)])
    return vector_list


def linspace_Vector(start, end, num=10, normalize=False):
    '''Creates a list of floats

    :param start: Start-value.
    :type start: pymel-Vector

    :param end: End-value.
    :type end: pymel-Vector

    :param num: Number of returned values
    :type num: Int

    :param normalize: Checked >> values will be returned in a range from 0.0 > 1.0
    :type normalize: Boolean

    :rType: List of pymel-Vectors
    '''

    x_values = linspace_float(start.x, end.x, num=num, normalize=normalize)
    y_values = linspace_float(start.y, end.y, num=num, normalize=normalize)
    z_values = linspace_float(start.z, end.z, num=num, normalize=normalize)
    vector_list = map(Vector, [(x, y, z) for x, y, z in zip(x_values, y_values, z_values)])
    return vector_list
