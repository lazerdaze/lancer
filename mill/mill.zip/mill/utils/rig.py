
"""
.. module:: rig
   :synopsis: Functions to manipulate the millrig

.. moduleauthor:: andreasg
"""

import maya.cmds as cmds
import pymel.core as pm

from millrigger.globals.rig import GLOBAL_SPACE, MOD_GROUP, PART_GROUP, BONE_GROUP, CTRL_GROUP, MAIN_CTRL, GEO_GROUP, LOD
from millrigger.utils import transform as mtrns
from millrigger.utils import name as mname
from millrigger.utils.nodes import constraints as mcon
from millrigger.utils.nodes import create as mcre
import millrigger.utils.matrix as mmtrx
import millrigger.globals.rig as glob_rig

"""
TODO: make sure everything linked to an out connector is preserved
"""

SCENE_ID = "default_rig_scene_connector"
MAIN_ID = "default_rig_main_connector"


def is_millrig(top_node):
    """
    Checks to see whether this was a millRig rig

    :param top_node:
    :return:
    """
    if isinstance(top_node, pm.PyNode):
        top_node = top_node.name()

    for attr in cmds.listAttr(top_node):
        if attr.startswith("millRig"):
            return True
    return False


def is_merged(top_node):
    """
    checks for existence of mod_GRP as indicator if rig is already merged

    :param top_node:
    :return:
    """
    child_names = cmds.listRelatives(top_node.name(), type="transform")
    return glob_rig.MOD_GROUP not in child_names


def merge_modules(top_node):
    """
    Merge modules into a hierarchy

    :param top_node: top-node of a millRig
    :type name: PyNode
    """
    if is_merged(top_node):
        pm.warning("MillRig is already merged")
        return

    global_space, main_module_group, main_control, main_parts, main_bones, control_group = _get_rig_nodes(top_node)

    # get the root and in connectors
    scene_connectors = []
    main_connectors = []
    in_connectors = []
    for connector in top_node.getChildren(ad=True, type="millRigConnectorIn"):
        if connector.identifier.get() == SCENE_ID:
            scene_connectors.append(connector)
        elif connector.identifier.get() == MAIN_ID:
            main_connectors.append(connector)
        else:
            in_connectors.append(connector)

    # run through and deal with the root connectors
    for scene_connector in scene_connectors:
        _merge_root_connector(scene_connector, global_space, main_control, control_group)
    for main_connector in main_connectors:
        _merge_root_connector(main_connector, global_space, main_control, main_control)

    # run through and deal with the in connectors
    for in_connector in in_connectors:
        _merge_in_connector(in_connector, main_control)

    # if a module hasn't got an in connector, check any remaining out_connectors
    out_connectors = top_node.getChildren(ad=True, type="millRigConnectorOut")
    for connector in out_connectors:
        _merge_leftover_out_connector(connector)

    # clear up the mod groups
    _clean_up_module_groups(main_module_group, control_group, main_parts, main_bones)
    remove_empty_mods(main_module_group)


def create_sets(top_node):
    """
    Creates the 'CACHE' and 'Controls' sets, then also selection sets for each module

    :param top_node:
    :return:
    """
    out = []
    grps = []

    millrig_modules = pm.ls(type="millRigModuleNode")
    for mod in millrig_modules:
        ctrls = [i for i in mod.members() if i.name().endswith("CTRL")]
        ctrls = list(set(ctrls))
        if not ctrls:
            continue

        grp_name = "SELECT_" + mod.name().upper()
        grp = _create_select_set(grp_name, ctrls)
        grps.append(grp)

    if grps:
        out.append(_create_select_set("SELECT", grps))

    out.append(_sort_into_set(top_node=top_node, set_name="CONTROLS", getter=_get_all_controls))
    out.append(_sort_into_set(top_node=top_node, set_name="CACHE", getter=_get_all_geo))
    return out


def remove_millrig_nodes(top_node=None):
    """
    save remove of all millRig-Nodes (dummyNode and sets)...
    clears sets before deleting to avoid unwanted removal of nodes
    :return:
    """
    # get topNode of rig-hierachy
    if top_node is None:
        top_node = pm.selected()[0].root()

    if not is_merged(top_node):
        pm.warning("MillRig needs to be merged first!")
        return

    # get top-set of millRig
    top_module_node = top_node.outputs(type='millRigModuleNode')

    if not top_module_node:
        pm.warning("MillRig is already removed!")
        return

    top_module_node = top_module_node[0]

    # get dummy-node of millRig
    dummy_node = top_module_node.dagSetMembers[0].inputs()[0]

    # get all module-sets of millRig
    module_nodes = [item for item in top_module_node.members()
                    if item.type() == 'millRigModuleNode']

    pm.delete(top_module_node)
    for item in module_nodes:
        pm.sets(item, clear=True)
        pm.delete(item)
    pm.delete(dummy_node)


def get_default_stored_attributes():
    """

    :return:
    """
    return {"C_global_CTRL.LOD": 2}


def create_bone_hierarchy(node, ns="", connect=True):
    """
    create a massive-compatible-bonehierarchy by extracting and reorganising
    copoies of the skinbones

    :param node: any node of the rig (needed to get namespace)
    :param ns: namespace
    :param connect: simple-constraint bones to rig
    """

    if ns:
        ns = ns + '__'

    old_namespace = mname.get_namespace(node.name())[0]
    parent_module_dict = _analyse_module_hierarchy(node.root())
    bone_dict = _extract_bones(parent_module_dict,
                               old_namespace=old_namespace,
                               new_namespace=ns,
                               connect=connect)

    bone_obj = None  # just to get access to a bone in the hierarchy
    for base_name in parent_module_dict:
        par_basename = parent_module_dict.get(base_name)
        bone = bone_dict.get(base_name)

        if isinstance(par_basename, list):
            for item in par_basename:
                par = bone_dict.get(item)
                if par:
                    break
        else:
            par = bone_dict.get(par_basename)
        if bone and par:
            bone_obj = bone[0]
            matrix = mmtrx.get_matrix(bone_obj)
            parent_obj = par[-1]
            pm.parent(bone_obj, parent_obj, r=True)
            mmtrx.set_matrix(bone_obj, matrix)

    return bone_obj.root()


def create_model_groups(matrix, side='L', sections=None):

    lods = ['proxy', 'anim', 'render']

    geo_grp = pm.ls(GEO_GROUP)
    lod_rmc = pm.ls(LOD)

    if not geo_grp:
        pm.warning("Missing node: %s" % GEO_GROUP)
        return
    else:
        geo_grp = geo_grp[0]

    if not lod_rmc:
        pm.warning("Missing node: %s" % LOD)
        return
    else:
        lod_rmc = lod_rmc[0]

    model_grps = []

    for part in sections:
        basename = side + '_' + part
        srt = mcre.node('transform',
                        name='%s_SRT' % basename,
                        matrix=matrix,
                        parent=geo_grp).transform
        model_grps.append(srt)

        mcre.locator(name='%s_LOC' % basename,
                     matrix=matrix,
                     parent=srt)

        for lod, col in zip(lods, "RGB"):
            node = mcre.node('transform',
                             name='%s_%s' % (basename, lod),
                             matrix=matrix,
                             parent=srt).transform
            lod_rmc.attr("outColor" + col) >> node.visibility
    return model_grps


def remove_empty_mods(main_module_group):
    """
    Go through all the mod groups and remove the empty ones.

    :param main_module_group:
    :return:
    """
    # delete groups without children
    for child in main_module_group.getChildren(ad=False, type="transform"):
        if not child.numChildren():
            pm.delete(child)

    # if the mod group has no children, delete it
    if not main_module_group.numChildren():
        pm.delete(main_module_group)


# =============================================================================
# NON-PUBLIC FUNCTIONS --------------------------------------------------------
# =============================================================================

def _sort_into_set(top_node, set_name, getter):
    # get the set
    if pm.objExists(set_name):
        _set = pm.PyNode(set_name)
        if not _set.type() == "objectSet":
            pm.warning(set_name + " is already made and is not a set, skipping.")
            return
    else:
        _set = pm.createNode("objectSet", n=set_name)

    # add the items
    items = getter(top_node.name())
    pm.select()
    _set.addMembers(items)
    return _set


def _get_all_controls(top_node_name):
    return [n for n in cmds.listRelatives(top_node_name, ad=True, pa=True) if n.endswith("_CTRL")]


def _get_all_geo(top_node_name):
    geo = [n for n in cmds.listRelatives(top_node_name, ad=True, pa=True) if n.endswith("_GEO")]
    nrbs = [n for n in cmds.listRelatives(top_node_name, ad=True, pa=True)
            if n.endswith("_NRB")]
    nrbs[:] = [n for n in nrbs if not n.endswith("_BONE_NRB") and not n.endswith("_CTRL_NRB")]
    if nrbs:
        geo.extend(nrbs)
    return geo


def _get_rig_nodes(top_node):
    """
    Returns any nodes we need from the rig - and PyNode calls are in here so, if we get errors, they happen before
    anything important.

    :param top_node:
    :return:
    """
    global_space = pm.PyNode(GLOBAL_SPACE)
    main_module_group = pm.PyNode(MOD_GROUP)
    main_control = pm.PyNode(MAIN_CTRL)
    main_bones = pm.PyNode(BONE_GROUP)
    control_group = pm.PyNode(CTRL_GROUP)

    # sometimes maya will have deleted the parts group because it's crap, so remake it if it's not found
    if pm.objExists(PART_GROUP):
        main_parts = pm.PyNode(PART_GROUP)
    else:
        main_parts = pm.createNode("transform", n=PART_GROUP, p=top_node)
    return global_space, main_module_group, main_control, main_parts, main_bones, control_group


def _get_module_name(node):
    """
    Return the module name from a given connector

    :param connector: millRigConnector* type PyNode
    :return: String
    """
    # look for the millRigModuleNode for the module name, otherwise use the name
    for node in node.message.outputs():
        if node.type() == "millRigModuleNode":
            return node.name()
    else:
        return "_".join(node.name().split("_")[:2])


def _merge_root_connector(connector, global_space, main_ctrl, parent):
    """
    Put everything from the roots (i.e. the main_connectors and scene_connectors) under
    then main control, then use the global space to drive any worldMatrix attributes.

    :param connector: millRigConnector* type PyNode
    :param global_space: the space to connect worldMatrix to
    :return:
    """
    module_name = _get_module_name(connector)

    # parent the children to the global space
    _parent_ctrl_children(module_name, connector, parent, tag=connector.identifier.get())

    # connect any matrices to the global space
    plugs = connector.worldMatrix.outputs(p=True)
    for plug in plugs:
        parent.worldMatrix >> plug

    # connect any global scale connections to the global space
    if pm.attributeQuery("globalScaleIn", node=connector, exists=True):
        plugs = connector.globalScaleIn.outputs(p=True)
        for plug in plugs:
            global_space.sy >> plug

    # connect any local scale connections to the local space node
    if pm.attributeQuery("localScaleIn", node=connector, exists=True):
        plugs = connector.localScaleIn.outputs(p=True)
        for plug in plugs:
            _get_local_scale(global_space, main_ctrl) >> plug

    # delete the connector once we're done
    pm.delete(connector)


def _merge_in_connector(connector, main_control):
    """
    Merge the in_connectors into a main hierarchy.

    :param connector: millRigConnector* type PyNode
    :param cleanup: whether to also delete the connectors and move the parts and bones
    :return:
    """
    module_name = _get_module_name(connector)

    # make a new root transform and match the position of the connector
    inputs = connector.parentMatrixIn.inputs()
    if inputs:
        out_connector = inputs[0]
        parent = out_connector.getParent()
    else:
        out_connector = None
        parent = main_control

    connector.parentMatrixIn.disconnect()
    parent_module_name = _get_module_name(parent)

    # check to see whether the parent is the module controls group
    if not (parent.name().endswith("_CTRLS") and parent.getParent().name().endswith("_MOD")):

        # check to see whether the parent is under either of the controls group
        for node in parent.getAllParents():
            if node.name() == parent_module_name + "_CTRLS" or node.name() == CTRL_GROUP:
                break

        # otherwise make a reference under the main controls group with a constraint
        else:
            new_parent_name = parent.name() + "_REF"
            try:
                new_parent = pm.PyNode(new_parent_name)
            except pm.MayaNodeError:
                new_parent = pm.createNode("transform", n=new_parent_name, p=CTRL_GROUP)
                mcon.create_simple_constraint(source=parent, target=new_parent)
            parent = new_parent

    # parent the DAG nodes
    _parent_ctrl_children(module_name, connector, parent, tag=connector.identifier.get())

    # check any connections that use parentMatrixIn or worldMatrix
    driven_attrs = connector.parentMatrixIn.outputs(p=True)
    driven_attrs.extend(connector.worldMatrix.outputs(p=True))

    # drive them with a transform in the same space as the out connector
    if driven_attrs:
        driver = pm.createNode("transform",
                               p=parent,
                               n=connector.name() + "_DRIVER"
                               )
        mmtrx.set_matrix(driver, connector.worldMatrix.get())
        driver = driver.worldMatrix

        for driven in driven_attrs:
            driver >> driven

    # delete the in connector
    to_del = [connector]

    # delete the out connector if it's not connected to anything
    if out_connector:
        if not out_connector.worldMatrix.outputs():
            to_del.append(out_connector)

    # delete what's needed
    pm.delete(to_del)


def _merge_leftover_out_connector(connector):
    """
    For any leftover out connectors, just parent any children under the parent and delete it
    """
    children = connector.getChildren(type="transform")
    parent = connector.getParent()

    for child in children:
        child.setParent(parent)

    pm.delete(connector)


def _parent_ctrl_children(module_name, old_ctrl_root, parent, tag=""):
    """
    Make a new control root under the given parent and move all the children over

    :param module_name:
    :param old_ctrl_root:
    :param parent:
    :param tag:
    :return:
    """
    # get all the children
    child_nodes = old_ctrl_root.getChildren(type='transform')
    if not child_nodes:
        return

    # make a new root
    namer = mname.Name(module_name + '_CTRL_ROOT', add_to_tags=tag)
    ctrl_root = pm.createNode('transform', name=namer.create_name(), parent=parent)
    mtrns.match(old_ctrl_root, ctrl_root)

    # parent all the children to the new root
    for child in child_nodes:
        child.setParent(ctrl_root)


def _clean_up_module_groups(main_module_group, control_group, main_parts, main_bones):
    """
    Cleans up all the parts and bone modules

    :param module_name:
    :return:
    """
    for module_group in main_module_group.getChildren(type="transform"):
        for group in module_group.getChildren(type="transform"):
            # get the appropriate parent
            if group.name().endswith("CTRLS"):
                group_parent = control_group

            elif group.name().endswith("PARTS"):
                group_parent = main_parts

            elif group.name().endswith("BONES"):
                group_parent = main_bones

            else:
                continue

            # move any groups with children to the parent, or delete it
            children = group.getChildren(type="transform")
            if children:
                group.setParent(group_parent)
            else:
                pm.delete(group)


def _get_all_fk_ctrls(obj):
    """
    returns all FK-controls of the rig

    :param top_node:
    :return:
    """
    # fk-controls have simple names excluding the tags in the "IGNORE_TAGS"-list
    IGNORE_TAGS = ["_ik_", "_pole_", "_aim_"]
    ns = mname.get_namespace(obj.name())[0]
    all_ctrls = pm.ls("%s*_CTRL" % ns, type="transform")
    fk_ctrls = []
    for ctrl in all_ctrls:
        valid = True
        ctrl_name = ctrl.name()
        for tag in IGNORE_TAGS:
            if tag in ctrl_name:
                valid = False
                break
        if valid:
            fk_ctrls.append(ctrl)
    return fk_ctrls


def _get_all_bone_srts(obj):
    """
    returns all FK-controls of the rig

    :param top_node:
    :return:
    """
    ns = mname.get_namespace(obj.name())[0]
    all_srts = pm.ls("%s*_bone_SRT" % ns, type="transform")
    return all_srts


def _get_module_dict(objs):
    """
    returns a dictionary with all the parent-controls of the given controls or bones
    while using an "exception-dict" because it sometimes is needed.
    :param objs:
    :return:
    """

    EXCEPTION_DICT = {'eye': 'C_head',
                      'torso': ['C_hip', 'C_pelvis'],
                      'spine': ['C_hip', 'C_pelvis'],
                      'chest': ['C_spine', 'C_torso'],
                      'belly': ['C_hip', 'C_pelvis'],
                      'neck': ['C_chest', 'C_spine', 'C_torso'],
                      'head': 'C_neck',
                      'toe': '_foot'}

    parent_dict = {}
    for obj in objs:
        # get longname and split it the get the basenames of each element of the hierarchy
        split_list = obj.longName().split("|")
        basename_list = ['_'.join(item.split('_')[:2]) for item in split_list][::-1]
        basename_list[:] = [mname.get_namespace(item)[-1] for item in basename_list]

        # filter out duplicates and the top-node
        sorted_list = []
        for item in basename_list:
            if item:
                if item not in sorted_list and item[0].isupper():
                    sorted_list.append(item)

        # set values and check with exception-list
        for child, par in zip(sorted_list[:-1], sorted_list[1:]):
            if child not in parent_dict.keys():
                key = child.rsplit("_", 1)[-1]
                if key[-1].isupper():
                    key = key[:-1]
                par = EXCEPTION_DICT.get(key, par)
                if par[0] == '_':
                    par = child[0] + par
                parent_dict[child] = par

    return parent_dict


def _analyse_module_hierarchy(top):
    """
    returns a dictionary with all the parent-module-names
    To get better results it looks at fk-controls and bones
    :param top:
    :return: dictionary containing the basenames of modules and their parents
    """
    ctrls = _get_all_fk_ctrls(top)
    bones = _get_all_bone_srts(top)
    parent_module_dict = _get_module_dict(ctrls)
    bone_dict = _get_module_dict(bones)
    for item in bone_dict:
        if item not in parent_module_dict:
            parent_module_dict[item] = bone_dict[item]
    return parent_module_dict


def _extract_bones(parent_module_dict,
                   old_namespace=None,
                   new_namespace='test__',
                   connect=False):
    """
    duplicate all bones and create new hierarchy

    :param parent_module_dict: dictionary containing parent-module-names
    :param old_namespace: original namespace of the rig
    :param new_namespace: resulting namespace for the new bones-hierarchy
    :param connect: if True create simple-constraints for the new bones
    :return:
    """
    SORT_DICT = {'C_belly': 'hip'}

    bone_dict = {}
    for base_name in parent_module_dict:
        # get bones of each module by using the basename
        sources = pm.ls(old_namespace + base_name + "_*BONE")
        x = sorted([item.longName() for item in sources], key=len)
        # using the SORT_DICT to deal with hierarchy-exceptions like:
        # "C_belly_hip_BONE", "C_belly_01_BONE", "C_belly_02_BONE", "C_belly_chest_BONE"
        if base_name in SORT_DICT:
            for item in x:
                if SORT_DICT[base_name] in item:
                    x.remove(item)
                    x.insert(0, item)
                    break

        sources[:] = pm.ls(x)
        chain = []
        par = None
        # create bones and create hierarchy
        for src in sources:
            src_name = src.shortName()
            src_name
            namer = mname.Name(src_name)
            namer.namespace = None
            index = namer.index
            tags = namer.tags or ""

            # exception for twistjoints to be parented parallel to the chain
            as_chain = True
            if "twist" in tags and index != "01":
                par = new_namespace + namer.replace(index="01")
                as_chain = False
            bone = pm.createNode('joint',
                                 name=new_namespace + namer.create_name(),
                                 parent=par)

            if as_chain:
                chain.append(bone)
            par = bone

            # make sure the bone-placement hasn't changed
            mmtrx.set_matrix(bone, mmtrx.clean_scale(mmtrx.get_matrix(src)))

            # onnect the bone to the original bone with a simpleconstraint
            if connect:
                mcon.create_simple_constraint(src, bone)

        bone_dict[base_name] = chain
    return bone_dict


def _create_select_set(name, objs):
    """
    Make a set for selection with the given name and containing the given objects
    """
    if pm.objExists(name):
        grp = pm.PyNode(name)
    else:
        grp = pm.sets(empty=True)
        grp.rename(name)

    grp.addMembers(objs)
    grp.ihi.set(2)
    return grp


def _get_local_scale(global_space, main_ctrl):
    """
    Gets the local scale, if the automatic node isn't in the rig (if it's pre v1.4.1) then one will be created

    :param global_space:
    :param main_ctrl:
    :param as_vector3:
    :return:
    """
    node = "*_main_connector_millRigConnectorOut_localScale_MULT"
    nodes = pm.ls(node, type="multiplyDivide")
    if not nodes:
        node = pm.createNode("multiplyDivide",
                             n="main_connector_millRigConnectorOut_localScale_MULT"
                             )
        global_space.scale >> node.input1
        main_ctrl.localScale >> node.input2X
        main_ctrl.localScale >> node.input2X
        main_ctrl.localScale >> node.input2X
    else:
        node = nodes[0]

    return node.outputX
