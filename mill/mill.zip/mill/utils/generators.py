
def splitter(values, split_values, relative=False):
    '''
    generates list of sublists based on the second lists values

    :param values: value list
    :type values: list of Floats
    :param split_values: value list
    :type split_values: list of Floats
    :param relative: if True: indices will be used as segment-length-list
    :type relative: boolean

    :rtype: generator-object (use: list(partition(listA, listB))
    '''

    # create list of length-values that trigger the use of a new parent
    if relative:
        split_list = [split_values[0]]
        for item in split_values[1:]:
            split_list.append(split_list[-1] + item)
    else:
        split_list = split_values

    i = 0
    offset = 0.0
    for split_val in split_list:
        sublist = []
        while i < len(values) and values[i] < split_val:
            val = values[i]
            if relative:
                val -= offset
            sublist.append(val)
            i += 1
        if sublist != []:
            yield sublist
        offset = split_val

    # spillover
    if values[i:] != []:
        if relative:
            yield [val - offset for val in values[i:]]
        else:
            yield values[i:]
