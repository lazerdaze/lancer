#!/usr/bin/env pysaveMiasmaSceneVersionthon
# -*- coding: utf-8 -*-
# $HeadURL: http://svn3d/rnd/trunk/tools/miasma/maya/scripts/miasma_basics.py $
# $Id: miasma_basics.py 20530 2016-06-06 18:37:55Z blamb $

import os
import sys

import pymel.core as pm

if 'MIASMA_MAYA_TEST' in os.environ:
    print("*** USING TEST ENVIRONMENT: %s ***" % os.environ['MIASMA_MAYA_TEST'])
    path_elems = os.environ['MIASMA_MAYA_TEST'].split('/')
    miasma_path = '/'.join(path_elems[:-2])
    print("*** INSERTING TEST PATH: %s ***" % miasma_path)
    if not miasma_path in sys.path:
        sys.path.insert(0, miasma_path)

import miasma
import miasma.core
import miasma.core.exceptions as exceptions
import miasma.ui.version_creator
import general_utilities
import miasma_utilities
import miasma_gui_utilities

from millrigger.globals.io import ICON_PATH

log = miasma.getLogger()


def is_miasma_scene():
    return bool(miasma_utilities.findAssetNodes(asset_type="application_file"))


def increment_scene(comment=False):
    '''Create a new version of an existing asset in Miasma.'''
    # get the asset
    scene_assets = miasma_utilities.findAssetNodes(asset_type="application_file")
    if scene_assets:
        asset_node = scene_assets[0]
    else:
        pm.error("This is not a miasma scene, cannot increment save")
        return False

    # present the UI, it creates the asset for us.
    ui = miasma.ui.version_creator.VersionCreator()

    ui.version_ui.asset_type = asset_node.asset.asset_type
    origin_location = pm.sceneName() or general_utilities.mostRecentProjectPath() + "/"

    mia = miasma.connect()
    versions = list()

    asset = asset_node.asset

    # Create the Version IO.
    mio = ui.version_ui.ioFromUI()
    mio.asset_node = asset_node
    mio.asset = asset_node.asset
    mio.asset_type = asset.asset_type

    # Create the version.
    log.debug("Creating the version.")
    try:
        icon = os.path.join(ICON_PATH, 'head_icon.png')

        latest_version = mio.createVersion(asset.default_stream,
                                           origin_location,
                                           icon,
                                           comment=comment)
    except exceptions.MiasmaError as err:
        miasma_gui_utilities.Error("Failed to create asset version.",
                                   "Failed to create asset version, this is the reason:",
                                   str(err)).show()
        return None

    log.info("Created asset: '%s' Version: %d", asset.name, latest_version.version)
    versions.append(latest_version)
    asset_node.version = latest_version
    return versions
