"""
Created on 4 Feb 2016

@author: andreasg
"""

# maya imports
import maya.api.OpenMaya as om


def get_mobject(node):
    """ returns Api 2.0 object """
    sel = om.MSelectionList()
    sel.add(node)
    mobject = sel.getDependNode(0)
    return mobject


def get_mfn_mesh(node):
    """ returns Api 2.0 MFnMesh-object """
    mobj = get_mobject(node.name())
    mfn = om.MFnMesh(mobj)
    return mfn


def get_mfn_nurbscurve(node):
    """ returns Api 2.0 MFnNurbsCurve-object """
    mobj = get_mobject(node.name())
    mfn = om.MFnNurbsCurve(mobj)
    return mfn


def get_mfn_nurbssurface(node):
    """ returns Api 2.0 MFnNurbsSurface-object """
    mobj = get_mobject(node.name())
    mfn = om.MFnNurbsSurface()
    mfn.setObject(mobj)
    return mfn


def get_closest_point_on_mesh(mesh, mpoint):
    """ returns closest point on mesh with api 2.0 """
    mesh = _check_mesh(mesh)
    mpoint = _check_mpoint(mpoint)

    return mesh.getClosestPoint(mpoint)[0]


def get_closest_uv_on_mesh(mesh, mpoint):
    """ returns uv by closest point on mesh with api 2.0 """
    mesh = _check_mesh(mesh)
    mpoint = _check_mpoint(mpoint)

    pnt = get_closest_point_on_mesh(mesh, mpoint)[0]
    u, v = mesh.getUVAtPoint(pnt)
    return u, v


def _check_mesh(mesh):
    if not isinstance(mesh, om.MFnMesh):
        mesh = get_mfn_mesh(mesh)
    return mesh


def _check_mpoint(mpoint):
    if not isinstance(mpoint, om.MPoint):
        mpoint = om.MPoint(mpoint)
    return mpoint
